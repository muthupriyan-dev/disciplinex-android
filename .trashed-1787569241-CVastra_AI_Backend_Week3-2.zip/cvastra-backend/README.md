# CVastra AI — Backend API (Week 3)

NSDC Junior Full Stack Developer Internship — Week 3 Task: Back-End API Development.

A RESTful Node.js/Express API for **CVastra AI**, the resume-scoring service planned in
the Week 1 architecture doc and given a front-end in Week 2. It handles user accounts,
resume uploads, and AI-scored analyses, backed by MongoDB.

## Stack

- **Runtime:** Node.js (Express 4)
- **Database:** MongoDB via Mongoose
- **Auth:** JWT (stateless — no server-side sessions), passwords hashed with bcrypt
- **File handling:** Multer (in-memory) + `pdf-parse` / `mammoth` for text extraction
- **AI scoring:** Google Gemini API, with a deterministic mock fallback when no API
  key is configured (see [Scoring behavior](#scoring-behavior) below)
- **Security:** Helmet, CORS allow-list, `express-mongo-sanitize`, rate limiting on
  auth and analysis routes, per-user ownership checks on every resource
- **Validation:** `express-validator`
- **Testing:** Jest + Supertest + `mongodb-memory-server` (no external DB needed to test)

## Project structure

```
cvastra-backend/
  src/
    config/db.js            MongoDB connection
    models/                 Mongoose schemas: User, Resume, Analysis
    middleware/              auth (JWT), validate, centralized errorHandler
    controllers/              request handlers, one file per resource
    routes/                   route definitions + validation chains
    services/
      geminiService.js        scoring — real Gemini call or mock fallback
      textExtractionService.js  PDF/DOCX -> plain text
    app.js                    Express app assembly
    server.js                 entrypoint — connects DB, starts listening
  tests/                     Jest + Supertest integration tests
  .env.example
  API_DOCUMENTATION.md
```

## Setup

Requires Node.js 18+ and a MongoDB connection (local, Docker, or Atlas).

```bash
git clone <this-repo-url>
cd cvastra-backend
npm install
cp .env.example .env
# edit .env — set MONGO_URI, JWT_SECRET at minimum
npm run dev      # nodemon, auto-restarts on change
# or
npm start        # plain node
```

Server starts on `http://localhost:5000` by default. Health check:

```bash
curl http://localhost:5000/api/health
```

## Running tests

```bash
npm install
npm test
```

Tests spin up an in-memory MongoDB instance (`mongodb-memory-server`), so no real
database or network access is needed to run the suite. Coverage: signup/login/me
lifecycle, resume CRUD + file validation + ownership checks, analysis
create/list/patch/delete, and the resume→analysis cascade delete.

> **Note on this submission:** this code was written and syntax-checked
> (`node --check`) in a sandboxed environment with no network access, so `npm
> install` / `npm test` could not be executed here. Please run `npm install &&
> npm test` locally or in CI before deploying — all 20 test cases are written and
> ready to run.

## Environment variables

See `.env.example` for the full list. Key ones:

| Variable | Purpose |
|---|---|
| `MONGO_URI` | MongoDB connection string |
| `JWT_SECRET` | Signs auth tokens — use a long random string in production |
| `GEMINI_API_KEY` | Optional. Enables real AI scoring; omit to use the mock scorer |
| `CORS_ORIGIN` | Comma-separated list of allowed frontend origins |

## Scoring behavior

`services/geminiService.js` calls the Gemini API when `GEMINI_API_KEY` is set,
using the same structured, 7-dimension prompt from the Week 1 plan. When the key
is absent, it falls back to a **deterministic mock scorer**: scores are derived
from a hash of the resume text, so the same resume always gets the same mock
score (not random noise on every call) — useful for local development and for
running the test suite without burning API quota.

## Deployment

Designed to deploy on Render (matching the Week 1 plan and the existing CVastra
AI backend): connect the GitHub repo, set the environment variables above in the
Render dashboard, and set the start command to `npm start`.

## Design notes / rationale

- **JWT over sessions** — keeps the API stateless, matching Render's deployment
  model and the architecture already chosen in Week 1.
- **Ownership checks in controllers, not just route-level auth** — `requireAuth`
  confirms *a* valid user; each resume/analysis controller additionally checks
  the resource belongs to *that* user (403 otherwise), so one account can never
  read or modify another's data even if it guesses a valid Mongo ID.
- **Cascade delete** — deleting a resume also deletes its analyses, so no
  orphaned records point at a resume that no longer exists.
- **Centralized error handling** — every controller is wrapped in `asyncHandler`
  and throws `AppError`; a single `errorHandler` middleware normalizes Mongoose
  cast/validation/duplicate-key errors into consistent JSON responses instead of
  leaking stack traces.
- **In-memory file uploads** — Multer stores the file in memory rather than on
  disk, since only the extracted text is persisted; this also fits a container
  deployment on Render without needing a persistent volume.
