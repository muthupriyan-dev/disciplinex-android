# CVastra AI — API Documentation

Base URL (local): `http://localhost:5000/api`
Base URL (production): `https://<your-render-service>.onrender.com/api`

## Conventions

- All request/response bodies are JSON, except file upload which is `multipart/form-data`.
- All responses follow the shape:
  ```json
  { "success": true, "data": { ... } }
  ```
  or, on error:
  ```json
  { "success": false, "message": "...", "details": [ { "field": "...", "message": "..." } ] }
  ```
  (`details` is only present for validation errors.)
- Protected routes require an `Authorization: Bearer <token>` header. The token is
  returned by signup/login and expires per `JWT_EXPIRES_IN` (default 7 days).
- All `:id` params are MongoDB ObjectIds; an invalid format returns `400`.

## Error status codes

| Code | Meaning |
|---|---|
| 400 | Bad request (e.g. missing file, malformed ID) |
| 401 | Missing/invalid/expired token, or wrong credentials |
| 403 | Authenticated, but not the owner of this resource |
| 404 | Resource not found |
| 409 | Conflict (e.g. email already registered) |
| 413 | Payload too large (file over 5MB) |
| 422 | Validation failed |
| 429 | Rate limit exceeded |
| 500 | Unexpected server error |

---

## Auth

### `POST /api/auth/signup`
Create a new account.

**Body**
```json
{ "name": "Muthu", "email": "muthu@example.com", "password": "at least 8 chars" }
```

**201 Response**
```json
{
  "success": true,
  "data": {
    "user": { "id": "…", "name": "Muthu", "email": "muthu@example.com", "createdAt": "…" },
    "token": "eyJhbGciOi..."
  }
}
```

Errors: `422` invalid input, `409` email already registered.

---

### `POST /api/auth/login`
**Body**
```json
{ "email": "muthu@example.com", "password": "..." }
```
**200 Response** — same shape as signup.
Errors: `401` incorrect email or password.

---

### `GET /api/auth/me` 🔒
Returns the currently authenticated user.

**200 Response**
```json
{ "success": true, "data": { "user": { "id": "…", "name": "…", "email": "…", "createdAt": "…" } } }
```

---

### `PUT /api/auth/me` 🔒
Update the current user's profile.

**Body**
```json
{ "name": "New Name" }
```
**200 Response** — updated user object.

---

### `DELETE /api/auth/me` 🔒
Deletes the current user's account. **204 No Content.**

---

## Resumes

All routes below require `Authorization: Bearer <token>` and only ever operate on
the current user's own resumes.

### `POST /api/resumes` 🔒
Upload a resume. `multipart/form-data`.

**Fields**
| Field | Type | Required | Notes |
|---|---|---|---|
| `resume` | file | yes | PDF or DOCX, max 5MB |
| `targetRole` | string | no | improves scoring relevance |

**201 Response**
```json
{
  "success": true,
  "data": {
    "resume": {
      "id": "…",
      "fileName": "resume.pdf",
      "mimeType": "application/pdf",
      "sizeBytes": 48213,
      "targetRole": "Frontend Developer",
      "textPreview": "Experienced Frontend Developer with…",
      "createdAt": "…",
      "updatedAt": "…"
    }
  }
}
```

Errors: `400` no file / unsupported type, `413` over 5MB, `422` text could not be extracted.

---

### `GET /api/resumes` 🔒
List all resumes owned by the current user, newest first.

**200 Response**
```json
{ "success": true, "count": 2, "data": { "resumes": [ { "...": "..." } ] } }
```

---

### `GET /api/resumes/:id` 🔒
Fetch a single resume.
Errors: `404` not found, `403` belongs to another user.

---

### `PUT /api/resumes/:id` 🔒
Update a resume's target role (the file itself is immutable — re-upload to replace it).

**Body**
```json
{ "targetRole": "Senior Frontend Developer" }
```
**200 Response** — updated resume object.

---

### `DELETE /api/resumes/:id` 🔒
Deletes the resume **and cascades to delete all of its analyses.**
**204 No Content.**

---

## Analyses

### `POST /api/resumes/:id/analyze` 🔒
Run scoring on a resume. Calls the Gemini API (or the mock fallback — see README)
and persists the result. Rate-limited to 15 requests / 15 minutes per IP.

**201 Response**
```json
{
  "success": true,
  "data": {
    "analysis": {
      "id": "…",
      "resume": "…",
      "overallScore": 78,
      "scores": {
        "formatting": 85, "content": 70, "keyword": 65,
        "experience": 80, "skills": 75, "impact": 60, "ats": 90
      },
      "feedback": [
        "Add quantifiable metrics to project bullet points.",
        "Include more role-specific keywords for the target position."
      ],
      "note": null,
      "createdAt": "…",
      "updatedAt": "…"
    }
  }
}
```

Errors: `404` resume not found, `403` not your resume, `429` rate limit.

---

### `GET /api/analyses` 🔒
List all analyses for the current user, newest first (each includes the
associated resume's `fileName` and `targetRole`).

**200 Response**
```json
{ "success": true, "count": 3, "data": { "analyses": [ { "...": "..." } ] } }
```

---

### `GET /api/analyses/:id` 🔒
Fetch a single analysis.
Errors: `404`, `403`.

---

### `PATCH /api/analyses/:id` 🔒
Update the user-editable **note** field. Scores and feedback are immutable —
if you want a new score, run `POST /api/resumes/:id/analyze` again.

**Body**
```json
{ "note": "Applied to three roles with this version." }
```
**200 Response** — updated analysis object.

---

### `DELETE /api/analyses/:id` 🔒
**204 No Content.**

---

## Health check

### `GET /api/health`
No auth required. Returns `{ "success": true, "message": "CVastra AI API is running." }`.
Useful for uptime monitors and Render health checks.

---

## Example: full flow with curl

```bash
# 1. Sign up
TOKEN=$(curl -s -X POST http://localhost:5000/api/auth/signup \
  -H "Content-Type: application/json" \
  -d '{"name":"Muthu","email":"muthu@example.com","password":"correcthorse123"}' \
  | node -pe "JSON.parse(require('fs').readFileSync(0)).data.token")

# 2. Upload a resume
curl -s -X POST http://localhost:5000/api/resumes \
  -H "Authorization: Bearer $TOKEN" \
  -F "resume=@./sample-resume.pdf" \
  -F "targetRole=Frontend Developer"

# 3. Analyze it (replace RESUME_ID)
curl -s -X POST http://localhost:5000/api/resumes/RESUME_ID/analyze \
  -H "Authorization: Bearer $TOKEN"

# 4. View history
curl -s http://localhost:5000/api/analyses -H "Authorization: Bearer $TOKEN"
```
