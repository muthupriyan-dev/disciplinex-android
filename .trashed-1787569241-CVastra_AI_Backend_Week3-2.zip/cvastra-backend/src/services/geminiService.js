const { SCORE_DIMENSIONS } = require("../models/Analysis");

const GEMINI_URL =
  "https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent";

function buildPrompt(resumeText, targetRole) {
  return `You are an expert resume reviewer. Score the following resume across exactly these
seven dimensions, each from 0-100: formatting, content, keyword, experience, skills, impact, ats.
${targetRole ? `Weight keyword and skills scoring against this target role: "${targetRole}".` : ""}
Also return 3-5 short, actionable feedback bullet points.

Respond with ONLY valid JSON in this exact shape, no markdown fences:
{
  "scores": { "formatting": 0, "content": 0, "keyword": 0, "experience": 0, "skills": 0, "impact": 0, "ats": 0 },
  "feedback": ["...", "..."]
}

Resume text:
"""
${resumeText.slice(0, 12000)}
"""`;
}

/** Deterministic pseudo-random score so mock results are stable per resume text, not random noise on every call. */
function seededScore(seed, min, max) {
  let hash = 0;
  for (let i = 0; i < seed.length; i++) {
    hash = (hash << 5) - hash + seed.charCodeAt(i);
    hash |= 0;
  }
  const normalized = Math.abs(hash % 1000) / 1000;
  return Math.round(min + normalized * (max - min));
}

const MOCK_FEEDBACK_POOL = [
  "Add quantifiable metrics to project bullet points (e.g. \"reduced load time by 40%\").",
  "Include more role-specific keywords for the target position.",
  "Formatting is clean and ATS-friendly — keep the single-column layout.",
  "Trim the summary section to 2-3 lines so recruiters reach experience faster.",
  "List technical skills in a scannable group rather than inline prose.",
  "Use stronger action verbs to open each bullet point.",
  "Experience section reads well but is missing measurable outcomes for the most recent role.",
  "Consider a dedicated projects section to surface relevant work not tied to employment.",
];

function mockScore(resumeText, targetRole) {
  const seed = resumeText.slice(0, 500) + (targetRole || "");
  const scores = {};
  SCORE_DIMENSIONS.forEach((dim, i) => {
    scores[dim] = seededScore(seed + dim, 55, 96);
  });
  const feedback = MOCK_FEEDBACK_POOL.filter(
    (_, i) => seededScore(seed + i, 0, 1) === 1 || i < 3
  ).slice(0, 4);
  return { scores, feedback };
}

/**
 * Scores resume text against the seven CVastra dimensions.
 * Uses the real Gemini API when GEMINI_API_KEY is set; otherwise falls back
 * to a deterministic mock so the API is fully runnable/testable without a key.
 */
async function scoreResume(resumeText, targetRole) {
  const apiKey = process.env.GEMINI_API_KEY;

  if (!apiKey) {
    return mockScore(resumeText, targetRole);
  }

  const response = await fetch(`${GEMINI_URL}?key=${apiKey}`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      contents: [{ parts: [{ text: buildPrompt(resumeText, targetRole) }] }],
    }),
  });

  if (!response.ok) {
    throw new Error(`Gemini API error: ${response.status} ${response.statusText}`);
  }

  const data = await response.json();
  const raw = data.candidates?.[0]?.content?.parts?.[0]?.text || "";
  const cleaned = raw.replace(/```json|```/g, "").trim();

  let parsed;
  try {
    parsed = JSON.parse(cleaned);
  } catch (e) {
    throw new Error("Gemini returned a response that could not be parsed as JSON.");
  }

  SCORE_DIMENSIONS.forEach((dim) => {
    if (typeof parsed.scores?.[dim] !== "number") {
      throw new Error(`Gemini response missing score for dimension: ${dim}`);
    }
  });

  return { scores: parsed.scores, feedback: parsed.feedback || [] };
}

function computeOverall(scores) {
  const values = SCORE_DIMENSIONS.map((dim) => scores[dim]);
  return Math.round(values.reduce((a, b) => a + b, 0) / values.length);
}

module.exports = { scoreResume, computeOverall };
