const pdfParse = require("pdf-parse");
const mammoth = require("mammoth");
const AppError = require("../utils/AppError");

/**
 * Extracts plain text from an uploaded resume buffer based on its mimetype.
 */
async function extractText(buffer, mimeType) {
  if (mimeType === "application/pdf") {
    const result = await pdfParse(buffer);
    return result.text.trim();
  }

  if (
    mimeType ===
    "application/vnd.openxmlformats-officedocument.wordprocessingml.document"
  ) {
    const result = await mammoth.extractRawText({ buffer });
    return result.value.trim();
  }

  throw new AppError("Unsupported file type. Upload a PDF or DOCX file.", 400);
}

module.exports = { extractText };
