const express = require("express");
const multer = require("multer");
const { body, param } = require("express-validator");
const validate = require("../middleware/validate");
const requireAuth = require("../middleware/auth");
const {
  createResume,
  listResumes,
  getResume,
  updateResume,
  deleteResume,
} = require("../controllers/resumeController");

const router = express.Router();

const upload = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: 5 * 1024 * 1024 },
  fileFilter: (req, file, cb) => {
    const allowed = [
      "application/pdf",
      "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
    ];
    if (!allowed.includes(file.mimetype)) {
      return cb(new Error("Only PDF and DOCX files are allowed."));
    }
    cb(null, true);
  },
});

router.use(requireAuth); // every resume route requires a logged-in user

router.post("/", upload.single("resume"), createResume);
router.get("/", listResumes);

router.get("/:id", [param("id").isMongoId()], validate, getResume);

router.put(
  "/:id",
  [
    param("id").isMongoId(),
    body("targetRole").optional({ nullable: true }).trim().isLength({ max: 150 }),
  ],
  validate,
  updateResume
);

router.delete("/:id", [param("id").isMongoId()], validate, deleteResume);

module.exports = router;
