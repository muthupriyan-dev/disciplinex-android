const express = require("express");
const { body } = require("express-validator");
const rateLimit = require("express-rate-limit");
const validate = require("../middleware/validate");
const requireAuth = require("../middleware/auth");
const {
  signup,
  login,
  getMe,
  updateMe,
  deleteMe,
} = require("../controllers/authController");

const router = express.Router();

// Tighter limiter on auth routes to slow down credential stuffing / brute force.
const authLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 20,
  standardHeaders: true,
  legacyHeaders: false,
  message: { success: false, message: "Too many auth attempts. Try again later." },
});

router.post(
  "/signup",
  authLimiter,
  [
    body("name").trim().notEmpty().withMessage("Name is required").isLength({ max: 100 }),
    body("email").isEmail().withMessage("A valid email is required").normalizeEmail(),
    body("password")
      .isLength({ min: 8 })
      .withMessage("Password must be at least 8 characters"),
  ],
  validate,
  signup
);

router.post(
  "/login",
  authLimiter,
  [
    body("email").isEmail().withMessage("A valid email is required").normalizeEmail(),
    body("password").notEmpty().withMessage("Password is required"),
  ],
  validate,
  login
);

router.get("/me", requireAuth, getMe);

router.put(
  "/me",
  requireAuth,
  [body("name").optional().trim().isLength({ min: 1, max: 100 })],
  validate,
  updateMe
);

router.delete("/me", requireAuth, deleteMe);

module.exports = router;
