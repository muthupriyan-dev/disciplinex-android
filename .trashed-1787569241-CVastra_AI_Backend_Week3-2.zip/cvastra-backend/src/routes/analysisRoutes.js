const express = require("express");
const rateLimit = require("express-rate-limit");
const { body, param } = require("express-validator");
const validate = require("../middleware/validate");
const requireAuth = require("../middleware/auth");
const {
  createAnalysis,
  listAnalyses,
  getAnalysis,
  updateAnalysis,
  deleteAnalysis,
} = require("../controllers/analysisController");

const router = express.Router();

// Analysis calls out to the Gemini API and is the most expensive route —
// limit it more tightly than general reads.
const analyzeLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 15,
  standardHeaders: true,
  legacyHeaders: false,
  message: { success: false, message: "Too many analysis requests. Try again later." },
});

router.use(requireAuth);

router.post(
  "/resumes/:id/analyze",
  analyzeLimiter,
  [param("id").isMongoId()],
  validate,
  createAnalysis
);

router.get("/analyses", listAnalyses);
router.get("/analyses/:id", [param("id").isMongoId()], validate, getAnalysis);

router.patch(
  "/analyses/:id",
  [param("id").isMongoId(), body("note").optional({ nullable: true }).trim().isLength({ max: 500 })],
  validate,
  updateAnalysis
);

router.delete("/analyses/:id", [param("id").isMongoId()], validate, deleteAnalysis);

module.exports = router;
