const Resume = require("../models/Resume");
const Analysis = require("../models/Analysis");
const AppError = require("../utils/AppError");
const asyncHandler = require("../utils/asyncHandler");
const { scoreResume, computeOverall } = require("../services/geminiService");

// POST /api/resumes/:id/analyze
const createAnalysis = asyncHandler(async (req, res) => {
  const resume = await Resume.findById(req.params.id);
  if (!resume) throw new AppError("Resume not found.", 404);
  if (String(resume.user) !== String(req.user._id)) {
    throw new AppError("You do not have access to this resume.", 403);
  }

  const { scores, feedback } = await scoreResume(resume.extractedText, resume.targetRole);
  const overallScore = computeOverall(scores);

  const analysis = await Analysis.create({
    user: req.user._id,
    resume: resume._id,
    overallScore,
    scores,
    feedback,
  });

  res.status(201).json({ success: true, data: { analysis: analysis.toSafeJSON() } });
});

// GET /api/analyses
const listAnalyses = asyncHandler(async (req, res) => {
  const analyses = await Analysis.find({ user: req.user._id })
    .sort({ createdAt: -1 })
    .populate("resume", "fileName targetRole");

  res.status(200).json({
    success: true,
    count: analyses.length,
    data: { analyses: analyses.map((a) => a.toSafeJSON()) },
  });
});

// GET /api/analyses/:id
const getAnalysis = asyncHandler(async (req, res) => {
  const analysis = await findOwnedAnalysis(req);
  res.status(200).json({ success: true, data: { analysis: analysis.toSafeJSON() } });
});

// PATCH /api/analyses/:id  (user-editable note only — scores are immutable)
const updateAnalysis = asyncHandler(async (req, res) => {
  const analysis = await findOwnedAnalysis(req);
  if (req.body.note !== undefined) analysis.note = req.body.note;
  await analysis.save();
  res.status(200).json({ success: true, data: { analysis: analysis.toSafeJSON() } });
});

// DELETE /api/analyses/:id
const deleteAnalysis = asyncHandler(async (req, res) => {
  const analysis = await findOwnedAnalysis(req);
  await analysis.deleteOne();
  res.status(204).send();
});

async function findOwnedAnalysis(req) {
  const analysis = await Analysis.findById(req.params.id);
  if (!analysis) throw new AppError("Analysis not found.", 404);
  if (String(analysis.user) !== String(req.user._id)) {
    throw new AppError("You do not have access to this analysis.", 403);
  }
  return analysis;
}

module.exports = { createAnalysis, listAnalyses, getAnalysis, updateAnalysis, deleteAnalysis };
