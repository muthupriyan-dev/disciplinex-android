const jwt = require("jsonwebtoken");
const AppError = require("../utils/AppError");
const asyncHandler = require("../utils/asyncHandler");
const User = require("../models/User");

/**
 * Verifies the Bearer token on the Authorization header, loads the user,
 * and attaches it to req.user. Protects any route it's applied to.
 */
const requireAuth = asyncHandler(async (req, res, next) => {
  const header = req.headers.authorization || "";
  const [scheme, token] = header.split(" ");

  if (scheme !== "Bearer" || !token) {
    throw new AppError("Authentication required. Provide a Bearer token.", 401);
  }

  let payload;
  try {
    payload = jwt.verify(token, process.env.JWT_SECRET);
  } catch (err) {
    throw new AppError("Invalid or expired token.", 401);
  }

  const user = await User.findById(payload.sub);
  if (!user) {
    throw new AppError("The user for this token no longer exists.", 401);
  }

  req.user = user;
  next();
});

module.exports = requireAuth;
