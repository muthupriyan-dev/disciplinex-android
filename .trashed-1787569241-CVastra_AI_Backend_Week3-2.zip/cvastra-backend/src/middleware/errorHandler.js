const AppError = require("../utils/AppError");

/* eslint-disable no-unused-vars */
function errorHandler(err, req, res, next) {
  let error = err;

  // Mongoose bad ObjectId
  if (err.name === "CastError") {
    error = new AppError(`Invalid ${err.path}: ${err.value}`, 400);
  }

  // Mongoose duplicate key (e.g. email already registered)
  if (err.code === 11000) {
    const field = Object.keys(err.keyValue || {})[0] || "field";
    error = new AppError(`That ${field} is already in use.`, 409);
  }

  // Mongoose validation errors
  if (err.name === "ValidationError") {
    const details = Object.values(err.errors).map((e) => ({
      field: e.path,
      message: e.message,
    }));
    error = new AppError("Validation failed.", 422, details);
  }

  const statusCode = error.statusCode || 500;
  const isOperational = error.isOperational || false;

  if (!isOperational && process.env.NODE_ENV !== "test") {
    console.error("UNEXPECTED ERROR:", err);
  }

  res.status(statusCode).json({
    success: false,
    message: isOperational ? error.message : "Something went wrong on our end.",
    ...(error.details ? { details: error.details } : {}),
  });
}

module.exports = errorHandler;
