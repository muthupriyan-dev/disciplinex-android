const { validationResult } = require("express-validator");
const AppError = require("../utils/AppError");

/**
 * Run after an express-validator chain. Collects any validation errors
 * into a single 422 response instead of letting bad input reach a controller.
 */
function validate(req, res, next) {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    const details = errors.array().map((e) => ({ field: e.path, message: e.msg }));
    return next(new AppError("Validation failed.", 422, details));
  }
  next();
}

module.exports = validate;
