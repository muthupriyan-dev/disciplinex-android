const mongoose = require("mongoose");

const resumeSchema = new mongoose.Schema(
  {
    user: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User",
      required: true,
      index: true,
    },
    fileName: {
      type: String,
      required: true,
      trim: true,
    },
    mimeType: {
      type: String,
      required: true,
      enum: ["application/pdf", "application/vnd.openxmlformats-officedocument.wordprocessingml.document"],
    },
    sizeBytes: {
      type: Number,
      required: true,
    },
    extractedText: {
      type: String,
      required: true,
    },
    targetRole: {
      type: String,
      trim: true,
      maxlength: 150,
      default: null,
    },
  },
  { timestamps: true }
);

resumeSchema.methods.toSafeJSON = function () {
  return {
    id: this._id,
    fileName: this.fileName,
    mimeType: this.mimeType,
    sizeBytes: this.sizeBytes,
    targetRole: this.targetRole,
    textPreview: this.extractedText ? this.extractedText.slice(0, 240) : "",
    createdAt: this.createdAt,
    updatedAt: this.updatedAt,
  };
};

module.exports = mongoose.model("Resume", resumeSchema);
