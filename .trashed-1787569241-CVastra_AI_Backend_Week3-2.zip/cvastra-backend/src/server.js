require("dotenv").config();
const connectDB = require("./config/db");
const createApp = require("./app");

const PORT = process.env.PORT || 5000;

async function start() {
  try {
    await connectDB(process.env.MONGO_URI);
    const app = createApp();
    app.listen(PORT, () => {
      console.log(`CVastra AI API listening on port ${PORT} [${process.env.NODE_ENV || "development"}]`);
    });
  } catch (err) {
    console.error("Failed to start server:", err);
    process.exit(1);
  }
}

start();
