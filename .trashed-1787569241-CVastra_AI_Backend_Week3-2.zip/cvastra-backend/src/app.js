const express = require("express");
const cors = require("cors");
const helmet = require("helmet");
const mongoSanitize = require("express-mongo-sanitize");

const authRoutes = require("./routes/authRoutes");
const resumeRoutes = require("./routes/resumeRoutes");
const analysisRoutes = require("./routes/analysisRoutes");
const errorHandler = require("./middleware/errorHandler");
const AppError = require("./utils/AppError");

function createApp() {
  const app = express();

  app.use(helmet());

  const allowedOrigins = (process.env.CORS_ORIGIN || "")
    .split(",")
    .map((s) => s.trim())
    .filter(Boolean);

  app.use(
    cors({
      origin: allowedOrigins.length ? allowedOrigins : "*",
      credentials: true,
    })
  );

  app.use(express.json({ limit: "1mb" }));
  app.use(mongoSanitize()); // strips $/. operators from user input to block NoSQL injection

  app.get("/api/health", (req, res) => {
    res.status(200).json({ success: true, message: "CVastra AI API is running." });
  });

  app.use("/api/auth", authRoutes);
  app.use("/api/resumes", resumeRoutes);
  app.use("/api", analysisRoutes); // exposes /api/resumes/:id/analyze and /api/analyses...

  app.use((req, res, next) => {
    next(new AppError(`No route found for ${req.method} ${req.originalUrl}`, 404));
  });

  app.use(errorHandler);

  return app;
}

module.exports = createApp;
