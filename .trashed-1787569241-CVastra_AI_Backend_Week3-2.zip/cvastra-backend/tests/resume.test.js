const request = require("supertest");
const createApp = require("../src/app");

const app = createApp();

async function signupAndGetToken() {
  const res = await request(app).post("/api/auth/signup").send({
    name: "Muthu",
    email: `user${Date.now()}@example.com`,
    password: "correcthorsebattery",
  });
  return res.body.data.token;
}

// Minimal valid PDF bytes so pdf-parse can extract at least some text-bearing structure.
const FAKE_PDF_TEXT_HEAVY = Buffer.from(
  `%PDF-1.4
1 0 obj<</Type/Catalog/Pages 2 0 R>>endobj
2 0 obj<</Type/Pages/Kids[3 0 R]/Count 1>>endobj
3 0 obj<</Type/Page/Parent 2 0 R/Resources<</Font<</F1 4 0 R>>>>/MediaBox[0 0 612 792]/Contents 5 0 R>>endobj
4 0 obj<</Type/Font/Subtype/Type1/BaseFont/Helvetica>>endobj
5 0 obj<</Length 90>>stream
BT /F1 18 Tf 50 700 Td (Experienced Frontend Developer with five years of React and TypeScript.) Tj ET
endstream
endobj
xref
0 6
trailer<</Size 6/Root 1 0 R>>
startxref
0
%%EOF`
);

describe("Resume API", () => {
  test("requires authentication", async () => {
    const res = await request(app).get("/api/resumes");
    expect(res.status).toBe(401);
  });

  test("rejects upload with no file", async () => {
    const token = await signupAndGetToken();
    const res = await request(app)
      .post("/api/resumes")
      .set("Authorization", `Bearer ${token}`);
    expect(res.status).toBe(400);
  });

  test("uploads a PDF resume, then lists / gets / updates / deletes it", async () => {
    const token = await signupAndGetToken();

    const uploadRes = await request(app)
      .post("/api/resumes")
      .set("Authorization", `Bearer ${token}`)
      .field("targetRole", "Frontend Developer")
      .attach("resume", FAKE_PDF_TEXT_HEAVY, {
        filename: "resume.pdf",
        contentType: "application/pdf",
      });

    expect(uploadRes.status).toBe(201);
    const resumeId = uploadRes.body.data.resume.id;
    expect(uploadRes.body.data.resume.targetRole).toBe("Frontend Developer");

    const listRes = await request(app)
      .get("/api/resumes")
      .set("Authorization", `Bearer ${token}`);
    expect(listRes.status).toBe(200);
    expect(listRes.body.count).toBe(1);

    const getRes = await request(app)
      .get(`/api/resumes/${resumeId}`)
      .set("Authorization", `Bearer ${token}`);
    expect(getRes.status).toBe(200);
    expect(getRes.body.data.resume.id).toBe(resumeId);

    const updateRes = await request(app)
      .put(`/api/resumes/${resumeId}`)
      .set("Authorization", `Bearer ${token}`)
      .send({ targetRole: "Senior Frontend Developer" });
    expect(updateRes.status).toBe(200);
    expect(updateRes.body.data.resume.targetRole).toBe("Senior Frontend Developer");

    const deleteRes = await request(app)
      .delete(`/api/resumes/${resumeId}`)
      .set("Authorization", `Bearer ${token}`);
    expect(deleteRes.status).toBe(204);

    const getAfterDelete = await request(app)
      .get(`/api/resumes/${resumeId}`)
      .set("Authorization", `Bearer ${token}`);
    expect(getAfterDelete.status).toBe(404);
  });

  test("a user cannot access another user's resume", async () => {
    const tokenA = await signupAndGetToken();
    const tokenB = await signupAndGetToken();

    const uploadRes = await request(app)
      .post("/api/resumes")
      .set("Authorization", `Bearer ${tokenA}`)
      .attach("resume", FAKE_PDF_TEXT_HEAVY, {
        filename: "resume.pdf",
        contentType: "application/pdf",
      });
    const resumeId = uploadRes.body.data.resume.id;

    const res = await request(app)
      .get(`/api/resumes/${resumeId}`)
      .set("Authorization", `Bearer ${tokenB}`);
    expect(res.status).toBe(403);
  });
});
