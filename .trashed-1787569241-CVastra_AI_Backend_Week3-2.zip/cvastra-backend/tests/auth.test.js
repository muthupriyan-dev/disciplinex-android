const request = require("supertest");
const createApp = require("../src/app");

const app = createApp();

describe("Auth API", () => {
  const validUser = {
    name: "Muthu",
    email: "muthu@example.com",
    password: "correcthorsebattery",
  };

  test("POST /api/auth/signup creates a user and returns a token", async () => {
    const res = await request(app).post("/api/auth/signup").send(validUser);
    expect(res.status).toBe(201);
    expect(res.body.success).toBe(true);
    expect(res.body.data.user.email).toBe(validUser.email);
    expect(res.body.data.user.passwordHash).toBeUndefined();
    expect(typeof res.body.data.token).toBe("string");
  });

  test("POST /api/auth/signup rejects a duplicate email", async () => {
    await request(app).post("/api/auth/signup").send(validUser);
    const res = await request(app).post("/api/auth/signup").send(validUser);
    expect(res.status).toBe(409);
    expect(res.body.success).toBe(false);
  });

  test("POST /api/auth/signup rejects a short password", async () => {
    const res = await request(app)
      .post("/api/auth/signup")
      .send({ ...validUser, password: "short" });
    expect(res.status).toBe(422);
    expect(res.body.details[0].field).toBe("password");
  });

  test("POST /api/auth/login succeeds with correct credentials", async () => {
    await request(app).post("/api/auth/signup").send(validUser);
    const res = await request(app)
      .post("/api/auth/login")
      .send({ email: validUser.email, password: validUser.password });
    expect(res.status).toBe(200);
    expect(typeof res.body.data.token).toBe("string");
  });

  test("POST /api/auth/login rejects wrong password", async () => {
    await request(app).post("/api/auth/signup").send(validUser);
    const res = await request(app)
      .post("/api/auth/login")
      .send({ email: validUser.email, password: "wrongpassword" });
    expect(res.status).toBe(401);
  });

  test("GET /api/auth/me requires a token", async () => {
    const res = await request(app).get("/api/auth/me");
    expect(res.status).toBe(401);
  });

  test("GET /api/auth/me returns the logged-in user with a valid token", async () => {
    const signupRes = await request(app).post("/api/auth/signup").send(validUser);
    const token = signupRes.body.data.token;

    const res = await request(app).get("/api/auth/me").set("Authorization", `Bearer ${token}`);
    expect(res.status).toBe(200);
    expect(res.body.data.user.email).toBe(validUser.email);
  });

  test("DELETE /api/auth/me deletes the account", async () => {
    const signupRes = await request(app).post("/api/auth/signup").send(validUser);
    const token = signupRes.body.data.token;

    const del = await request(app).delete("/api/auth/me").set("Authorization", `Bearer ${token}`);
    expect(del.status).toBe(204);

    const me = await request(app).get("/api/auth/me").set("Authorization", `Bearer ${token}`);
    expect(me.status).toBe(401);
  });
});
