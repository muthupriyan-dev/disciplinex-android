const request = require("supertest");
const createApp = require("../src/app");

const app = createApp();

const FAKE_PDF_TEXT_HEAVY = Buffer.from(
  `%PDF-1.4
1 0 obj<</Type/Catalog/Pages 2 0 R>>endobj
2 0 obj<</Type/Pages/Kids[3 0 R]/Count 1>>endobj
3 0 obj<</Type/Page/Parent 2 0 R/Resources<</Font<</F1 4 0 R>>>>/MediaBox[0 0 612 792]/Contents 5 0 R>>endobj
4 0 obj<</Type/Font/Subtype/Type1/BaseFont/Helvetica>>endobj
5 0 obj<</Length 90>>stream
BT /F1 18 Tf 50 700 Td (Experienced Frontend Developer with five years of React and TypeScript.) Tj ET
endstream
endobj
xref
0 6
trailer<</Size 6/Root 1 0 R>>
startxref
0
%%EOF`
);

async function signupAndUploadResume() {
  const signupRes = await request(app)
    .post("/api/auth/signup")
    .send({
      name: "Muthu",
      email: `user${Date.now()}${Math.random()}@example.com`,
      password: "correcthorsebattery",
    });
  const token = signupRes.body.data.token;

  const uploadRes = await request(app)
    .post("/api/resumes")
    .set("Authorization", `Bearer ${token}`)
    .field("targetRole", "Frontend Developer")
    .attach("resume", FAKE_PDF_TEXT_HEAVY, {
      filename: "resume.pdf",
      contentType: "application/pdf",
    });

  return { token, resumeId: uploadRes.body.data.resume.id };
}

describe("Analysis API", () => {
  test("POST /api/resumes/:id/analyze scores a resume across 7 dimensions (mock scorer, no API key)", async () => {
    const { token, resumeId } = await signupAndUploadResume();

    const res = await request(app)
      .post(`/api/resumes/${resumeId}/analyze`)
      .set("Authorization", `Bearer ${token}`);

    expect(res.status).toBe(201);
    const { analysis } = res.body.data;
    expect(typeof analysis.overallScore).toBe("number");
    expect(analysis.overallScore).toBeGreaterThanOrEqual(0);
    expect(analysis.overallScore).toBeLessThanOrEqual(100);

    const dims = ["formatting", "content", "keyword", "experience", "skills", "impact", "ats"];
    dims.forEach((d) => {
      expect(typeof analysis.scores[d]).toBe("number");
    });
    expect(Array.isArray(analysis.feedback)).toBe(true);
  });

  test("GET /api/analyses lists past analyses for the logged-in user", async () => {
    const { token, resumeId } = await signupAndUploadResume();
    await request(app)
      .post(`/api/resumes/${resumeId}/analyze`)
      .set("Authorization", `Bearer ${token}`);

    const res = await request(app).get("/api/analyses").set("Authorization", `Bearer ${token}`);
    expect(res.status).toBe(200);
    expect(res.body.count).toBe(1);
  });

  test("PATCH /api/analyses/:id updates the user note, not the scores", async () => {
    const { token, resumeId } = await signupAndUploadResume();
    const createRes = await request(app)
      .post(`/api/resumes/${resumeId}/analyze`)
      .set("Authorization", `Bearer ${token}`);
    const analysisId = createRes.body.data.analysis.id;
    const originalScore = createRes.body.data.analysis.overallScore;

    const patchRes = await request(app)
      .patch(`/api/analyses/${analysisId}`)
      .set("Authorization", `Bearer ${token}`)
      .send({ note: "Applied to three roles with this version." });

    expect(patchRes.status).toBe(200);
    expect(patchRes.body.data.analysis.note).toBe("Applied to three roles with this version.");
    expect(patchRes.body.data.analysis.overallScore).toBe(originalScore);
  });

  test("DELETE /api/analyses/:id removes the analysis", async () => {
    const { token, resumeId } = await signupAndUploadResume();
    const createRes = await request(app)
      .post(`/api/resumes/${resumeId}/analyze`)
      .set("Authorization", `Bearer ${token}`);
    const analysisId = createRes.body.data.analysis.id;

    const delRes = await request(app)
      .delete(`/api/analyses/${analysisId}`)
      .set("Authorization", `Bearer ${token}`);
    expect(delRes.status).toBe(204);

    const getRes = await request(app)
      .get(`/api/analyses/${analysisId}`)
      .set("Authorization", `Bearer ${token}`);
    expect(getRes.status).toBe(404);
  });

  test("deleting a resume cascades and removes its analyses", async () => {
    const { token, resumeId } = await signupAndUploadResume();
    const createRes = await request(app)
      .post(`/api/resumes/${resumeId}/analyze`)
      .set("Authorization", `Bearer ${token}`);
    const analysisId = createRes.body.data.analysis.id;

    await request(app)
      .delete(`/api/resumes/${resumeId}`)
      .set("Authorization", `Bearer ${token}`);

    const getRes = await request(app)
      .get(`/api/analyses/${analysisId}`)
      .set("Authorization", `Bearer ${token}`);
    expect(getRes.status).toBe(404);
  });
});
