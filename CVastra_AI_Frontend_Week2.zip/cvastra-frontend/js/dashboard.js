/**
 * dashboard.js — behavior for dashboard.html (view 2 of 3).
 */
(function () {
  const statsEl = document.getElementById("stats");
  const regionEl = document.getElementById("history-region");

  function renderStats(history) {
    if (history.length === 0) {
      statsEl.innerHTML = "";
      return;
    }
    const avg = Math.round(history.reduce((sum, r) => sum + r.overall, 0) / history.length);
    const best = Math.max(...history.map((r) => r.overall));
    statsEl.innerHTML = `
      <div class="stat-block">
        <span class="stat-num">${history.length}</span>
        <span class="stat-label">Total fittings</span>
      </div>
      <div class="stat-block">
        <span class="stat-num">${avg}</span>
        <span class="stat-label">Average score</span>
      </div>
      <div class="stat-block">
        <span class="stat-num">${best}</span>
        <span class="stat-label">Best score</span>
      </div>
    `;
  }

  function cardHTML(record) {
    const cls = scoreClass(record.overall);
    const role = record.targetRole ? `Target: ${escapeHTML(record.targetRole)}` : "No target role specified";
    return `
      <a class="swatch-card" href="detail.html?id=${encodeURIComponent(record.id)}">
        <div class="fname">${escapeHTML(record.fileName)}</div>
        <div class="role-tag">${role}</div>
        <div class="score-row">
          <span class="score-num ${cls}">${record.overall}</span>
          <span class="score-label">/ 100 overall</span>
        </div>
        <div class="date">${formatDate(record.createdAt)}</div>
      </a>
    `;
  }

  function escapeHTML(str) {
    const div = document.createElement("div");
    div.textContent = str;
    return div.innerHTML;
  }

  function renderHistory(history) {
    if (history.length === 0) {
      regionEl.innerHTML = `
        <div class="empty-state">
          <h3>No fittings yet</h3>
          <p>Upload a resume to see it measured here.</p>
          <a href="index.html" class="btn">Start your first analysis</a>
        </div>
      `;
      return;
    }
    const grid = document.createElement("div");
    grid.className = "swatch-grid";
    grid.innerHTML = history.map(cardHTML).join("");
    regionEl.innerHTML = "";
    regionEl.appendChild(grid);
  }

  async function init() {
    const history = await CVastraAPI.getHistory();
    renderStats(history);
    renderHistory(history);
  }

  init();
})();
