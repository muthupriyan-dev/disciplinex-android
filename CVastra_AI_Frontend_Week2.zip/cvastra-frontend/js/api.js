/**
 * api.js
 * ---------------------------------------------------------------------------
 * Thin client for the CVastra AI backend described in the Week 1 System
 * Architecture doc (REST API on Render, POST /api/resume/analyze, etc).
 *
 * There is no live backend wired up for this front-end-only deliverable, so
 * every function here fakes the network call (latency + realistic response
 * shape) and persists results to localStorage instead of MongoDB.
 *
 * To connect a real backend: replace the body of each function with a
 * `fetch(BASE_URL + path, ...)` call. The function signatures and return
 * shapes are already written to match what the Express API is expected to
 * return, so callers (dashboard.js, detail.js, upload flow in app.js)
 * would not need to change.
 * ---------------------------------------------------------------------------
 */

const CVastraAPI = (() => {
  const STORAGE_KEY = "cvastra_analyses";
  const BASE_URL = "https://api.cvastra.example"; // placeholder for the real Render URL

  const DIMENSIONS = [
    { key: "formatting", label: "Formatting" },
    { key: "content", label: "Content Quality" },
    { key: "keyword", label: "Keyword Match" },
    { key: "experience", label: "Experience" },
    { key: "skills", label: "Skills Relevance" },
    { key: "impact", label: "Impact / Metrics" },
    { key: "ats", label: "ATS Compatibility" },
  ];

  function readAll() {
    try {
      const raw = localStorage.getItem(STORAGE_KEY);
      return raw ? JSON.parse(raw) : [];
    } catch (e) {
      console.error("CVastraAPI: could not read storage", e);
      return [];
    }
  }

  function writeAll(list) {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(list));
  }

  function delay(ms) {
    return new Promise((resolve) => setTimeout(resolve, ms));
  }

  function randomBetween(min, max) {
    return Math.floor(Math.random() * (max - min + 1)) + min;
  }

  function generateId() {
    return "an_" + Date.now().toString(36) + Math.random().toString(36).slice(2, 8);
  }

  const FEEDBACK_POOL = [
    "Add quantifiable metrics to project bullet points (e.g. \"reduced load time by 40%\").",
    "Include more role-specific keywords for the target position.",
    "Formatting is clean and ATS-friendly — keep the single-column layout.",
    "Trim the summary section to 2-3 lines so recruiters reach experience faster.",
    "List technical skills in a scannable group rather than inline prose.",
    "Use stronger action verbs to open each bullet point.",
    "Experience section reads well but is missing measurable outcomes for the most recent role.",
    "Consider a dedicated projects section to surface relevant work not tied to employment.",
  ];

  /**
   * POST /api/resume/analyze
   * Simulates upload + text extraction + Gemini scoring + DB write.
   */
  async function analyzeResume({ fileName, targetRole }) {
    await delay(1400 + Math.random() * 600);

    const scores = {};
    DIMENSIONS.forEach((d) => {
      scores[d.key] = randomBetween(55, 96);
    });
    const overall = Math.round(
      Object.values(scores).reduce((a, b) => a + b, 0) / DIMENSIONS.length
    );

    const shuffled = [...FEEDBACK_POOL].sort(() => Math.random() - 0.5);
    const feedback = shuffled.slice(0, 4);

    const record = {
      id: generateId(),
      fileName,
      targetRole: targetRole || null,
      overall,
      scores,
      feedback,
      createdAt: new Date().toISOString(),
    };

    const all = readAll();
    all.unshift(record);
    writeAll(all);

    return record;
  }

  /** GET /api/analysis/history */
  async function getHistory() {
    await delay(250);
    return readAll();
  }

  /** GET /api/analysis/:id */
  async function getAnalysis(id) {
    await delay(200);
    return readAll().find((r) => r.id === id) || null;
  }

  /** DELETE — used by the dashboard's "remove" action (not in the original endpoint table; local convenience) */
  async function deleteAnalysis(id) {
    await delay(150);
    const all = readAll().filter((r) => r.id !== id);
    writeAll(all);
    return true;
  }

  return {
    DIMENSIONS,
    analyzeResume,
    getHistory,
    getAnalysis,
    deleteAnalysis,
  };
})();
