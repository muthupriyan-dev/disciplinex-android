/**
 * detail.js — behavior for detail.html (view 3 of 3).
 * Reads ?id= from the query string and renders one analysis record.
 */
(function () {
  const region = document.getElementById("detail-region");

  function getIdFromQuery() {
    const params = new URLSearchParams(window.location.search);
    return params.get("id");
  }

  function escapeHTML(str) {
    const div = document.createElement("div");
    div.textContent = str;
    return div.innerHTML;
  }

  function measureRowHTML(dim, value) {
    return `
      <div class="measure-row">
        <div class="m-label">${dim.label}</div>
        <div class="tape-track">
          <div class="tape-fill" style="width:${value}%;"></div>
        </div>
        <div class="m-val">${value}%</div>
      </div>
    `;
  }

  function renderRecord(record) {
    const cls = scoreClass(record.overall);
    document.title = `${record.fileName} — CVastra AI`;

    const measuresHTML = CVastraAPI.DIMENSIONS.map((d) =>
      measureRowHTML(d, record.scores[d.key])
    ).join("");

    const feedbackHTML = record.feedback.map((f) => `<li>${escapeHTML(f)}</li>`).join("");

    region.innerHTML = `
      <div class="detail-header">
        <div>
          <p style="font-family:var(--font-mono);color:var(--gold);font-size:0.8rem;letter-spacing:0.1em;text-transform:uppercase;margin-bottom:6px;">Measurements</p>
          <h1 style="font-size:2rem;margin-bottom:4px;">${escapeHTML(record.fileName)}</h1>
          <p style="color:var(--ink-soft);margin-bottom:0;">
            ${record.targetRole ? `Fitted for <strong>${escapeHTML(record.targetRole)}</strong> &middot; ` : ""}${formatDate(record.createdAt)}
          </p>
        </div>
        <span class="badge ${cls}">${record.overall >= 80 ? "Well fitted" : record.overall >= 65 ? "Needs alterations" : "Major alterations"}</span>
      </div>

      <div class="detail-grid">
        <div class="dial-panel">
          <div class="dial" style="--pct:${record.overall};">
            <span class="dial-value">${record.overall}<span class="dial-suffix">%</span></span>
          </div>
          <p class="dial-caption">Overall fit score</p>
          <div class="panel-actions">
            <button class="btn btn-block" id="print-btn">Download report</button>
            <a class="btn btn-outline btn-block" href="index.html">Re-upload a version</a>
          </div>
        </div>

        <div>
          <div class="measurements">
            <h2 style="font-size:1.1rem;margin-bottom:4px;">Seven-point breakdown</h2>
            <p style="color:var(--ink-soft);font-size:0.9rem;margin-bottom:10px;">Each measurement is scored independently, the way a tailor checks shoulders separately from sleeve length.</p>
            ${measuresHTML}
          </div>

          <div class="feedback-panel">
            <h2 style="font-size:1.1rem;">Suggested alterations</h2>
            <ul class="feedback-list">${feedbackHTML}</ul>
          </div>
        </div>
      </div>
    `;

    document.getElementById("print-btn").addEventListener("click", () => {
      window.print();
    });
  }

  function renderNotFound() {
    region.innerHTML = `
      <div class="empty-state">
        <h3>No measurements found</h3>
        <p>This analysis doesn't exist, or your local history was cleared.</p>
        <a href="index.html" class="btn">Start a new analysis</a>
      </div>
    `;
  }

  async function init() {
    const id = getIdFromQuery();
    if (!id) {
      renderNotFound();
      return;
    }
    const record = await CVastraAPI.getAnalysis(id);
    if (!record) {
      renderNotFound();
      return;
    }
    renderRecord(record);
  }

  init();
})();
