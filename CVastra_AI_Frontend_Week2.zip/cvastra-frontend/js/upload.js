/**
 * upload.js — behavior for index.html (the landing / upload view).
 */
(function () {
  const dropzone = document.getElementById("dropzone");
  const fileInput = document.getElementById("file-input");
  const browseBtn = document.getElementById("browse-btn");
  const fileNameTag = document.getElementById("file-name-tag");
  const analyzeBtn = document.getElementById("analyze-btn");
  const statusLine = document.getElementById("status-line");
  const form = document.getElementById("upload-form");
  const targetRoleInput = document.getElementById("target-role");

  let selectedFile = null;

  function setFile(file) {
    if (!file) return;
    const okType = /\.(pdf|docx)$/i.test(file.name);
    if (!okType) {
      statusLine.textContent = "Please choose a PDF or DOCX file.";
      return;
    }
    selectedFile = file;
    fileNameTag.textContent = file.name;
    fileNameTag.hidden = false;
    analyzeBtn.disabled = false;
    statusLine.textContent = "";
  }

  browseBtn.addEventListener("click", () => fileInput.click());
  fileInput.addEventListener("change", (e) => setFile(e.target.files[0]));

  ["dragenter", "dragover"].forEach((evt) => {
    dropzone.addEventListener(evt, (e) => {
      e.preventDefault();
      dropzone.classList.add("dragover");
    });
  });
  ["dragleave", "drop"].forEach((evt) => {
    dropzone.addEventListener(evt, (e) => {
      e.preventDefault();
      dropzone.classList.remove("dragover");
    });
  });
  dropzone.addEventListener("drop", (e) => {
    const file = e.dataTransfer.files && e.dataTransfer.files[0];
    setFile(file);
  });

  form.addEventListener("submit", async (e) => {
    e.preventDefault();
    if (!selectedFile) return;

    analyzeBtn.disabled = true;
    analyzeBtn.textContent = "Measuring…";
    statusLine.textContent = "Extracting text and scoring against seven dimensions…";

    try {
      const record = await CVastraAPI.analyzeResume({
        fileName: selectedFile.name,
        targetRole: targetRoleInput.value.trim(),
      });
      statusLine.textContent = "Done — opening your results.";
      window.location.href = `detail.html?id=${encodeURIComponent(record.id)}`;
    } catch (err) {
      console.error(err);
      statusLine.textContent = "Something went wrong. Please try again.";
      analyzeBtn.disabled = false;
      analyzeBtn.textContent = "Take measurements";
    }
  });
})();
