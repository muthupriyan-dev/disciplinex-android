# CVastra AI — Front-End (Week 2)

NSDC Junior Full Stack Developer Internship — Week 2 Task: Front-End Application Development.

This is the front-end for **CVastra AI**, the resume-scoring SaaS planned in the Week 1
architecture document. It implements three interconnected views and talks to a mock API
layer shaped exactly like the real backend described in that doc, so wiring up the live
Render API later is a drop-in change, not a rewrite.

## Design concept

CVastra = "CV" + *vastra* (garment/attire). The interface leans into a **tailor's workshop**
metaphor instead of generic SaaS styling: a resume is a garment being measured and altered.

- Scores are called **measurements**, not just numbers.
- The overall score is a circular **tailor's dial**, not a generic donut chart.
- Per-dimension scores are **measuring-tape bars** with tick-mark texture.
- Feedback items are **alterations**, marked with a scissors glyph instead of a bullet.
- History cards on the dashboard are **fabric swatches** with pinked (zigzag-cut) edges.
- Section dividers are dashed **stitch lines**.

**Palette:** ink navy `#1B2A41`, parchment `#F3ECDC`, thread-gold `#B8863B`,
chalk-red `#B4462F` (low scores), sage `#5F7D5E` (high scores).

**Type:** Fraunces (display/headlines), Inter (body/UI), IBM Plex Mono (scores and
data — a monospace face reads like measurements on a tape).

## Views

| Page | File | Purpose |
|---|---|---|
| Landing / Upload | `index.html` | Hero, drag-and-drop resume upload, optional target role, "how it works" |
| Dashboard | `dashboard.html` | Summary stats + history of past analyses as swatch cards |
| Detail | `detail.html` | One analysis: overall score dial, 7-dimension breakdown, feedback list |

Navigation between all three is via the header nav (persistent across pages) and
in-page links (e.g. a dashboard card links to its own detail view; the detail view's
"Re-upload a version" links back to the upload page).

## Tech stack / patterns

- **No framework** — plain HTML, CSS, and vanilla ES6 JavaScript, matching the stack
  the real CVastra AI backend already expects (kept consistent with the Week 1 doc's
  choice of a vanilla-JS frontend on Netlify) and with a phone-only, no-build-step
  development workflow.
- **Multi-page site**, not a client-side-routed SPA — each view is its own HTML file.
  This keeps the mental model simple, deploys to Netlify with zero configuration, and
  means any single view can be opened directly by URL (including the detail view's
  `?id=` deep link).
- **Mock API layer** (`js/api.js`) — an IIFE module (`CVastraAPI`) exposing
  `analyzeResume()`, `getHistory()`, `getAnalysis(id)`, `deleteAnalysis(id)`. Each
  function fakes network latency and persists to `localStorage` instead of MongoDB.
  Function names and return shapes mirror the REST endpoints from the Week 1 API
  table (`POST /api/resume/analyze`, `GET /api/analysis/history`,
  `GET /api/analysis/:id`) so swapping in real `fetch()` calls later doesn't change
  any calling code in `upload.js`, `dashboard.js`, or `detail.js`.
- **Separation of concerns** — one JS file per page (`upload.js`, `dashboard.js`,
  `detail.js`) plus shared utilities (`app.js`) and the API layer (`api.js`), all
  loaded as plain `<script>` tags (no bundler needed).
- **Design tokens in CSS custom properties** (`:root` in `css/styles.css`) — color,
  font, and layout values are defined once and reused, so the theme can be retuned
  from one place.

## Accessibility

- Skip-to-content link on every page.
- Semantic landmarks (`header`, `nav`, `main`, `footer`) and one `h1` per page.
- Visible focus states via `:focus-visible` (not suppressed).
- `aria-live="polite"` regions for the upload status line, dashboard history, and
  detail view, so screen reader users hear async updates.
- `aria-expanded` / `aria-controls` on the mobile nav toggle.
- `prefers-reduced-motion` respected — transitions are disabled for users who request it.
- Decorative SVG icons marked `aria-hidden="true"`.

## Responsiveness

Mobile-first CSS with breakpoints at `720px` (nav collapses to a toggle menu, the
3-column "how it works" steps and detail view stack to one column) and
`820px`/`900px` for the detail and card grids. Tested down to a 375px viewport.

## Running locally

No build step and no dependencies to install. From the project folder:

```bash
# any static file server works, for example:
python3 -m http.server 8000
# then open http://localhost:8000/index.html
```

Or, since it's fully static, you can open `index.html` directly in a browser —
everything except the two Google Fonts (which need network access) will still work.

To deploy: upload this folder to GitHub and connect it to Netlify (matches the
Week 1 deployment plan) — no build command is needed since there's no bundling step.

## Connecting the real backend

Everything currently goes through `js/api.js`. To point it at the live Express API
on Render instead of `localStorage`:

1. Set `BASE_URL` in `api.js` to the real Render URL.
2. Replace the body of each function (`analyzeResume`, `getHistory`, `getAnalysis`,
   `deleteAnalysis`) with a `fetch()` call to the matching endpoint from the Week 1
   API table, keeping the same return shape.
3. No changes are needed in `upload.js`, `dashboard.js`, or `detail.js` — they only
   ever call `CVastraAPI.*`, never `localStorage` directly.

## Known limitations (by design, for this deliverable)

- Scoring is randomly generated per upload (55-96 per dimension) since there's no
  live Gemini integration wired into this front-end-only submission.
- Auth (signup/login from the Week 1 plan) isn't implemented yet — history is scoped
  to the browser's `localStorage`, not a per-user account.
- "Download report" on the detail view triggers the browser print dialog as a
  stand-in for a generated PDF.
