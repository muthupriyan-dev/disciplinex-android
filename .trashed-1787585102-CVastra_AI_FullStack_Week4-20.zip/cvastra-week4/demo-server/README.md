# CVastra AI — Demo Server (integration testing aid, not the graded backend)

A dependency-free Node.js server (`server.js`, core `http`/`crypto` modules
only — no `npm install` needed) that implements the **same route contract**
as the real backend in `../backend` — see `../backend/API_DOCUMENTATION.md`.

## Why this exists

The real backend needs `npm install` (Express, Mongoose, bcrypt, Multer,
pdf-parse...) and a MongoDB connection. This project was built in a sandboxed
environment with no network access to the npm registry, so those couldn't be
installed there to prove the integration actually works end-to-end.

This server exists to let the real front-end talk to a real, running server
anywhere Node is available — no install step, no database — so the
integration could be tested by actually running it, not just by inspection.
`../demo/cvastra-integration-demo.webm` was recorded against this server.

**The graded submission is `../backend`.** This is a testing aid.

## Run it

```bash
node server.js
# listens on http://localhost:5000 by default (set DEMO_PORT to change)
```

Then serve `../frontend` and open `index.html` — its API base meta tag
already points at `http://localhost:5000/api`.

## Differences from the real backend

| | Real backend (`../backend`) | Demo server (this folder) |
|---|---|---|
| Dependencies | Express, Mongoose, bcrypt, Multer, pdf-parse, mammoth, jsonwebtoken... | none (Node core only) |
| Database | MongoDB (persistent) | in-memory array (resets on restart) |
| Auth tokens | real JWT (`jsonwebtoken`) | HMAC-signed JSON, same shape/behavior, hand-rolled |
| Password hashing | bcrypt | `crypto.scryptSync` |
| PDF/DOCX text extraction | `pdf-parse` / `mammoth` (real parsing) | strips non-printable bytes from the raw upload — a stand-in, not real parsing |
| AI scoring | Gemini API, or deterministic mock if no key | same deterministic mock algorithm, always |
| Route contract | — | **identical** — same paths, methods, request/response JSON shapes |
