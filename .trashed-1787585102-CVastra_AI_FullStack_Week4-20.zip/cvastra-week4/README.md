# CVastra AI — Full-Stack Integration (Week 4)

NSDC Junior Full Stack Developer Internship — Week 4 Task: Integrating Front-End
with Back-End.

This connects the Week 2 front-end to the Week 3 backend: real `fetch()` calls
replace the old `localStorage` mock, a login/signup flow was added (the backend
requires a JWT on every data route), and every page now handles loading and
error states from a live server instead of assuming success.

## What's in this folder

```
cvastra-week4/
  frontend/       Week 2 front-end, updated to call the real API (see below)
  backend/        Week 3 Express + MongoDB API, unchanged except one small
                   fix (see "Changes made during integration")
  demo-server/    A dependency-free stand-in backend — see "Two ways to run this"
  demo/
    cvastra-integration-demo.webm   Screen recording of the real, running app
  README.md        this file
```

## Two ways to run this

### Option A — the real backend (this is the graded submission)

Requires Node 18+ and a MongoDB connection.

```bash
cd backend
npm install
cp .env.example .env      # set MONGO_URI and JWT_SECRET at minimum
npm run dev                # starts on http://localhost:5000
```

```bash
cd frontend
python3 -m http.server 8791   # or any static file server
# open http://localhost:8791/index.html
```

The front-end's API base URL is set via a meta tag in each HTML file:
```html
<meta name="cvastra-api-base" content="http://localhost:5000/api">
```
Change it if your backend runs on a different port, or edit `CORS_ORIGIN` in
the backend's `.env` to match wherever the front-end is served from.

### Option B — the zero-dependency demo server

`npm install` needs registry access, which isn't available in every
environment (including the sandbox this was built in — see "Challenges" below).
`demo-server/server.js` implements the **identical route contract** — same
paths, methods, request/response shapes documented in
`backend/API_DOCUMENTATION.md` — using only Node's built-in `http` and `crypto`
modules. No install step, no database.

```bash
cd demo-server
node server.js              # starts on http://localhost:5000, no npm install needed
```

Then serve `frontend/` the same way as Option A. This is what
`demo/cvastra-integration-demo.webm` was recorded against — a real server,
really running, not a mockup.

**This is not the graded backend.** It exists so the integration can be
verified end-to-end (and recorded) anywhere, including offline. The actual
submission is the Express/MongoDB backend in `backend/`.

## What changed on the front-end for integration

- **`js/api.js`** — completely rewritten. Every function now makes a real
  `fetch()` call instead of reading/writing `localStorage`, and throws a typed
  `ApiError` (with `.status`) so pages can branch on status codes.
- **`js/auth.js`** (new) — token storage, a `requireAuthOrRedirect()` guard
  used at the top of every protected page, and the nav's login/logout state.
- **`login.html` + `js/login.js`** (new) — the backend requires a JWT for
  every route except signup/login, and Week 2's front-end had no auth UI at
  all. This was the single biggest gap to close for integration.
- **`js/upload.js`** — now a two-step flow matching the real API: `POST
  /api/resumes` (upload) then `POST /api/resumes/:id/analyze` (score),
  instead of one mock call. Shows distinct status text for each step.
- **`js/dashboard.js` / `js/detail.js`** — updated to the real response
  shape (`overallScore` instead of `overall`, resume `fileName`/`targetRole`
  nested under a populated `resume` field instead of flat on the record), and
  render an `error-banner` instead of silently failing when a request errors.
- Every protected page now redirects to `login.html?next=<page>` if there's
  no token, and back to the originally-requested page after login/signup.

## Changes made during integration (backend side)

- `GET /api/analyses/:id` didn't populate the `resume` field the way `GET
  /api/analyses` (list) already did, so the detail page had no `fileName` to
  show for a single analysis. Fixed by adding the same `.populate("resume",
  "fileName targetRole")` call used in the list endpoint.
- `.env.example`'s `CORS_ORIGIN` example now includes the local dev port the
  front-end actually runs on (`8791`), not just a generic placeholder.

This is exactly the kind of mismatch this week's task description points at:
the two sides were each internally consistent but hadn't been run against
each other until now, and this was the one seam that broke.

## Testing the integration

1. Automated: an end-to-end Playwright script drove the real browser through
   signup → upload → analyze → dashboard → detail → logout against the demo
   server, asserting on URL transitions, DOM content (7 measurement rows,
   swatch card count, dial score), and zero unexpected console errors. This
   is what `demo/cvastra-integration-demo.webm` is a recording of.
2. Manual: the same flow via `curl` directly against both the demo server and
   (separately) the real Express backend, confirming identical response
   shapes for signup, upload, analyze, and history.

## Challenges and solutions

**Response shape mismatch (resume flat vs. nested).**
The Week 2 mock stored `fileName`/`targetRole` directly on the analysis
record. The real backend nests them under a populated `resume` object.
`dashboard.js` and `detail.js` were updated to read `record.resume.fileName`
with a fallback, and the backend's `getAnalysis` was fixed to populate
consistently with `listAnalyses` (see above).

**No auth UI existed yet.**
Week 2 didn't need login, since everything was local. Week 3's API requires a
Bearer token on every data route. Solution: added `login.html`, `js/login.js`,
and `js/auth.js` as a small, focused addition rather than restructuring the
existing three views — the upload/dashboard/detail pages only needed a guard
clause and a token-aware fetch wrapper, not a rewrite.

**Two-step upload vs. one-step mock.**
The Week 2 mock scored a resume in a single fake call. The real API separates
"create a resume" from "analyze it," matching proper REST resource semantics
(a resume can exist and be re-analyzed later without re-uploading). `upload.js`
now chains `uploadResume()` → `analyzeResume(resume.id)` and shows the user
which step is in progress.

**No network access in the build environment for `npm install`.**
The sandbox this was built in blocks the npm registry, so the real
Express/Mongoose backend's dependencies can't be installed or its test suite
run here (this limitation is documented in `backend/README.md` too — code was
syntax-checked with `node --check` but not executed). Rather than submit an
integration that was only ever proven on paper, the dependency-free demo
server was built specifically to let the *actual* front-end talk to an
*actual* running server in this environment, so the integration bugs above
(the resume-populate mismatch, the response shape differences) were caught by
running the app, not by inspection. Swapping `demo-server/` for `backend/` in
Option A is a one-line change (the API base meta tag / `CORS_ORIGIN`) because
both implement the same contract.

## Known limitations

- The demo server's "text extraction" is a stand-in (strips non-printable
  bytes from the raw file) since it has no `pdf-parse`/`mammoth` dependency —
  the real backend does proper PDF/DOCX text extraction.
- The demo server's data is in-memory and resets on restart; the real backend
  persists to MongoDB.
- Scoring in both is the deterministic mock algorithm (no `GEMINI_API_KEY`
  configured) — see `backend/README.md` for how real Gemini scoring is wired
  in when a key is available.
