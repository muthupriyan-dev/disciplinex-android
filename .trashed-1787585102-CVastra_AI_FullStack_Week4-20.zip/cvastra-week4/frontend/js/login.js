/**
 * login.js — behavior for login.html.
 */
(function () {
  const tabLogin = document.getElementById("tab-login");
  const tabSignup = document.getElementById("tab-signup");
  const loginForm = document.getElementById("login-form");
  const signupForm = document.getElementById("signup-form");
  const errorBox = document.getElementById("form-error");

  function showTab(which) {
    const isLogin = which === "login";
    tabLogin.setAttribute("aria-selected", String(isLogin));
    tabSignup.setAttribute("aria-selected", String(!isLogin));
    loginForm.hidden = !isLogin;
    signupForm.hidden = isLogin;
    errorBox.hidden = true;
  }

  tabLogin.addEventListener("click", () => showTab("login"));
  tabSignup.addEventListener("click", () => showTab("signup"));

  function getNextUrl() {
    const params = new URLSearchParams(window.location.search);
    return params.get("next") || "dashboard.html";
  }

  function showError(err) {
    errorBox.textContent =
      err.status === 0
        ? "Could not reach the CVastra API. Make sure the backend is running (see README)."
        : err.message || "Something went wrong.";
    errorBox.hidden = false;
  }

  loginForm.addEventListener("submit", async (e) => {
    e.preventDefault();
    errorBox.hidden = true;
    const submitBtn = document.getElementById("login-submit");
    submitBtn.disabled = true;
    submitBtn.textContent = "Logging in…";
    try {
      const { user, token } = await CVastraAPI.login(
        document.getElementById("login-email").value.trim(),
        document.getElementById("login-password").value
      );
      CVastraAuth.setSession(token, user);
      window.location.href = getNextUrl();
    } catch (err) {
      showError(err);
      submitBtn.disabled = false;
      submitBtn.textContent = "Log in";
    }
  });

  signupForm.addEventListener("submit", async (e) => {
    e.preventDefault();
    errorBox.hidden = true;
    const submitBtn = document.getElementById("signup-submit");
    submitBtn.disabled = true;
    submitBtn.textContent = "Creating account…";
    try {
      const { user, token } = await CVastraAPI.signup(
        document.getElementById("signup-name").value.trim(),
        document.getElementById("signup-email").value.trim(),
        document.getElementById("signup-password").value
      );
      CVastraAuth.setSession(token, user);
      window.location.href = getNextUrl();
    } catch (err) {
      showError(err);
      submitBtn.disabled = false;
      submitBtn.textContent = "Create account";
    }
  });

  // If already logged in, skip straight through.
  if (CVastraAuth.isLoggedIn()) {
    window.location.href = getNextUrl();
  }
})();
