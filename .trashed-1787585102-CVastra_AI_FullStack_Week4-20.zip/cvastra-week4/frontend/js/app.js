/**
 * app.js — shared across all pages.
 * Handles the mobile nav toggle and a couple of formatting helpers reused
 * by dashboard.js and detail.js.
 */

document.addEventListener("DOMContentLoaded", () => {
  const toggle = document.querySelector(".nav-toggle");
  const nav = document.querySelector(".main-nav");
  if (toggle && nav) {
    toggle.addEventListener("click", () => {
      const isOpen = nav.classList.toggle("open");
      toggle.setAttribute("aria-expanded", String(isOpen));
    });
  }
});

function scoreClass(value) {
  if (value >= 80) return "score-good";
  if (value >= 65) return "score-mid";
  return "score-low";
}

function formatDate(iso) {
  const d = new Date(iso);
  return d.toLocaleDateString(undefined, { year: "numeric", month: "short", day: "numeric" });
}
