/**
 * api.js — real HTTP client for the CVastra AI backend (Week 3 Express API,
 * or the dependency-free demo-server that mirrors the same contract).
 *
 * Replaces the Week 2 localStorage mock. Every function throws an ApiError
 * (with .status and .payload) on failure so callers can branch on status
 * codes (401 -> redirect to login, 403/404 -> friendly message, etc).
 *
 * Base URL is configurable via a <meta name="cvastra-api-base" content="...">
 * tag so the same static files can point at localhost during development
 * and at the deployed Render URL in production, with no code changes.
 */

class ApiError extends Error {
  constructor(message, status, payload) {
    super(message);
    this.status = status;
    this.payload = payload;
  }
}

const CVastraAPI = (() => {
  const DIMENSIONS = [
    { key: "formatting", label: "Formatting" },
    { key: "content", label: "Content Quality" },
    { key: "keyword", label: "Keyword Match" },
    { key: "experience", label: "Experience" },
    { key: "skills", label: "Skills Relevance" },
    { key: "impact", label: "Impact / Metrics" },
    { key: "ats", label: "ATS Compatibility" },
  ];

  function baseURL() {
    const meta = document.querySelector('meta[name="cvastra-api-base"]');
    return (meta && meta.content) || "http://localhost:5000/api";
  }

  async function request(path, { method = "GET", body, isForm = false } = {}) {
    const headers = {};
    const token = CVastraAuth.getToken();
    if (token) headers.Authorization = `Bearer ${token}`;
    if (!isForm && body !== undefined) headers["Content-Type"] = "application/json";

    let response;
    try {
      response = await fetch(`${baseURL()}${path}`, {
        method,
        headers,
        body: isForm ? body : body !== undefined ? JSON.stringify(body) : undefined,
      });
    } catch (networkErr) {
      throw new ApiError(
        "Could not reach the CVastra API. Is the backend running?",
        0,
        null
      );
    }

    let payload = null;
    const text = await response.text();
    if (text) {
      try {
        payload = JSON.parse(text);
      } catch (e) {
        payload = null;
      }
    }

    if (!response.ok) {
      const message = (payload && payload.message) || `Request failed (${response.status})`;
      throw new ApiError(message, response.status, payload);
    }

    return payload;
  }

  // ---- Auth ----
  async function signup(name, email, password) {
    const res = await request("/auth/signup", { method: "POST", body: { name, email, password } });
    return res.data;
  }
  async function login(email, password) {
    const res = await request("/auth/login", { method: "POST", body: { email, password } });
    return res.data;
  }
  async function getMe() {
    const res = await request("/auth/me");
    return res.data.user;
  }

  // ---- Resumes ----
  async function uploadResume(file, targetRole) {
    const form = new FormData();
    form.append("resume", file);
    if (targetRole) form.append("targetRole", targetRole);
    const res = await request("/resumes", { method: "POST", body: form, isForm: true });
    return res.data.resume;
  }
  async function listResumes() {
    const res = await request("/resumes");
    return res.data.resumes;
  }

  // ---- Analyses ----
  async function analyzeResume(resumeId) {
    const res = await request(`/resumes/${resumeId}/analyze`, { method: "POST" });
    return res.data.analysis;
  }
  async function getHistory() {
    const res = await request("/analyses");
    return res.data.analyses;
  }
  async function getAnalysis(id) {
    const res = await request(`/analyses/${id}`);
    return res.data.analysis;
  }
  async function deleteAnalysis(id) {
    await request(`/analyses/${id}`, { method: "DELETE" });
    return true;
  }

  /** Convenience: upload + analyze in one call, used by the upload page. */
  async function uploadAndAnalyze(file, targetRole) {
    const resume = await uploadResume(file, targetRole);
    const analysis = await analyzeResume(resume.id);
    return analysis;
  }

  return {
    DIMENSIONS,
    signup,
    login,
    getMe,
    uploadResume,
    listResumes,
    analyzeResume,
    getHistory,
    getAnalysis,
    deleteAnalysis,
    uploadAndAnalyze,
  };
})();
