/**
 * auth.js — shared token storage + fetch helper, used by every page.
 *
 * The backend from Week 3 requires a Bearer JWT on every route except
 * /api/auth/signup, /api/auth/login, and /api/health. This module is the
 * single place that knows about the token so upload.js / dashboard.js /
 * detail.js never touch localStorage directly.
 */

const CVastraAuth = (() => {
  const TOKEN_KEY = "cvastra_token";
  const USER_KEY = "cvastra_user";

  function getToken() {
    return localStorage.getItem(TOKEN_KEY);
  }

  function getUser() {
    try {
      const raw = localStorage.getItem(USER_KEY);
      return raw ? JSON.parse(raw) : null;
    } catch (e) {
      return null;
    }
  }

  function setSession(token, user) {
    localStorage.setItem(TOKEN_KEY, token);
    localStorage.setItem(USER_KEY, JSON.stringify(user));
  }

  function clearSession() {
    localStorage.removeItem(TOKEN_KEY);
    localStorage.removeItem(USER_KEY);
  }

  function isLoggedIn() {
    return !!getToken();
  }

  /** Redirects to login.html if there's no token. Call at the top of protected pages. */
  function requireAuthOrRedirect() {
    if (!isLoggedIn()) {
      const next = encodeURIComponent(window.location.pathname + window.location.search);
      window.location.href = `login.html?next=${next}`;
      return false;
    }
    return true;
  }

  function logout() {
    clearSession();
    window.location.href = "login.html";
  }

  return { getToken, getUser, setSession, clearSession, isLoggedIn, requireAuthOrRedirect, logout };
})();

/**
 * Renders the "Login" link vs. "Hi, <name> · Logout" state in the header nav.
 * Every page includes a <span id="auth-slot"></span> in its nav for this.
 */
function renderAuthSlot() {
  const slot = document.getElementById("auth-slot");
  if (!slot) return;

  if (CVastraAuth.isLoggedIn()) {
    const user = CVastraAuth.getUser();
    slot.innerHTML = `
      <span class="nav-user">Hi, ${user ? escapeHTMLLocal(user.name) : "there"}</span>
      <button type="button" class="nav-logout" id="logout-btn">Logout</button>
    `;
    document.getElementById("logout-btn").addEventListener("click", CVastraAuth.logout);
  } else {
    slot.innerHTML = `<a href="login.html">Login</a>`;
  }
}

function escapeHTMLLocal(str) {
  const div = document.createElement("div");
  div.textContent = str;
  return div.innerHTML;
}

document.addEventListener("DOMContentLoaded", renderAuthSlot);
