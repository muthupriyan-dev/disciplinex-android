# CVastra AI — Front-End

> **Week 4 update:** this now talks to a real backend over HTTP — see the
> top-level `../README.md` for the integration notes, what changed, and how
> to run the whole stack together. This file covers the front-end on its own.

NSDC Junior Full Stack Developer Internship — originally built Week 2, wired
to the live API in Week 4.

## Design concept

CVastra = "CV" + *vastra* (garment/attire). The interface leans into a **tailor's workshop**
metaphor instead of generic SaaS styling: a resume is a garment being measured and altered.

- Scores are called **measurements**, not just numbers.
- The overall score is a circular **tailor's dial**, not a generic donut chart.
- Per-dimension scores are **measuring-tape bars** with tick-mark texture.
- Feedback items are **alterations**, marked with a scissors glyph instead of a bullet.
- History cards on the dashboard are **fabric swatches** with pinked (zigzag-cut) edges.
- Section dividers are dashed **stitch lines**.

**Palette:** ink navy `#1B2A41`, parchment `#F3ECDC`, thread-gold `#B8863B`,
chalk-red `#B4462F` (low scores), sage `#5F7D5E` (high scores).

**Type:** Fraunces (display/headlines), Inter (body/UI), IBM Plex Mono (scores and
data — a monospace face reads like measurements on a tape).

## Views

| Page | File | Purpose |
|---|---|---|
| Login / Signup | `login.html` | Auth — required before any other page will load |
| Landing / Upload | `index.html` | Hero, drag-and-drop resume upload, optional target role |
| Dashboard | `dashboard.html` | Summary stats + history of past analyses as swatch cards |
| Detail | `detail.html` | One analysis: overall score dial, 7-dimension breakdown, feedback list |

Every page except `login.html` calls `CVastraAuth.requireAuthOrRedirect()` on
load, which bounces to `login.html?next=<page>` if there's no token, and back
to the originally-requested page after a successful login/signup.

## Tech stack / patterns

- **No framework** — plain HTML, CSS, and vanilla ES6 JavaScript, matching the
  real CVastra AI backend's expectations and a phone-only, no-build-step
  development workflow.
- **Multi-page site**, not a client-side-routed SPA — each view is its own
  HTML file, deploys to Netlify with zero configuration, and any view can be
  opened directly by URL (including the detail view's `?id=` deep link).
- **`js/api.js`** — a real HTTP client (`CVastraAPI`). Every function calls
  `fetch()` against the backend and throws a typed `ApiError` (carrying
  `.status`) on failure, so callers can branch (401 → force logout, 403/404 →
  friendly message, 0 → "can't reach the API").
- **`js/auth.js`** — token storage (`localStorage`), the auth guard, and the
  nav's login/logout state (`renderAuthSlot()`), shared by every page.
- The API's base URL is configurable per-deployment via a meta tag, not
  hardcoded:
  ```html
  <meta name="cvastra-api-base" content="http://localhost:5000/api">
  ```
- **Separation of concerns** — one JS file per page (`login.js`, `upload.js`,
  `dashboard.js`, `detail.js`) plus shared utilities (`app.js`, `auth.js`) and
  the API layer (`api.js`), all loaded as plain `<script>` tags.
- **Design tokens in CSS custom properties** (`:root` in `css/styles.css`).

## Accessibility

- Skip-to-content link on every page.
- Semantic landmarks (`header`, `nav`, `main`, `footer`) and one `h1` per page.
- Visible focus states via `:focus-visible` (not suppressed).
- `aria-live="polite"` regions for async status/history/detail/error content.
- `aria-expanded` / `aria-controls` on the mobile nav toggle.
- `prefers-reduced-motion` respected.
- Decorative SVG icons marked `aria-hidden="true"`.

## Responsiveness

Mobile-first CSS with breakpoints at `720px` (nav collapses to a toggle menu)
and `820px`/`900px` for detail/card grids. Tested down to a 375px viewport.

## Running locally

See the top-level `../README.md` for the full setup (it needs a backend
running too — either the real one in `../backend` or the dependency-free
`../demo-server` for a no-install option). For the front-end alone:

```bash
python3 -m http.server 8791
# open http://localhost:8791/login.html
```

## Known limitations (by design)

- "Download report" on the detail view triggers the browser print dialog as a
  stand-in for a generated PDF.
- Deleting an analysis from the detail view has no undo (a confirm dialog
  guards it).
