# InstaDecode — Phase 1: Authentication System

## What's in this phase
Complete backend authentication system:
- Instagram OAuth login (official Meta Graph API flow — no password ever asked)
- JWT access + refresh tokens, stored in httpOnly cookies
- Multi-account support (one platform user can link several Instagram accounts)
- Session management (logout revokes just that session, not all devices)
- Encrypted-at-rest storage of Instagram access tokens (AES-256-GCM)
- `/api/auth/me` for profile info fetching
- Rate limiting + Helmet security headers already wired in

## Important: Instagram API reality check
The Instagram Graph API (the only *legitimate* OAuth-based API) only exposes
data about **the account that logs in** — its own id, username, account type,
media count. It does **not** provide:
- Any other account's follower/following list
- "Who unfollowed me" / "who doesn't follow back"
- Any private data without that account's own consent

Phase 3 (Followers Analysis) will use clearly-labeled **demo data** for those
specific screens, since real per-follower data isn't available through any
policy-compliant API. Everything else (dashboard, engagement, health score,
AI features, reports) uses real Graph API data once you connect a
Business/Creator account.

## One-time setup: Meta App (do this from your phone browser)
1. Go to developers.facebook.com → My Apps → Create App → type "Consumer".
2. Add the "Instagram Basic Display" or "Instagram Graph API" product.
3. Under Settings → Basic, copy **App ID** and **App Secret**.
4. Add a Valid OAuth Redirect URI:
   `https://<your-render-backend>.onrender.com/api/auth/instagram/callback`
5. Add yourself as an Instagram Tester (Roles → Roles) if the app is in
   Development mode — your own account must accept the tester invite in the
   Instagram app under Settings → Apps and Websites → Tester Invites.

## Deploying (GitHub browser upload → Render)
1. Create a new GitHub repo, e.g. `instadecode-backend`.
2. Use "Add file → Upload files" on GitHub web, drag this whole
   `instadecode-backend` folder in (GitHub preserves the folder structure).
3. On Render: New → Web Service → connect the repo.
   - Build command: `npm install && npm run build`
   - Start command: `npm start`
4. In Render's Environment tab, add every variable from `.env.example` with
   your real values (App ID, App Secret, Mongo URI from Atlas, JWT secrets —
   generate random ones, e.g. via `openssl rand -hex 32` or any online
   generator).
5. Deploy. Check `https://<your-service>.onrender.com/api/health` — should
   return a JSON success message.

## Next
Phase 2 (Analytics Dashboard) will consume `/api/auth/me` and start pulling
real Instagram Insights data. Let me know when you're ready and I'll build
the frontend auth pages (Login, Settings) + the analytics dashboard next.
