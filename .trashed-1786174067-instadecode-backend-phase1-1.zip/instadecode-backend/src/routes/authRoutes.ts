import { Router } from "express";
import rateLimit from "express-rate-limit";
import { requireAuth } from "../middleware/auth";
import {
  startInstagramAuth,
  instagramCallback,
  refreshSession,
  logout,
  getCurrentUser,
  switchAccount,
  unlinkAccount,
} from "../controllers/authController";

const router = Router();

// Prevent abuse of the OAuth entry point
const authLimiter = rateLimit({ windowMs: 15 * 60 * 1000, max: 20 });

router.get("/instagram", authLimiter, startInstagramAuth);
router.get("/instagram/callback", authLimiter, instagramCallback);
router.post("/refresh", refreshSession);
router.post("/logout", requireAuth, logout);
router.get("/me", requireAuth, getCurrentUser);
router.post("/switch-account", requireAuth, switchAccount);
router.delete("/accounts/:accountId", requireAuth, unlinkAccount);

export default router;
