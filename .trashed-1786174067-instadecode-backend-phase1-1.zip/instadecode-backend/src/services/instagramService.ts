import axios from "axios";
import { logger } from "../utils/logger";

const GRAPH_BASE = "https://graph.facebook.com/v19.0";
const IG_OAUTH_BASE = "https://api.instagram.com/oauth";

export interface IGShortLivedTokenResponse {
  access_token: string;
  user_id: string;
}

export interface IGLongLivedTokenResponse {
  access_token: string;
  token_type: string;
  expires_in: number; // seconds, ~60 days
}

export interface IGProfile {
  id: string;
  username: string;
  account_type: "PERSONAL" | "BUSINESS" | "MEDIA_CREATOR";
  media_count?: number;
  name?: string;
  profile_picture_url?: string;
}

/**
 * Step 1: Exchange the OAuth "code" (from the redirect) for a short-lived access token.
 */
export const exchangeCodeForToken = async (code: string): Promise<IGShortLivedTokenResponse> => {
  const params = new URLSearchParams({
    client_id: process.env.IG_APP_ID as string,
    client_secret: process.env.IG_APP_SECRET as string,
    grant_type: "authorization_code",
    redirect_uri: process.env.IG_REDIRECT_URI as string,
    code,
  });

  const { data } = await axios.post(`${IG_OAUTH_BASE}/access_token`, params);
  return data;
};

/**
 * Step 2: Exchange the short-lived token for a long-lived token (~60 days validity).
 */
export const getLongLivedToken = async (shortLivedToken: string): Promise<IGLongLivedTokenResponse> => {
  const { data } = await axios.get(`${GRAPH_BASE}/access_token`, {
    params: {
      grant_type: "ig_exchange_token",
      client_secret: process.env.IG_APP_SECRET,
      access_token: shortLivedToken,
    },
  });
  return data;
};

/**
 * Step 3: Fetch the connected profile's basic public info.
 * Note: Graph API only exposes the authenticated account's own fields here
 * (id, username, account_type, media_count) — no third-party follower lists.
 */
export const fetchInstagramProfile = async (accessToken: string): Promise<IGProfile> => {
  const { data } = await axios.get(`https://graph.instagram.com/me`, {
    params: {
      fields: "id,username,account_type,media_count",
      access_token: accessToken,
    },
  });
  return data;
};

/**
 * Refreshes a long-lived token before it expires (call via cron, see jobs/tokenRefresh.ts).
 */
export const refreshLongLivedToken = async (currentToken: string): Promise<IGLongLivedTokenResponse> => {
  const { data } = await axios.get(`${GRAPH_BASE}/refresh_access_token`, {
    params: {
      grant_type: "ig_refresh_token",
      access_token: currentToken,
    },
  });
  return data;
};

export const getInstagramAuthUrl = (): string => {
  const params = new URLSearchParams({
    client_id: process.env.IG_APP_ID as string,
    redirect_uri: process.env.IG_REDIRECT_URI as string,
    scope: "user_profile,user_media",
    response_type: "code",
  });
  return `https://api.instagram.com/oauth/authorize?${params.toString()}`;
};
