import { Response } from "express";
import crypto from "crypto";
import User from "../models/User";
import Account from "../models/Account";
import { AuthRequest } from "../middleware/auth";
import { AppError } from "../middleware/errorHandler";
import {
  exchangeCodeForToken,
  getLongLivedToken,
  fetchInstagramProfile,
  getInstagramAuthUrl,
} from "../services/instagramService";
import { encryptToken, decryptToken } from "../utils/encryption";
import { generateAccessToken, generateRefreshToken, verifyRefreshToken } from "../utils/jwt";
import { logger } from "../utils/logger";

const COOKIE_OPTIONS = {
  httpOnly: true,
  secure: process.env.NODE_ENV === "production",
  sameSite: "lax" as const,
};

// GET /api/auth/instagram
export const startInstagramAuth = (req: AuthRequest, res: Response) => {
  const url = getInstagramAuthUrl();
  res.redirect(url);
};

// GET /api/auth/instagram/callback
export const instagramCallback = async (req: AuthRequest, res: Response) => {
  const { code } = req.query;
  if (!code || typeof code !== "string") {
    throw new AppError("Missing authorization code", 400);
  }

  // Step 1: short-lived token
  const shortLived = await exchangeCodeForToken(code);

  // Step 2: long-lived token (~60 days)
  const longLived = await getLongLivedToken(shortLived.access_token);

  // Step 3: fetch the connected profile
  const profile = await fetchInstagramProfile(longLived.access_token);

  // Step 4: find-or-create the platform User + linked Account
  // If the request is authenticated already, link this IG account to the
  // existing user (multi-account support). Otherwise create a fresh user.
  let user = req.userId ? await User.findById(req.userId) : null;

  let account = await Account.findOne({ instagramUserId: profile.id });
  const expiresAt = new Date(Date.now() + longLived.expires_in * 1000);
  const encryptedAccessToken = encryptToken(longLived.access_token);

  if (account) {
    account.encryptedAccessToken = encryptedAccessToken;
    account.tokenExpiresAt = expiresAt;
    account.username = profile.username;
    account.accountType = profile.account_type === "MEDIA_CREATOR" ? "CREATOR" : profile.account_type;
    await account.save();
    if (!user) user = await User.findById(account.userId);
  } else {
    if (!user) user = await User.create({});
    account = await Account.create({
      userId: user._id,
      instagramUserId: profile.id,
      username: profile.username,
      accountType: profile.account_type === "MEDIA_CREATOR" ? "CREATOR" : profile.account_type,
      encryptedAccessToken,
      tokenExpiresAt: expiresAt,
      isPrimary: true,
    });
    user.activeAccountId = account._id as any;
    await user.save();
  }

  if (!user.activeAccountId) {
    user.activeAccountId = account._id as any;
  }

  // Step 5: issue our own session tokens (JWT access + refresh)
  const sessionId = crypto.randomUUID();
  const accessToken = generateAccessToken({ userId: String(user._id), sessionId });
  const refreshToken = generateRefreshToken({ userId: String(user._id), sessionId });

  user.refreshTokens.push({
    token: refreshToken,
    sessionId,
    createdAt: new Date(),
    userAgent: req.headers["user-agent"],
  });
  await user.save();

  res
    .cookie("accessToken", accessToken, { ...COOKIE_OPTIONS, maxAge: 15 * 60 * 1000 })
    .cookie("refreshToken", refreshToken, { ...COOKIE_OPTIONS, maxAge: 30 * 24 * 60 * 60 * 1000 })
    .redirect(`${process.env.CLIENT_URL}/dashboard`);

  logger.info(`User ${user._id} authenticated via Instagram (@${profile.username})`);
};

// POST /api/auth/refresh
export const refreshSession = async (req: AuthRequest, res: Response) => {
  const token = req.cookies?.refreshToken;
  if (!token) throw new AppError("No refresh token provided", 401);

  const payload = verifyRefreshToken(token);
  const user = await User.findById(payload.userId);
  if (!user) throw new AppError("User not found", 401);

  const stored = user.refreshTokens.find((t) => t.sessionId === payload.sessionId && t.token === token);
  if (!stored) throw new AppError("Session revoked, please log in again", 401);

  const newAccessToken = generateAccessToken({ userId: payload.userId, sessionId: payload.sessionId });
  res
    .cookie("accessToken", newAccessToken, { ...COOKIE_OPTIONS, maxAge: 15 * 60 * 1000 })
    .json({ success: true, message: "Session refreshed" });
};

// POST /api/auth/logout
export const logout = async (req: AuthRequest, res: Response) => {
  if (req.userId && req.sessionId) {
    await User.updateOne(
      { _id: req.userId },
      { $pull: { refreshTokens: { sessionId: req.sessionId } } }
    );
  }
  res.clearCookie("accessToken").clearCookie("refreshToken").json({ success: true, message: "Logged out" });
};

// GET /api/auth/me
export const getCurrentUser = async (req: AuthRequest, res: Response) => {
  const user = await User.findById(req.userId).populate("activeAccountId", "-encryptedAccessToken");
  if (!user) throw new AppError("User not found", 404);

  const accounts = await Account.find({ userId: user._id }).select("-encryptedAccessToken");
  res.json({ success: true, user, accounts });
};

// POST /api/auth/switch-account
export const switchAccount = async (req: AuthRequest, res: Response) => {
  const { accountId } = req.body;
  const account = await Account.findOne({ _id: accountId, userId: req.userId });
  if (!account) throw new AppError("Account not found or not linked to this user", 404);

  await User.updateOne({ _id: req.userId }, { activeAccountId: account._id });
  res.json({ success: true, message: `Switched to @${account.username}` });
};

// DELETE /api/auth/accounts/:accountId
export const unlinkAccount = async (req: AuthRequest, res: Response) => {
  const { accountId } = req.params;
  const account = await Account.findOne({ _id: accountId, userId: req.userId });
  if (!account) throw new AppError("Account not found", 404);

  await account.deleteOne();
  res.json({ success: true, message: "Account unlinked" });
};
