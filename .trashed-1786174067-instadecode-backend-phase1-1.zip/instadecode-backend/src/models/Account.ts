import mongoose, { Schema, Document } from "mongoose";

export interface IAccount extends Document {
  userId: mongoose.Types.ObjectId;
  instagramUserId: string;
  username: string;
  fullName?: string;
  profilePictureUrl?: string;
  accountType: "PERSONAL" | "BUSINESS" | "CREATOR";
  encryptedAccessToken: string; // long-lived IG token, encrypted at rest
  tokenExpiresAt: Date;
  isPrimary: boolean;
  connectedAt: Date;
  lastSyncedAt?: Date;
}

const AccountSchema = new Schema<IAccount>(
  {
    userId: { type: Schema.Types.ObjectId, ref: "User", required: true, index: true },
    instagramUserId: { type: String, required: true, unique: true },
    username: { type: String, required: true },
    fullName: { type: String },
    profilePictureUrl: { type: String },
    accountType: {
      type: String,
      enum: ["PERSONAL", "BUSINESS", "CREATOR"],
      default: "PERSONAL",
    },
    encryptedAccessToken: { type: String, required: true, select: false },
    tokenExpiresAt: { type: Date, required: true },
    isPrimary: { type: Boolean, default: false },
    connectedAt: { type: Date, default: Date.now },
    lastSyncedAt: { type: Date },
  },
  { timestamps: true }
);

export default mongoose.model<IAccount>("Account", AccountSchema);
