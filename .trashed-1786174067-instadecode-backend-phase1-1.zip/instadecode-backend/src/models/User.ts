import mongoose, { Schema, Document } from "mongoose";

export interface IUser extends Document {
  email?: string;
  activeAccountId: mongoose.Types.ObjectId | null;
  refreshTokens: { token: string; sessionId: string; createdAt: Date; userAgent?: string }[];
  preferences: {
    theme: "light" | "dark";
    language: string;
    emailReports: boolean;
  };
  createdAt: Date;
  updatedAt: Date;
}

const UserSchema = new Schema<IUser>(
  {
    email: { type: String, unique: true, sparse: true, lowercase: true, trim: true },
    activeAccountId: { type: Schema.Types.ObjectId, ref: "Account", default: null },
    refreshTokens: [
      {
        token: { type: String, required: true },
        sessionId: { type: String, required: true },
        createdAt: { type: Date, default: Date.now },
        userAgent: { type: String },
      },
    ],
    preferences: {
      theme: { type: String, enum: ["light", "dark"], default: "dark" },
      language: { type: String, default: "en" },
      emailReports: { type: Boolean, default: true },
    },
  },
  { timestamps: true }
);

export default mongoose.model<IUser>("User", UserSchema);
