# Telegram AI Clone Bot

Auto-replies to Telegram messages in your personal texting style, with a
multi-provider AI fallback chain so quota limits don't take the bot down.

Fallback order (edit in `aiFallback.js` -> `MODEL_CHAIN`):
1. Gemini 2.5 Flash
2. Gemini 2.5 Flash Lite
3. Gemini 2.0 Flash
4. Groq (Llama 3.3 70B)
5. OpenRouter (free Llama 3.3 70B)
6. Cohere (Command R+)
7. HuggingFace Inference API (Llama 3.1 8B)

## Setup

1. Install dependencies:
   ```
   npm install
   ```

2. Copy `.env.example` to `.env` and fill in your keys:
   ```
   cp .env.example .env
   ```

   Where to get each key:
   - Telegram: message @BotFather on Telegram, `/newbot`
   - Gemini: https://aistudio.google.com/app/apikey
   - Groq: https://console.groq.com/keys
   - OpenRouter: https://openrouter.ai/keys
   - Cohere: https://dashboard.cohere.com/api-keys
   - HuggingFace: https://huggingface.co/settings/tokens

3. Run locally:
   ```
   npm start
   ```

## Deploying on Render

1. Push this folder to a GitHub repo.
2. On Render: New -> Background Worker (or Web Service).
3. Build command: `npm install`
4. Start command: `npm start`
5. Add all the `.env` variables under Render's Environment tab.

## Customizing your texting style

Edit `PERSONA_PROMPT` in `bot.js` to describe how you text — tone, language
mix, length, emoji usage, etc. The more specific, the better the clone.

## Commands

- `/start` — check the bot is alive
- `/reset` — clear the in-memory conversation history for that chat

## Notes

- Chat history is stored in memory only — it resets whenever the bot
  restarts or Render redeploys. For persistent memory, connect a database
  (e.g. Firebase Firestore, which you're already using in other projects).
- If ALL providers fail (rare), the bot sends a graceful "busy" message
  instead of crashing.
