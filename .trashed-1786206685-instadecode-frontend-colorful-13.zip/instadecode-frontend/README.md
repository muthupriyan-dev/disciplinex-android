# InstaDecode Frontend

Plain HTML/CSS/JS — no build step, no npm install needed. Just static files.

## Files
- `index.html` — landing page with "Connect Instagram" button
- `dashboard.html` — shows the logged-in user's linked accounts
- `app.js` — dashboard logic (calls your backend API)
- `config.js` — **edit this** if your backend URL ever changes
- `style.css` — all styling

## Deploy (pick one, both are free)

**Netlify (easiest):**
1. Go to https://app.netlify.com/drop
2. Drag this whole folder into the browser window
3. Done — you get a live URL instantly

**GitHub Pages:**
1. Push this folder to a GitHub repo
2. Repo → Settings → Pages → set source to `main` branch, root folder
3. Your site goes live at `https://<username>.github.io/<repo>`

## Important: backend CORS setup

Your backend must explicitly allow requests from wherever this frontend
ends up living, **with credentials enabled** (since login uses cookies).

In your backend's `src/server.ts`, the `cors()` setup should look like:

```ts
app.use(cors({
  origin: "https://your-frontend-url.netlify.app", // no trailing slash
  credentials: true,
}));
```

Redeploy the backend on Render after adding this, or the dashboard will
fail to log in even though the API is reachable.

## After deploying

1. Open your frontend URL → click "Connect Instagram"
2. Complete the Instagram login
3. You'll land on `dashboard.html` with your account(s) listed

Analytics cards (engagement, growth charts) are placeholders for now —
ready to wire up once the backend's analytics endpoints exist.
