const loadingEl = document.getElementById('loading');
const errorEl = document.getElementById('errorState');
const contentEl = document.getElementById('content');
const accountPillEl = document.getElementById('accountPill');
const accountListEl = document.getElementById('accountList');
const activeUsernameEl = document.getElementById('activeUsername');
const activeTypeEl = document.getElementById('activeType');
const statAccountsEl = document.getElementById('statAccounts');
const logoutBtn = document.getElementById('logoutBtn');

async function apiFetch(path, options = {}) {
  const res = await fetch(API_BASE_URL + path, {
    credentials: 'include',
    headers: { 'Content-Type': 'application/json' },
    ...options,
  });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) {
    throw new Error(data.message || `Request failed (${res.status})`);
  }
  return data;
}

function renderAccounts(user, accounts) {
  const activeId = user.activeAccountId?._id || user.activeAccountId;

  const active = accounts.find((a) => a._id === activeId) || user.activeAccountId;
  activeUsernameEl.textContent = active?.username ? `@${active.username}` : 'No active account';
  activeTypeEl.textContent = active?.accountType ? active.accountType.toLowerCase() : '';

  statAccountsEl.textContent = accounts.length;

  accountPillEl.style.display = 'inline-flex';
  accountPillEl.textContent = active?.username ? `@${active.username} ▾` : 'select account ▾';

  accountListEl.innerHTML = '';

  if (accounts.length === 0) {
    accountListEl.innerHTML = `
      <div class="empty-state" style="padding:40px 0;">
        <h2>No accounts linked yet</h2>
        <p>Connect an Instagram account to start seeing data here.</p>
      </div>`;
    return;
  }

  accounts.forEach((acc) => {
    const row = document.createElement('div');
    row.className = 'account-row';
    const isActive = acc._id === activeId;
    row.innerHTML = `
      <div class="meta">
        <span class="username">@${acc.username}</span>
        <span class="type">${(acc.accountType || '').toLowerCase()}</span>
      </div>
      ${isActive
        ? '<span class="badge-active">active</span>'
        : `<button class="btn btn-ghost switch-btn" data-id="${acc._id}">Switch</button>`}
    `;
    accountListEl.appendChild(row);
  });

  document.querySelectorAll('.switch-btn').forEach((btn) => {
    btn.addEventListener('click', async () => {
      btn.disabled = true;
      btn.textContent = 'Switching…';
      try {
        await apiFetch('/api/auth/switch-account', {
          method: 'POST',
          body: JSON.stringify({ accountId: btn.dataset.id }),
        });
        await loadUser();
      } catch (err) {
        alert(err.message);
        btn.disabled = false;
        btn.textContent = 'Switch';
      }
    });
  });
}

async function loadUser() {
  loadingEl.style.display = 'block';
  errorEl.style.display = 'none';
  contentEl.style.display = 'none';
  try {
    const data = await apiFetch('/api/auth/me');
    renderAccounts(data.user, data.accounts || []);
    loadingEl.style.display = 'none';
    contentEl.style.display = 'block';
  } catch (err) {
    loadingEl.style.display = 'none';
    errorEl.style.display = 'block';
    errorEl.textContent = `// ${err.message} — redirecting to login…`;
    setTimeout(() => {
      window.location.href = 'index.html';
    }, 1800);
  }
}

logoutBtn.addEventListener('click', async () => {
  logoutBtn.disabled = true;
  logoutBtn.textContent = 'Logging out…';
  try {
    await apiFetch('/api/auth/logout', { method: 'POST' });
  } catch (err) {
    // even if this fails, send the user back to login
  }
  window.location.href = 'index.html';
});

loadUser();
