// InstaDecode frontend config
// Point this at your deployed backend. No trailing slash.
const API_BASE_URL = "https://decodeanalytics-backend.onrender.com";
