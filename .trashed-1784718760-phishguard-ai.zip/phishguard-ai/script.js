/* =========================================================
   PhishGuard AI — script.js
   Educational, fully client-side phishing URL heuristics.
   No data ever leaves the browser. No real WHOIS / domain-age
   lookups are performed — those panels use clearly-labelled
   simulated data for teaching purposes only.
   ========================================================= */

(function () {
  'use strict';

  /* ---------------------------------------------------------
     0. Reference data
  --------------------------------------------------------- */
  const SUSPICIOUS_KEYWORDS = [
    'login', 'signin', 'sign-in', 'verify', 'secure', 'update', 'account',
    'bank', 'wallet', 'otp', 'password', 'confirm', 'payment', 'recover', 'support'
  ];

  const RISKY_TLDS = ['xyz', 'tk', 'ml', 'ga', 'cf', 'gq', 'top', 'club', 'work', 'info', 'click', 'loan', 'win', 'icu', 'rest'];
  const SAFE_TLDS = ['com', 'org', 'edu', 'gov', 'net', 'io', 'co'];

  // Known brand -> their genuine registrable domain.
  const BRANDS = {
    google: 'google.com', microsoft: 'microsoft.com', amazon: 'amazon.com',
    paypal: 'paypal.com', facebook: 'facebook.com', instagram: 'instagram.com',
    netflix: 'netflix.com', apple: 'apple.com', paytm: 'paytm.com',
    phonepe: 'phonepe.com', flipkart: 'flipkart.com'
  };

  const REDIRECT_PARAM_KEYS = [
    'redirect', 'redirecturl', 'redirect_url', 'next', 'continue',
    'return', 'returnurl', 'return_url', 'url', 'dest', 'destination', 'go', 'target'
  ];

  const REGISTRARS = ['NameCheap, Inc.', 'GoDaddy.com, LLC', 'Public Domain Registry', 'Tucows Domains Inc.', 'PDR Ltd.', 'Name.com, Inc.'];

  const STATUS_COLOR_HEX = { pass: '#15803d', warn: '#d97706', fail: '#dc2626' };

  // 8 checks and the weight (must sum to 100) each contributes to the overall score.
  const CHECK_DEFS = [
    { key: 'keywords', name: 'Suspicious Keywords', weight: 10 },
    { key: 'length', name: 'URL Length', weight: 5 },
    { key: 'special', name: 'Special Characters', weight: 6 },
    { key: 'https', name: 'HTTPS Usage', weight: 8 },
    { key: 'tld', name: 'Domain Extension', weight: 8 },
    { key: 'brand', name: 'Brand Impersonation', weight: 15 },
    { key: 'subdomain', name: 'Subdomain Abuse', weight: 10 },
    { key: 'redirect', name: 'Redirect Indicators', weight: 8 },
    { key: 'network', name: 'Network Address Check', weight: 30 }
  ];

  const SCAN_LOG_LINES = [
    '[INFO] Initializing PhishGuard heuristics engine...',
    '[INFO] Parsing URL structure...',
    '[INFO] Scanning for suspicious keywords...',
    '[INFO] Evaluating TLD reputation...',
    '[INFO] Checking brand impersonation patterns...',
    '[INFO] Analyzing subdomain structure...',
    '[INFO] Inspecting redirect parameters...',
    '[INFO] Compiling threat intelligence...',
    '[SUCCESS] Analysis completed.'
  ];

  /* ---------------------------------------------------------
     1. Small utilities
  --------------------------------------------------------- */
  function hashString(str) {
    let h = 0;
    for (let i = 0; i < str.length; i++) {
      h = (h * 31 + str.charCodeAt(i)) >>> 0;
    }
    return h;
  }

  function leetNormalize(s) {
    return s.replace(/0/g, 'o').replace(/1/g, 'l').replace(/3/g, 'e')
      .replace(/4/g, 'a').replace(/5/g, 's').replace(/7/g, 't').replace(/\$/g, 's');
  }

  function getRegistrableDomain(hostname) {
    const parts = hostname.split('.').filter(Boolean);
    if (parts.length <= 2) return parts.join('.');
    const sld = parts[parts.length - 2];
    const commonSecondLevel = ['co', 'com', 'org', 'net', 'gov', 'ac', 'edu'];
    if (commonSecondLevel.includes(sld)) return parts.slice(-3).join('.');
    return parts.slice(-2).join('.');
  }

  function statusFromScore(score) {
    if (score < 30) return 'pass';
    if (score < 65) return 'warn';
    return 'fail';
  }

  function clamp(n, min, max) { return Math.min(max, Math.max(min, n)); }

  /* ---------------------------------------------------------
     2. The eight heuristic checks
     Each returns { score: 0-100, explanation: string, findings: string[] }
  --------------------------------------------------------- */
  function checkKeywords(fullUrl) {
    const lower = fullUrl.toLowerCase();
    const found = SUSPICIOUS_KEYWORDS.filter(k => lower.includes(k));
    let score, explanation;
    if (found.length === 0) {
      score = 5;
      explanation = 'No suspicious keywords (login, verify, otp, etc.) found in the URL.';
    } else if (found.length === 1) {
      score = 35;
      explanation = `One suspicious keyword detected: "${found[0]}". Could be legitimate, but worth a second look.`;
    } else if (found.length === 2) {
      score = 55;
      explanation = `Multiple suspicious keywords detected: ${found.join(', ')}.`;
    } else {
      score = 80;
      explanation = `Several suspicious keywords stacked together: ${found.join(', ')}. Common in credential-harvesting links.`;
    }
    return { score, explanation, findings: found.length ? [`Suspicious keyword(s) found: ${found.join(', ')}.`] : [] };
  }

  function checkLength(fullUrl) {
    const len = fullUrl.length;
    let score, explanation;
    if (len <= 30) { score = 5; explanation = `URL is short (${len} characters) — typical of a normal link.`; }
    else if (len <= 60) { score = 20; explanation = `URL length is moderate (${len} characters).`; }
    else if (len <= 100) { score = 45; explanation = `URL is somewhat long (${len} characters), which can hide extra parameters.`; }
    else if (len <= 150) { score = 70; explanation = `URL is quite long (${len} characters) — often used to bury suspicious tokens.`; }
    else { score = 90; explanation = `URL is extremely long (${len} characters), a common obfuscation tactic.`; }
    return { score, explanation, findings: score >= 70 ? [`Unusually long URL (${len} characters).`] : [] };
  }

  function checkSpecialChars(fullUrl, hostname) {
    const atCount = (fullUrl.match(/@/g) || []).length;
    const pctCount = (fullUrl.match(/%/g) || []).length;
    const dotCount = (hostname.match(/\./g) || []).length;

    let score = 5;
    const findings = [];
    const notes = [];

    if (atCount > 0) {
      score = Math.max(score, 78);
      findings.push(`Contains "@" (${atCount}×) — browsers ignore everything before "@", a classic cloaking trick.`);
      notes.push('contains "@"');
    }
    if (pctCount >= 3) {
      score = Math.max(score, 55);
      findings.push(`Heavy URL-encoding detected (${pctCount} "%" characters).`);
      notes.push('heavily percent-encoded');
    }
    if (dotCount >= 4) {
      score = Math.max(score, 40);
      findings.push('Domain has an unusually high number of dots.');
      notes.push('many dots in domain');
    }

    const explanation = notes.length
      ? `Flagged pattern(s): ${notes.join(', ')}.`
      : 'No unusual special-character patterns (e.g. "@", excess "%") found.';

    return { score, explanation, findings };
  }

  function checkNetworkAddress(hostname, urlObj) {
    const isIpv4 = /^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$/.test(hostname);
    const isIpv6 = hostname.includes(':') && /^[0-9a-f:]+$/i.test(hostname.replace(/[[\]]/g, ''));
    const isIp = isIpv4 || isIpv6;

    const isLoopback = hostname === '127.0.0.1' || hostname === 'localhost' || hostname === '::1';
    const isPrivateV4 = isIpv4 && /^(10\.|192\.168\.|172\.(1[6-9]|2\d|3[01])\.)/.test(hostname);

    const port = urlObj.port;
    const hasNonStandardPort = port !== '' && port !== '80' && port !== '443';

    const findings = [];
    let score, explanation;

    if (isIp) {
      score = 80;
      findings.push('Hostname is a raw IP address rather than a registered domain name — a common phishing/scam-kit pattern since attackers avoid buying a domain.');
      explanation = 'Hostname is a raw IP address, not a domain name.';
      if (isLoopback || isPrivateV4) {
        score = 95;
        findings.push('Address points to a local/private machine (loopback or private LAN IP) — never a legitimate destination for a public website, often used while testing or hosting throwaway phishing pages.');
        explanation += ' It also resolves to a local/private network address, not a public server.';
      }
      if (hasNonStandardPort) {
        score = clamp(score + 5, 0, 100);
        findings.push(`Uses a non-standard port (:${port}) — legitimate public sites almost always run on 80/443.`);
        explanation += ` Running on non-standard port :${port}.`;
      }
    } else if (hasNonStandardPort) {
      score = 45;
      explanation = `Domain name looks normal, but the URL specifies a non-standard port (:${port}), which is unusual for everyday public sites.`;
      findings.push(`Non-standard port specified (:${port}).`);
    } else {
      score = 5;
      explanation = 'Hostname is a normal domain name on a standard port.';
    }

    return { score, explanation, findings };
  }

  function checkHttps(urlObj) {
    if (urlObj.protocol === 'https:') {
      return {
        score: 10,
        explanation: 'Connection uses HTTPS encryption. Note: phishing sites can buy free HTTPS certificates too, so this alone never proves legitimacy.',
        findings: []
      };
    }
    return {
      score: 65,
      explanation: 'No HTTPS encryption detected. Data submitted on this page could be intercepted in transit.',
      findings: ['Connection is not encrypted (plain HTTP).']
    };
  }

  function checkTld(hostname) {
    const isIp = /^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$/.test(hostname) || hostname.includes(':');
    if (isIp) {
      return {
        score: 20,
        explanation: 'Hostname is an IP address, so there is no domain extension to evaluate here — see the Network Address check instead.',
        findings: []
      };
    }
    const labels = hostname.split('.');
    const tld = labels[labels.length - 1].toLowerCase();
    let score, explanation;
    if (RISKY_TLDS.includes(tld)) {
      score = 85;
      explanation = `".${tld}" is a low-cost TLD frequently abused for throwaway phishing domains.`;
    } else if (SAFE_TLDS.includes(tld)) {
      score = 10;
      explanation = `".${tld}" is a long-established, generally trusted TLD.`;
    } else {
      score = 40;
      explanation = `".${tld}" is not on the common trusted list. Not inherently malicious, but worth double-checking.`;
    }
    return { score, explanation, findings: score >= 65 ? [`Uses ".${tld}", a TLD commonly associated with abuse.`] : [] };
  }

  function checkBrandImpersonation(hostname) {
    const normalized = hostname.toLowerCase();
    const leet = leetNormalize(normalized);
    const registrable = getRegistrableDomain(normalized);
    const matches = [];

    for (const brand in BRANDS) {
      const official = BRANDS[brand];
      if (registrable === official) continue; // this IS the real site — not impersonation
      if (leet.includes(brand)) {
        const literalPresent = normalized.includes(brand);
        matches.push({ brand, leetUsed: !literalPresent, official });
      }
    }

    if (matches.length === 0) {
      return { score: 5, explanation: 'No known brand names detected in this hostname.', findings: [] };
    }

    let score = 55 + (matches.some(m => m.leetUsed) ? 20 : 0) + Math.max(0, (matches.length - 1) * 10);
    score = clamp(score, 0, 100);

    const names = matches.map(m => m.brand).join(', ');
    const officials = [...new Set(matches.map(m => m.official))].join(', ');
    const explanation = `Hostname references brand name(s) "${names}" but resolves to "${registrable}", not the official domain (${officials}).`;
    const findings = matches.map(m =>
      `Possible "${m.brand}" impersonation: "${registrable}" is not "${m.official}"${m.leetUsed ? ' (look-alike characters used)' : ''}.`
    );

    return { score, explanation, findings };
  }

  function checkSubdomainAbuse(hostname) {
    const labels = hostname.toLowerCase().split('.').filter(Boolean);
    const fakeTldWords = ['com', 'net', 'org', 'gov', 'co'];
    const prefixLabels = labels.slice(0, Math.max(labels.length - 2, 0));
    const suspiciousPrefix = prefixLabels.filter(l => fakeTldWords.includes(l) || Object.keys(BRANDS).includes(l));

    let score, explanation, findings = [];

    if (suspiciousPrefix.length > 0) {
      score = 85;
      explanation = `Subdomain embeds "${suspiciousPrefix.join(', ')}" ahead of the real domain (${getRegistrableDomain(hostname)}) — a common trick to look like a trusted site.`;
      findings.push(`Subdomain disguises the real domain using "${suspiciousPrefix.join(', ')}".`);
    } else if (labels.length >= 5) {
      score = 55;
      explanation = `Unusually deep subdomain chain (${labels.length} labels) can be used to hide the true destination.`;
      findings.push(`Deep subdomain chain (${labels.length} labels).`);
    } else if (labels.length === 4) {
      score = 30;
      explanation = 'Multiple subdomain levels detected. Worth confirming the actual registrable domain.';
    } else {
      score = 8;
      explanation = 'Subdomain structure looks ordinary.';
    }

    return { score, explanation, findings };
  }

  function checkRedirect(urlObj) {
    const matched = [];
    let embeddedUrl = false;
    for (const key of urlObj.searchParams.keys()) {
      if (REDIRECT_PARAM_KEYS.includes(key.toLowerCase())) matched.push(key);
    }
    for (const value of urlObj.searchParams.values()) {
      if (/^https?:\/\//i.test(value)) embeddedUrl = true;
    }

    let score, explanation, findings = [];
    if (embeddedUrl) {
      score = 90;
      explanation = 'Query string embeds a full secondary URL — a classic open-redirect / cloaking pattern.';
      findings.push('Embedded secondary URL found in query parameters (open-redirect pattern).');
    } else if (matched.length > 0) {
      score = 58;
      explanation = `Redirect-style parameter(s) found: ${matched.join(', ')}.`;
      findings.push(`Redirect-style parameter(s) present: ${matched.join(', ')}.`);
    } else {
      score = 5;
      explanation = 'No redirect-style parameters found.';
    }
    return { score, explanation, findings };
  }

  /* ---------------------------------------------------------
     3. Orchestration
  --------------------------------------------------------- */
  function parseInputUrl(raw) {
    const trimmed = raw.trim();
    if (!trimmed) return null;
    try { return new URL(trimmed); } catch (e) { /* try adding scheme */ }
    try { return new URL('http://' + trimmed); } catch (e) { return null; }
  }

  function getRiskLevel(score) {
    if (score < 20) return { label: 'SAFE', hex: '#15803d', band: 0 };
    if (score < 40) return { label: 'LOW RISK', hex: '#65a30d', band: 1 };
    if (score < 60) return { label: 'MEDIUM RISK', hex: '#d97706', band: 2 };
    if (score < 80) return { label: 'HIGH RISK', hex: '#ea580c', band: 3 };
    return { label: 'CRITICAL', hex: '#dc2626', band: 4 };
  }

  function runAnalysis(raw) {
    const urlObj = parseInputUrl(raw);
    if (!urlObj) return null;

    const hostname = urlObj.hostname.toLowerCase();
    const full = urlObj.href;

    const results = {
      keywords: checkKeywords(full),
      length: checkLength(full),
      special: checkSpecialChars(full, hostname),
      https: checkHttps(urlObj),
      tld: checkTld(hostname),
      brand: checkBrandImpersonation(hostname),
      subdomain: checkSubdomainAbuse(hostname),
      redirect: checkRedirect(urlObj),
      network: checkNetworkAddress(hostname, urlObj)
    };

    let overall = 0;
    CHECK_DEFS.forEach(def => { overall += results[def.key].score * (def.weight / 100); });
    overall = Math.round(clamp(overall, 0, 100));

    const level = getRiskLevel(overall);

    let findings = [];
    CHECK_DEFS.forEach(def => { findings = findings.concat(results[def.key].findings || []); });
    if (findings.length === 0) findings.push('No major phishing indicators detected in this URL.');

    const age = simulateDomainAge(hostname, overall);
    const whois = simulateWhois(hostname, age, overall);

    return { urlObj, full, hostname, results, overall, level, findings, age, whois };
  }

  function simulateDomainAge(hostname, overallScore) {
    const h = hashString(getRegistrableDomain(hostname));
    let roll = h % 100;
    if (overallScore >= 60) roll = Math.floor(roll * 0.35);
    else if (overallScore >= 40) roll = Math.floor(roll * 0.65);

    if (roll < 35) {
      return { category: 'New Domain', note: 'Simulated signal suggests this domain was likely registered recently (often under 6 months) — typical of throwaway phishing infrastructure.' };
    } else if (roll < 70) {
      return { category: 'Medium Age', note: 'Simulated signal suggests moderate domain age (roughly 6 months to 2 years).' };
    }
    return { category: 'Established', note: 'Simulated signal suggests an older, more established domain — generally (not always) a lower-risk signal.' };
  }

  function simulateWhois(hostname, age, overallScore) {
    const reg = getRegistrableDomain(hostname);
    const h = hashString(reg);
    const registrar = REGISTRARS[h % REGISTRARS.length];
    const now = Date.now();
    const DAY = 24 * 3600 * 1000;
    let ageDays;
    if (age.category === 'New Domain') ageDays = h % 180;
    else if (age.category === 'Medium Age') ageDays = 180 + (h % 550);
    else ageDays = 730 + (h % 2000);

    const created = new Date(now - ageDays * DAY);
    const expiry = new Date(created.getTime() + (1 + (h % 3)) * 365 * DAY);
    const status = overallScore >= 60 ? 'Active — Privacy Protected' : 'Active';

    return {
      domain: reg,
      registrar,
      created: created.toISOString().split('T')[0],
      expiry: expiry.toISOString().split('T')[0],
      status
    };
  }

  function buildAiAnalysis(data) {
    const lines = [];
    lines.push(`AI Analysis: This URL scores ${data.overall}/100, placing it in the "${data.level.label}" band.`);

    const topIssues = CHECK_DEFS
      .map(def => ({ name: def.name, score: data.results[def.key].score }))
      .filter(d => d.score >= 50)
      .sort((a, b) => b.score - a.score)
      .slice(0, 3);

    if (topIssues.length > 0) {
      lines.push(`The strongest signals come from: ${topIssues.map(d => d.name.toLowerCase()).join(', ')}.`);
    } else {
      lines.push('No single check produced a strong warning signal — the URL looks structurally unremarkable.');
    }

    if (data.overall >= 80) {
      lines.push('Treat this link as highly likely to be malicious. Do not enter credentials, OTPs, or payment information.');
    } else if (data.overall >= 60) {
      lines.push('Multiple phishing-style indicators are present. Verify the destination through an official source before trusting it.');
    } else if (data.overall >= 40) {
      lines.push('Some indicators are mildly suspicious. A quick manual check of the domain is recommended.');
    } else if (data.overall >= 20) {
      lines.push('Mostly benign signals with a couple of minor flags — low concern, but stay alert.');
    } else {
      lines.push('Structurally, this URL matches patterns typical of legitimate links.');
    }
    return lines.join('\n\n');
  }

  function buildRecommendations(data) {
    const recs = [
      'Verify domain ownership through the official website, not the link itself.',
      'Never enter passwords, OTPs, or card details on a page reached via an unsolicited link.',
      'Enable two-factor authentication (2FA) wherever the linked service supports it.',
      "Type the company's URL directly into your browser instead of clicking unfamiliar links.",
      'Use a password manager — it will refuse to autofill credentials on a lookalike domain.'
    ];
    if (data.results.https.score > 30) recs.push('Avoid submitting any data on a non-HTTPS page.');
    if (data.results.brand.score > 40) recs.push("Compare the domain character-by-character against the brand's real domain before trusting it.");
    if (data.results.tld.score > 60) recs.push('Treat links on uncommon, low-cost TLDs with extra scrutiny.');
    return recs;
  }

  function buildThreatIntel(data) {
    const indicatorCount = CHECK_DEFS.filter(def => data.results[def.key].score >= 50).length;
    let confidence;
    if (indicatorCount >= 4 || data.overall >= 75) confidence = 'High';
    else if (indicatorCount >= 2 || data.overall >= 45) confidence = 'Medium';
    else confidence = 'Low';
    return { riskScore: data.overall, indicatorCount, findingCount: data.findings.length, confidence };
  }

  /* ---------------------------------------------------------
     4. DOM references
  --------------------------------------------------------- */
  const $ = (id) => document.getElementById(id);

  const urlInput = $('urlInput');
  const analyzeBtn = $('analyzeBtn');
  const clearBtn = $('clearBtn');
  const qrToggleBtn = $('qrToggleBtn');
  const inputError = $('inputError');

  const qrZone = $('qrZone');
  const qrDropzone = $('qrDropzone');
  const qrFileInput = $('qrFileInput');
  const qrCanvas = $('qrCanvas');
  const qrResult = $('qrResult');
  const qrResultUrl = $('qrResultUrl');

  const scanLoading = $('scanLoading');
  const scanLogs = $('scanLogs');

  const resultsEl = $('results');
  const gaugeFill = $('gaugeFill');
  const riskScoreNum = $('riskScoreNum');
  const riskLevelTag = $('riskLevelTag');
  const riskUrlEcho = $('riskUrlEcho');
  const riskSummary = $('riskSummary');
  const progressFill = $('progressFill');

  const checksGrid = $('checksGrid');
  const aiAnalystText = $('aiAnalystText');
  const recList = $('recList');
  const ageBadge = $('ageBadge');
  const ageNote = $('ageNote');
  const whoisTable = $('whoisTable');
  const tiGrid = $('tiGrid');
  const findingsList = $('findingsList');
  const downloadPdfBtn = $('downloadPdfBtn');
  const terminalBody = $('terminalBody');

  let lastResult = null;
  const charts = { breakdown: null, categories: null, distribution: null };
  const GAUGE_CIRC = 2 * Math.PI * 52;

  /* ---------------------------------------------------------
     5. Render helpers (textContent only — never trust URL-derived
        strings inside innerHTML)
  --------------------------------------------------------- */
  function clearChildren(el) { while (el.firstChild) el.removeChild(el.firstChild); }

  function renderChecksGrid(data) {
    clearChildren(checksGrid);
    CHECK_DEFS.forEach(def => {
      const r = data.results[def.key];
      const status = statusFromScore(r.score);
      const statusLabel = status === 'pass' ? 'LOW' : status === 'warn' ? 'CAUTION' : 'FLAGGED';
      const color = STATUS_COLOR_HEX[status];

      const card = document.createElement('div');
      card.className = 'check-card';

      const head = document.createElement('div');
      head.className = 'check-card-head';
      const nameSpan = document.createElement('span');
      nameSpan.className = 'check-name';
      nameSpan.textContent = def.name;
      const statusSpan = document.createElement('span');
      statusSpan.className = 'check-status status-' + status;
      statusSpan.textContent = statusLabel;
      head.append(nameSpan, statusSpan);

      const scoreDiv = document.createElement('div');
      scoreDiv.className = 'check-score';
      scoreDiv.textContent = `Score: ${r.score}/100 \u00B7 weight ${def.weight}%`;

      const barWrap = document.createElement('div');
      barWrap.className = 'check-bar';
      const barFill = document.createElement('div');
      barFill.className = 'check-bar-fill';
      barFill.style.width = r.score + '%';
      barFill.style.background = color;
      barWrap.appendChild(barFill);

      const explainP = document.createElement('p');
      explainP.className = 'check-explain';
      explainP.textContent = r.explanation;

      card.append(head, scoreDiv, barWrap, explainP);
      checksGrid.appendChild(card);
    });
  }

  function renderRecommendations(recs) {
    clearChildren(recList);
    recs.forEach(r => {
      const li = document.createElement('li');
      li.textContent = r;
      recList.appendChild(li);
    });
  }

  function renderFindings(findings) {
    clearChildren(findingsList);
    findings.forEach(f => {
      const li = document.createElement('li');
      li.textContent = f;
      if (f.startsWith('No major phishing indicators')) li.classList.add('benign');
      findingsList.appendChild(li);
    });
  }

  function renderWhois(whois) {
    clearChildren(whoisTable);
    const rows = [
      ['Domain Name', whois.domain],
      ['Registrar', whois.registrar],
      ['Creation Date', whois.created],
      ['Expiry Date', whois.expiry],
      ['Registration Status', whois.status]
    ];
    rows.forEach(([label, value]) => {
      const tr = document.createElement('tr');
      const td1 = document.createElement('td'); td1.textContent = label;
      const td2 = document.createElement('td'); td2.textContent = value;
      tr.append(td1, td2);
      whoisTable.appendChild(tr);
    });
  }

  function renderThreatIntel(ti) {
    clearChildren(tiGrid);
    const stats = [
      ['Risk Score', `${ti.riskScore}/100`],
      ['Threat Indicators', ti.indicatorCount],
      ['Suspicious Findings', ti.findingCount],
      ['Confidence Level', ti.confidence]
    ];
    stats.forEach(([label, value]) => {
      const box = document.createElement('div');
      box.className = 'ti-stat';
      const v = document.createElement('span'); v.className = 'ti-stat-value'; v.textContent = value;
      const l = document.createElement('span'); l.className = 'ti-stat-label'; l.textContent = label;
      box.append(v, l);
      tiGrid.appendChild(box);
    });
  }

  function renderCharts(data) {
    if (typeof Chart === 'undefined') return;
    const labels = CHECK_DEFS.map(d => d.name);
    const rawScores = CHECK_DEFS.map(d => data.results[d.key].score);
    const colors = rawScores.map(s => STATUS_COLOR_HEX[statusFromScore(s)]);
    const contributions = CHECK_DEFS.map(d => Math.round(data.results[d.key].score * d.weight / 100));

    Chart.defaults.color = '#5b6478';
    Chart.defaults.font.family = "'JetBrains Mono', monospace";

    if (charts.breakdown) charts.breakdown.destroy();
    charts.breakdown = new Chart($('chartBreakdown').getContext('2d'), {
      type: 'doughnut',
      data: { labels, datasets: [{ data: contributions, backgroundColor: colors, borderColor: '#ffffff', borderWidth: 2 }] },
      options: { plugins: { legend: { position: 'bottom', labels: { font: { size: 9 }, boxWidth: 10 } } }, cutout: '62%' }
    });

    if (charts.categories) charts.categories.destroy();
    charts.categories = new Chart($('chartCategories').getContext('2d'), {
      type: 'bar',
      data: { labels, datasets: [{ label: 'Risk score', data: rawScores, backgroundColor: colors, borderRadius: 4 }] },
      options: {
        indexAxis: 'y',
        scales: { x: { min: 0, max: 100, grid: { color: 'rgba(15,23,42,0.08)' } }, y: { ticks: { font: { size: 9 } }, grid: { display: false } } },
        plugins: { legend: { display: false } }
      }
    });

    const bandLabels = ['Safe', 'Low', 'Medium', 'High', 'Critical'];
    const bandMax = [20, 40, 60, 80, 100];
    const bandColors = ['#15803d', '#65a30d', '#d97706', '#ea580c', '#dc2626'];
    const currentBand = data.level.band;

    if (charts.distribution) charts.distribution.destroy();
    charts.distribution = new Chart($('chartDistribution').getContext('2d'), {
      type: 'bar',
      data: {
        labels: bandLabels,
        datasets: [{ label: 'Band ceiling', data: bandMax, backgroundColor: bandColors.map((c, i) => i === currentBand ? c : c + '33') }]
      },
      options: {
        scales: { y: { min: 0, max: 100, grid: { color: 'rgba(15,23,42,0.08)' } }, x: { grid: { display: false } } },
        plugins: {
          legend: { display: false },
          tooltip: { callbacks: { label: (ctx) => ctx.dataIndex === currentBand ? `Current score: ${data.overall}/100` : 'Band range' } }
        }
      }
    });
  }

  function renderResults(data) {
    riskScoreNum.textContent = data.overall;
    const offset = GAUGE_CIRC - (GAUGE_CIRC * data.overall / 100);
    gaugeFill.style.strokeDasharray = GAUGE_CIRC;
    gaugeFill.style.strokeDashoffset = offset;
    gaugeFill.style.stroke = data.level.hex;

    riskLevelTag.textContent = data.level.label;
    riskLevelTag.style.color = data.level.hex;
    riskLevelTag.style.borderColor = data.level.hex;
    riskLevelTag.style.background = data.level.hex + '22';

    riskUrlEcho.textContent = data.full;
    riskSummary.textContent = `${data.findings.length} finding(s) raised across 8 independent checks.`;

    progressFill.style.width = data.overall + '%';
    progressFill.style.background = data.level.hex;

    renderChecksGrid(data);
    aiAnalystText.textContent = buildAiAnalysis(data);
    renderRecommendations(buildRecommendations(data));

    ageBadge.textContent = data.age.category;
    ageBadge.style.borderColor = data.level.hex;
    ageNote.textContent = data.age.note;

    renderWhois(data.whois);
    renderThreatIntel(buildThreatIntel(data));
    renderFindings(data.findings);
    renderCharts(data);
  }

  function updateHeroTerminal(data, scanning) {
    clearChildren(terminalBody);
    const lines = [];
    lines.push(`Target: ${data.full}`);
    if (scanning) {
      lines.push('Running heuristics engine...');
    } else {
      lines.push(`Verdict: ${data.level.label} (${data.overall}/100)`);
      lines.push('Analysis cached — run again to refresh.');
    }
    lines.forEach((text) => {
      const p = document.createElement('p');
      p.className = 'line';
      p.textContent = text;
      terminalBody.appendChild(p);
    });
  }

  /* ---------------------------------------------------------
     6. Scan sequence + event wiring
  --------------------------------------------------------- */
  function showInputError(msg) {
    inputError.textContent = msg;
    inputError.classList.remove('hidden');
  }
  function clearInputError() {
    inputError.textContent = '';
    inputError.classList.add('hidden');
  }

  function runScanSequence(data) {
    resultsEl.classList.add('hidden');
    scanLoading.classList.remove('hidden');
    clearChildren(scanLogs);

    SCAN_LOG_LINES.forEach((line, i) => {
      const p = document.createElement('p');
      p.className = 'log-line' + (line.indexOf('SUCCESS') !== -1 ? ' ok' : '');
      p.textContent = line;
      p.style.animationDelay = (i * 0.16) + 's';
      scanLogs.appendChild(p);
    });

    const fill = document.querySelector('.scan-bar-fill');
    fill.style.animation = 'none';
    // eslint-disable-next-line no-unused-expressions
    fill.offsetWidth; // force reflow to restart animation
    fill.style.animation = '';

    updateHeroTerminal(data, true);

    window.setTimeout(() => {
      scanLoading.classList.add('hidden');
      renderResults(data);
      resultsEl.classList.remove('hidden');
      updateHeroTerminal(data, false);
      lastResult = data;
      resultsEl.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }, 1700);
  }

  function handleAnalyzeClick() {
    const raw = urlInput.value;
    if (!raw || !raw.trim()) {
      showInputError('Please enter a URL to analyze.');
      return;
    }
    const data = runAnalysis(raw);
    if (!data) {
      showInputError("That doesn't look like a valid URL. Try including http:// or https://");
      return;
    }
    clearInputError();
    runScanSequence(data);
  }

  function handleClearClick() {
    urlInput.value = '';
    clearInputError();
    resultsEl.classList.add('hidden');
    scanLoading.classList.add('hidden');
    qrZone.classList.add('hidden');
    qrResult.classList.add('hidden');
    lastResult = null;
    clearChildren(terminalBody);
    const p1 = document.createElement('p'); p1.className = 'line'; p1.textContent = 'PhishGuard AI heuristics engine ready.';
    const p2 = document.createElement('p'); p2.className = 'line'; p2.textContent = 'Awaiting target URL…';
    terminalBody.append(p1, p2);
    urlInput.focus();
  }

  analyzeBtn.addEventListener('click', handleAnalyzeClick);
  clearBtn.addEventListener('click', handleClearClick);
  urlInput.addEventListener('keydown', (e) => { if (e.key === 'Enter') handleAnalyzeClick(); });

  document.querySelectorAll('.chip').forEach(chip => {
    chip.addEventListener('click', () => {
      urlInput.value = chip.getAttribute('data-sample');
      handleAnalyzeClick();
    });
  });

  qrToggleBtn.addEventListener('click', () => { qrZone.classList.toggle('hidden'); });

  /* ---------------------------------------------------------
     7. QR code upload + decode (jsQR, fully client-side)
  --------------------------------------------------------- */
  function handleQrFile(file) {
    if (!file || !file.type.startsWith('image/')) return;
    const reader = new FileReader();
    reader.onload = (e) => {
      const img = new Image();
      img.onload = () => {
        qrCanvas.width = img.width;
        qrCanvas.height = img.height;
        const ctx = qrCanvas.getContext('2d');
        ctx.drawImage(img, 0, 0);
        const imageData = ctx.getImageData(0, 0, qrCanvas.width, qrCanvas.height);
        const code = (typeof jsQR === 'function') ? jsQR(imageData.data, imageData.width, imageData.height) : null;

        qrResult.classList.remove('hidden');
        if (code && code.data) {
          qrResultUrl.textContent = code.data;
          urlInput.value = code.data;
        } else {
          qrResultUrl.textContent = 'No QR code detected in this image. Try a clearer, higher-contrast image.';
        }
      };
      img.src = e.target.result;
    };
    reader.readAsDataURL(file);
  }

  qrDropzone.addEventListener('click', () => qrFileInput.click());
  qrFileInput.addEventListener('change', () => { if (qrFileInput.files[0]) handleQrFile(qrFileInput.files[0]); });
  qrDropzone.addEventListener('dragover', (e) => { e.preventDefault(); qrDropzone.classList.add('dragover'); });
  qrDropzone.addEventListener('dragleave', () => qrDropzone.classList.remove('dragover'));
  qrDropzone.addEventListener('drop', (e) => {
    e.preventDefault();
    qrDropzone.classList.remove('dragover');
    if (e.dataTransfer.files[0]) handleQrFile(e.dataTransfer.files[0]);
  });

  /* ---------------------------------------------------------
     8. PDF report export (jsPDF)
  --------------------------------------------------------- */
  function downloadPdfReport() {
    if (!lastResult || typeof window.jspdf === 'undefined') return;
    const { jsPDF } = window.jspdf;
    const doc = new jsPDF();
    const pageWidth = 180;
    let y = 18;

    doc.setFont('helvetica', 'bold'); doc.setFontSize(16);
    doc.text('PhishGuard AI - Phishing Risk Report', 14, y); y += 8;

    doc.setFontSize(9); doc.setFont('helvetica', 'italic');
    doc.text('Educational heuristic analysis. Not a real security verdict.', 14, y); y += 9;

    doc.setFont('helvetica', 'bold'); doc.setFontSize(11); doc.text('URL:', 14, y);
    doc.setFont('helvetica', 'normal');
    const urlLines = doc.splitTextToSize(lastResult.full, pageWidth - 18);
    doc.text(urlLines, 30, y); y += urlLines.length * 5 + 5;

    doc.setFont('helvetica', 'bold');
    doc.text(`Risk Score: ${lastResult.overall}/100`, 14, y); y += 7;
    doc.text(`Risk Level: ${lastResult.level.label}`, 14, y); y += 7;
    doc.setFont('helvetica', 'normal');
    doc.text(`Generated: ${new Date().toLocaleString()}`, 14, y); y += 10;

    doc.setFont('helvetica', 'bold'); doc.text('Findings:', 14, y); y += 7;
    doc.setFont('helvetica', 'normal');
    lastResult.findings.forEach(f => {
      const lines = doc.splitTextToSize('- ' + f, pageWidth);
      if (y > 270) { doc.addPage(); y = 18; }
      doc.text(lines, 14, y); y += lines.length * 5 + 2;
    });

    y += 4;
    doc.setFont('helvetica', 'bold'); doc.text('Recommendations:', 14, y); y += 7;
    doc.setFont('helvetica', 'normal');
    buildRecommendations(lastResult).forEach(r => {
      const lines = doc.splitTextToSize('- ' + r, pageWidth);
      if (y > 270) { doc.addPage(); y = 18; }
      doc.text(lines, 14, y); y += lines.length * 5 + 2;
    });

    doc.save('phishguard-report.pdf');
  }

  downloadPdfBtn.addEventListener('click', downloadPdfReport);

})();
