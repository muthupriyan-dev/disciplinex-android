# PhishGuard AI

A client-side, browser-only **phishing URL risk analyzer** built as a cybersecurity self-study project. PhishGuard AI breaks a URL down into eight lexical and structural heuristics — the same category of signals real phishing filters look at — and explains the verdict in plain language, with a terminal/hacker-styled dashboard UI.

> **This is an educational project, not a real security product.** Every score is a local heuristic estimate computed entirely in your browser. Domain age and WHOIS data are **simulated** for teaching purposes and are not retrieved from any real registry. Never use this tool as your sole basis for trusting a link.

---

## Features

- **URL Analysis Engine** — 8 weighted heuristic checks: suspicious keywords, URL length, special characters, HTTPS usage, domain extension (TLD) reputation, brand impersonation (incl. leetspeak look-alikes), subdomain abuse, and redirect-parameter detection.
- **Risk Result Dashboard** — animated circular gauge, 0–100 score, five-tier risk level (Safe → Low → Medium → High → Critical), and a gradient progress bar.
- **Detailed Analysis Cards** — per-check status, score, weight, and a plain-language explanation.
- **AI Security Analyst** — a dynamically generated natural-language summary that highlights the strongest contributing signals and gives a verdict-appropriate recommendation.
- **Security Recommendations** — a contextual checklist (2FA, password managers, verifying domains, etc.) that adapts to what was actually flagged.
- **Domain Age Simulator** & **WHOIS-style Card** — clearly-labelled *simulated* educational placeholders, deterministic per domain (same domain always produces the same simulated record).
- **Threat Intelligence Dashboard** — aggregated risk score, indicator count, finding count, and a confidence rating.
- **QR Code Scanner** — drag-and-drop or click-to-upload a QR code image; decoded fully client-side with [jsQR](https://github.com/cozmo/jsQR), then run through the same analysis engine.
- **PDF Report Generator** — exports a timestamped report (URL, score, level, findings, recommendations) via [jsPDF](https://github.com/parallax/jsPDF).
- **Data Visualization** — three [Chart.js](https://www.chartjs.org/) charts: risk breakdown (doughnut), threat categories (bar), and score-band distribution.
- **Cybersecurity UI touches** — glassmorphism cards, ambient scanline sweep, a live "terminal" log panel, staggered scan-log animation, and hover/transition polish throughout.

## Screenshots

> Add screenshots here after running the app locally, e.g.:
> `assets/images/hero.png`, `assets/images/dashboard.png`, `assets/images/checks.png`

## Installation

No build step, no dependencies to install, no backend.

```bash
git clone https://github.com/<your-username>/phishguard-ai.git
cd phishguard-ai
```

Open `index.html` directly in a browser, or serve it locally:

```bash
python3 -m http.server 8080
# then visit http://localhost:8080
```

### Deploying to GitHub Pages

1. Push this repository to GitHub.
2. Go to **Settings → Pages**.
3. Set the source to the `main` branch, root folder.
4. Your app will be live at `https://<your-username>.github.io/phishguard-ai/`.

## Usage

1. Paste a full URL (including `http://` or `https://`) into the input field, or tap one of the sample chips.
2. Click **Analyze URL** and watch the scan sequence run.
3. Review the risk gauge, the eight detailed check cards, the AI analyst summary, and the threat intelligence dashboard.
4. Optionally upload a QR code image to extract and analyze its embedded URL.
5. Download a PDF report of the analysis for your notes.

## How scoring works

Each of the 8 checks produces an independent risk score from 0–100. The overall score is a weighted sum:

| Check | Weight |
|---|---|
| Brand Impersonation | 20% |
| Suspicious Keywords | 15% |
| Subdomain Abuse | 15% |
| Domain Extension (TLD) | 12% |
| Special Characters | 10% |
| HTTPS Usage | 10% |
| Redirect Indicators | 10% |
| URL Length | 8% |

Risk bands: **0–19 Safe · 20–39 Low · 40–59 Medium · 60–79 High · 80–100 Critical.**

## Technologies

- HTML5, CSS3 (glassmorphism, CSS variables, animations), vanilla JavaScript (no framework)
- [Chart.js](https://www.chartjs.org/) — data visualization
- [jsQR](https://github.com/cozmo/jsQR) — client-side QR code decoding
- [jsPDF](https://github.com/parallax/jsPDF) — PDF report export
- Google Fonts: JetBrains Mono, Inter

## Known limitations (by design, for an educational tool)

- Brand-impersonation and registrable-domain detection use a simplified heuristic (last two/three labels of the hostname) — it does not use a full public-suffix list, so some edge-case TLD structures may be misclassified.
- Domain age and WHOIS data are deterministic *simulations* derived from the domain string, not real registry lookups.
- Scoring weights are heuristic and illustrative; they are tuned for teaching, not for production-grade phishing detection.
- No URL is ever sent to a server — all analysis, including QR decoding and PDF generation, happens locally in the browser.

## Future Improvements

- Integrate a real-time threat intelligence API (with the user's consent) as an optional, clearly-labelled "live lookup" mode.
- Add a public-suffix-list-based domain parser for more accurate registrable-domain extraction.
- Add a history panel for previously analyzed URLs (local storage only).
- Add unit tests for each heuristic check.
- Internationalize the keyword/brand lists beyond English/global brands.

## Disclaimer

PhishGuard AI is a **self-study cybersecurity project**, not a certified or commercial security tool. It must not be relied upon as the sole means of judging whether a URL is safe. Always verify suspicious links through official channels, and report real phishing attempts to your email provider or local cybersecurity authority.
