# CVastra AI — Week 6 Submission
## Deployment, Maintenance, and Project Reflection

This submission covers deployment, maintenance planning, and reflection for
**CVastra AI**, an AI-powered resume scoring SaaS application built across
Weeks 1–6 of this internship.

## Contents

1. **CVastra_AI_Deployment_Guide.docx**
   Step-by-step guide for deploying the backend (Render) and frontend
   (Netlify), including required environment variables and two real issues
   encountered during this project (a Gemini model deprecation and an
   unpinned CDN dependency) with how they were resolved.

2. **CVastra_AI_Maintenance_Documentation.docx**
   Logging strategy, error severity triage, update procedure, dependency/
   security maintenance, and honestly-stated limitations of the current
   maintenance plan given a phone-only development workflow.

3. **CVastra_AI_Project_Reflection_Report.docx**
   A reflection on the full six-week build: what went well, challenges
   faced (phone-only development, sandbox network restrictions during
   Weeks 3–5), lessons learned, and areas for improvement.

## Project context

- Stack: Node.js + Express + Gemini API backend (Render), vanilla
  HTML/CSS/JS frontend (Netlify)
- Built entirely from a mobile phone — no local terminal at any point.
  Code is authored, then uploaded via the GitHub web interface, and both
  Render and Netlify auto-deploy on push to main.
- Live deployment has been verified end to end: signup, login, resume
  upload, and Gemini-based scoring all function against the production
  database.
