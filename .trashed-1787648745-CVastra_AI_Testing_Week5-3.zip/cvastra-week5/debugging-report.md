# CVastra AI — Debugging Report (Week 5)

This documents every bug actually found while building this week's test suite
— all of them were discovered by writing and running real tests, not
invented for the assignment. Each entry: what broke, how it was found, root
cause, and the fix.

---

## 1. `new Date(null)` silently returns the Unix epoch, not an invalid date

**Found by:** `tests/frontend-unit/utils.test.js` — the very first run of the
new `formatDate` unit tests failed.

**Symptom:** `formatDate(null)` was expected to return `""` (guarded against
invalid input) but instead returned `"Jan 1, 1970"`.

**Root cause:** JavaScript's `Date` constructor treats `null` as `0` (numeric
coercion), which is a *valid* timestamp (the Unix epoch) — not `NaN`. My
first guard, `Number.isNaN(d.getTime())`, only catches genuinely invalid
dates like `new Date("not-a-date")`. It does nothing for `null`/`undefined`,
because those produce a technically-valid `Date` object.

```js
new Date(null)       // -> Thu Jan 01 1970 (valid!)
new Date(undefined)  // -> Invalid Date (NaN)
```

**Fix:** Added an explicit `null`/`undefined`/`""` check *before* constructing
the `Date`, in addition to the `NaN` guard for genuinely malformed strings
(see `frontend/js/utils.js`).

**Why it mattered:** this function renders directly into swatch cards and the
detail page. If an analysis record ever arrived with a missing `createdAt`
(e.g. a future schema change, a partially-written record), the UI would have
silently shown "Jan 1, 1970" instead of failing loudly or omitting the date.

---

## 2. Flaky end-to-end test suite — fixed timeouts instead of real waits

**Found by:** running `tests/frontend-e2e/app_spec.py` twice in a row. First
run: 4/8 failed. Second run: 3/8 failed, but a **different** 3. Same code,
same server, different results — a clear signature of a race condition in
the *test*, not the app.

**Root cause:** most test steps used `page.wait_for_timeout(300)` (a blind
sleep) instead of waiting for actual page state. After a signup redirect,
the new page still has async work in flight — `auth.js`'s
`DOMContentLoaded` handler renders the nav's login/logout state, and
`dashboard.js`/`detail.js` kick off their own `fetch()` calls in `init()`.
A fixed 300ms delay is sometimes enough and sometimes isn't, depending on
system load — exactly the kind of nondeterminism that produces "passes
sometimes" bugs.

**Fix:** replaced blind timeouts with `wait_for_selector()` /
`wait_for_url()` / `wait_for_function()` calls that wait for the actual
condition each test depends on — e.g. `wait_for_selector("#logout-btn")`
instead of "wait 300ms and hope the nav re-rendered by then."

**Verification:** ran the hardened suite 3 times consecutively — 8/8 passing
every time (see `test-logs/frontend-e2e-test-log.txt`).

**Lesson:** this is a general pattern worth calling out — `wait_for_timeout`
in any test suite is a latent flake. It happens to work in isolated manual
runs (like the very first Week 4 demo recording) and then fails
unpredictably once run repeatedly or under different system load, which is
exactly what happened here.

---

## 3. Integration test resource leak: unread response bodies

**Found by:** while first debugging the pagination test failures (see #4
below), some test runs threw `Cannot read properties of undefined (reading
'analyses')` in a *different* test than the one that was actually broken —
a sign that state was leaking between tests.

**Root cause:** several test loops called `await fetch(...)` inside a
`for` loop to trigger analysis creation, without ever reading the response
body (`res.json()`). Node's built-in `fetch` (undici) doesn't fully release
a connection back to its pool until the response body is consumed or
explicitly cancelled. Looping 25 times without consuming bodies meant 25
half-finished response streams piling up, which is a real resource leak
that could eventually cause connection exhaustion or misattributed
responses under load.

**Fix:** added an `uploadAndAnalyze()` test helper that always calls
`await analyzeRes.json()`, and replaced every loop that previously ignored
the analyze response with a call to it.

**Note:** this bug was in the *test code*, not the application — but it's
recorded here because it's a genuinely easy mistake to make with `fetch`,
and it actively masked the real bug (#4) by making failures look
inconsistent and hard to localize until the response bodies were being
consumed properly.

---

## 4. The real bug: `GET /api/analyses` returned 500 after adding pagination

**Found by:** `tests/backend-integration/api.test.js`, after fixing #3 above
made the failures deterministic and traceable to one exact function via the
server's own stack trace in its stdout log.

**Symptom:** every request to `GET /api/analyses` returned:
```
500 {"success":false,"message":"Something went wrong on the demo server."}
```

**Root cause — a genuine, classic refactor mistake.** When pagination was
added, `handleListAnalyses` was changed to accept a fourth parameter,
`query` (a `URLSearchParams`), and to call `query.get("page")` /
`query.get("limit")` inside it. The **handler definition** was updated, and
so was the router call site for `/api/resumes` — but the router call site
for `/api/analyses` was missed:

```js
// resumes — correctly updated:
if (path === "/api/resumes" && req.method === "GET")
  return handleListResumes(req, res, user, url.searchParams);

// analyses — NOT updated (the bug):
if (path === "/api/analyses" && req.method === "GET")
  return handleListAnalyses(req, res, user);   // <- query param missing entirely
```

Inside the handler, `query.get("page")` then threw `TypeError: Cannot read
properties of undefined (reading 'get')` because `query` was `undefined`.

**Why nothing else caught this:**
- `node --check` (syntax check) passed — this is valid JavaScript; a missing
  function argument isn't a syntax error.
- The **unit tests** for `utils/pagination.js` all passed — they test the
  pure parsing logic directly, correctly, in isolation. They have no way to
  know the router forgot to call it.
- Nothing in the codebase had a type system or a call-site check that would
  catch "this function's signature changed, are all its callers updated?"

Only an actual HTTP request to the actual running route — i.e., an
integration test — exercises the *wiring* between the router and the
handler, which is exactly where the bug was.

**Fix:** one-line change — pass `url.searchParams` at the missed call site,
matching the pattern already used for `/api/resumes`.

**Verification:** full integration suite went from 22/26 passing (4
failures, all traceable to this one 500) to 26/26 passing. Re-ran the e2e
Playwright suite afterward as a regression check — still 8/8.

**Lesson:** unit tests proved the pagination *logic* was correct; only
integration tests proved the pagination *feature* actually worked. Both
layers were necessary — neither alone would have caught this.

---

## 5. Code-quality issues found by inspection (not test failures, but real risk)

These weren't caught by a failing test — they were found by grepping the
codebase for duplicated logic while preparing to write tests, and fixed
*before* they could cause a bug like #4.

- **5MB file size limit** was hardcoded in two places
  (`resumeController.js` and `resumeRoutes.js`'s Multer config). A future
  change to one without the other would silently create inconsistent
  validation — the route would accept a file the controller then rejects,
  or vice versa.
- **Allowed MIME types** (`application/pdf`, the DOCX type) were duplicated
  in *three* places: the Mongoose schema enum, Multer's file filter, and
  `textExtractionService.js`'s type check.
- **`SCORE_DIMENSIONS`** (the seven scoring categories) was defined once in
  `models/Analysis.js` and re-imported by `geminiService.js` — meaning
  `geminiService.js`, whose mock-scoring logic has nothing to do with the
  database, transitively required `mongoose` just to get a list of seven
  strings. This made it **impossible to unit test** `geminiService.js` in
  this sandboxed environment (no `npm install`), since `require()`-ing it
  threw `Cannot find module 'mongoose'`.

**Fix:** extracted all three into dependency-free, single-source-of-truth
modules — `utils/fileRules.js` and `utils/scoring.js` — and updated every
call site to import from there instead of keeping a local copy. This is
also what made the 37 backend unit tests in this submission possible to
write and actually run: `geminiService.js`, `Analysis.js`'s scoring
constant, and all the file-validation logic are now testable in complete
isolation.

---

## Summary table

| # | Bug | Found via | Severity | Fixed |
|---|---|---|---|---|
| 1 | `formatDate(null)` → "Jan 1 1970" instead of empty | frontend unit test | Low (edge case, but a real latent UI bug) | Yes |
| 2 | Flaky e2e suite (fixed timeouts) | repeated e2e runs | Medium (undermines test suite trust) | Yes |
| 3 | Unread `fetch` response bodies in tests | debugging #4 | Low (test-code only, but a real leak pattern) | Yes |
| 4 | `GET /api/analyses` 500 — missed router call-site update | integration test | **High** (a whole endpoint broken) | Yes |
| 5 | Triplicated constants (size limit, MIME types, dimensions) | code review | Medium (drift risk + blocked testability) | Yes |
