/**
 * demo-server/server.js
 * ---------------------------------------------------------------------------
 * A dependency-free stand-in for the real backend (backend/), built with
 * only Node core modules (http, crypto, url). It implements the exact same
 * route contract — same paths, methods, request/response shapes — described
 * in API_DOCUMENTATION.md.
 *
 * WHY THIS EXISTS: the real backend needs `npm install` (Express, Mongoose,
 * bcrypt, Multer, pdf-parse, ...) and a MongoDB connection. This demo server
 * needs neither, so it's possible to run the *actual* integrated front-end
 * against a *real* running server anywhere Node is available — including
 * offline/sandboxed environments — to verify the integration end-to-end and
 * record a working demo.
 *
 * This is NOT the submission's backend. It exists purely to prove the
 * front-end's fetch calls, auth flow, and error handling genuinely work
 * against a live server. The graded backend is in backend/ (Week 3, Express
 * + MongoDB). See README.md "Two ways to run this" for details.
 *
 * Data is in-memory and resets on restart. Text "extraction" is a stand-in
 * (real backend uses pdf-parse/mammoth) and scoring reuses the same
 * deterministic mock algorithm as backend/src/services/geminiService.js so
 * results are stable, not random noise, across a session.
 * ---------------------------------------------------------------------------
 */

const http = require("http");
const crypto = require("crypto");
const { URL } = require("url");

const PORT = process.env.DEMO_PORT || 5000;
const JWT_SECRET = "demo-secret-not-for-production";
const CORS_ORIGINS = (process.env.DEMO_CORS_ORIGIN || "*")
  .split(",")
  .map((s) => s.trim());

// ---------------------------------------------------------------------------
// In-memory "database"
// ---------------------------------------------------------------------------
const db = {
  users: [], // { id, name, email, passwordHash, salt, createdAt }
  resumes: [], // { id, user, fileName, mimeType, sizeBytes, extractedText, targetRole, createdAt, updatedAt }
  analyses: [], // { id, user, resume, overallScore, scores, feedback, note, createdAt, updatedAt }
};
let nextId = 1;
function genId(prefix) {
  return `${prefix}_${(nextId++).toString(36)}${crypto.randomBytes(3).toString("hex")}`;
}

// ---------------------------------------------------------------------------
// Password hashing (scrypt, core crypto — no bcrypt dependency)
// ---------------------------------------------------------------------------
function hashPassword(password) {
  const salt = crypto.randomBytes(16).toString("hex");
  const hash = crypto.scryptSync(password, salt, 64).toString("hex");
  return { salt, hash };
}
function verifyPassword(password, salt, hash) {
  const check = crypto.scryptSync(password, salt, 64).toString("hex");
  return crypto.timingSafeEqual(Buffer.from(check), Buffer.from(hash));
}

// ---------------------------------------------------------------------------
// Minimal JWT-like token (HMAC-signed JSON) — no jsonwebtoken dependency
// ---------------------------------------------------------------------------
function signToken(userId) {
  const payload = { sub: userId, exp: Date.now() + 7 * 24 * 60 * 60 * 1000 };
  const body = Buffer.from(JSON.stringify(payload)).toString("base64url");
  const sig = crypto.createHmac("sha256", JWT_SECRET).update(body).digest("base64url");
  return `${body}.${sig}`;
}
function verifyToken(token) {
  const [body, sig] = String(token).split(".");
  if (!body || !sig) return null;
  const expected = crypto.createHmac("sha256", JWT_SECRET).update(body).digest("base64url");
  if (sig !== expected) return null;
  const payload = JSON.parse(Buffer.from(body, "base64url").toString());
  if (payload.exp < Date.now()) return null;
  return payload;
}

// ---------------------------------------------------------------------------
// Deterministic mock scorer — mirrors backend/src/services/geminiService.js
// ---------------------------------------------------------------------------
// ---------------------------------------------------------------------------
// Deterministic mock scorer — imported from the real backend's pure,
// dependency-free scoring module (backend/src/utils/scoring.js) instead of
// keeping a second copy here. Before Week 5 this logic was duplicated
// between the two servers; now there is exactly one implementation, and
// both servers score identically by construction, not by manual sync.
// ---------------------------------------------------------------------------
const path = require("path");
const { SCORE_DIMENSIONS, mockScore: baseMockScore, computeOverall } = require(
  path.join(__dirname, "..", "backend", "src", "utils", "scoring")
);
function mockScore(text, targetRole) {
  const { scores, feedback } = baseMockScore(text, targetRole);
  return { scores, feedback, overallScore: computeOverall(scores) };
}

// ---------------------------------------------------------------------------
// Tiny helpers: JSON body parsing, multipart/form-data parsing, responses
// ---------------------------------------------------------------------------
function readBody(req) {
  return new Promise((resolve, reject) => {
    const chunks = [];
    req.on("data", (c) => chunks.push(c));
    req.on("end", () => resolve(Buffer.concat(chunks)));
    req.on("error", reject);
  });
}

async function readJSON(req) {
  const buf = await readBody(req);
  if (!buf.length) return {};
  try {
    return JSON.parse(buf.toString("utf8"));
  } catch (e) {
    return {};
  }
}

/** Minimal multipart/form-data parser — handles one file field + text fields, matching upload.js's usage. */
async function readMultipart(req, boundary) {
  const buf = await readBody(req);
  const boundaryBuf = Buffer.from(`--${boundary}`);
  const parts = [];
  let start = buf.indexOf(boundaryBuf);
  while (start !== -1) {
    const next = buf.indexOf(boundaryBuf, start + boundaryBuf.length);
    if (next === -1) break;
    const part = buf.slice(start + boundaryBuf.length, next);
    parts.push(part);
    start = next;
  }

  const fields = {};
  let file = null;

  for (const part of parts) {
    const headerEnd = part.indexOf("\r\n\r\n");
    if (headerEnd === -1) continue;
    const headerText = part.slice(0, headerEnd).toString("utf8");
    let content = part.slice(headerEnd + 4);
    // strip trailing \r\n before next boundary
    if (content.slice(-2).toString() === "\r\n") content = content.slice(0, -2);

    const nameMatch = headerText.match(/name="([^"]+)"/);
    const fileNameMatch = headerText.match(/filename="([^"]*)"/);
    const typeMatch = headerText.match(/Content-Type:\s*(.+)/i);
    if (!nameMatch) continue;
    const fieldName = nameMatch[1];

    if (fileNameMatch && fileNameMatch[1]) {
      file = {
        fieldName,
        originalname: fileNameMatch[1],
        mimetype: typeMatch ? typeMatch[1].trim() : "application/octet-stream",
        buffer: content,
        size: content.length,
      };
    } else {
      fields[fieldName] = content.toString("utf8");
    }
  }

  return { fields, file };
}

function send(res, status, body) {
  const json = JSON.stringify(body);
  res.writeHead(status, { "Content-Type": "application/json; charset=utf-8" });
  res.end(json);
}
function sendError(res, status, message, details) {
  send(res, status, { success: false, message, ...(details ? { details } : {}) });
}

function safeUser(u) {
  return { id: u.id, name: u.name, email: u.email, createdAt: u.createdAt };
}
function safeResume(r) {
  return {
    id: r.id,
    fileName: r.fileName,
    mimeType: r.mimeType,
    sizeBytes: r.sizeBytes,
    targetRole: r.targetRole,
    textPreview: r.extractedText.slice(0, 240),
    createdAt: r.createdAt,
    updatedAt: r.updatedAt,
  };
}
function safeAnalysis(a, { populateResume = false } = {}) {
  const resumeField = populateResume
    ? (() => {
        const r = db.resumes.find((x) => x.id === a.resume);
        return r ? { id: r.id, fileName: r.fileName, targetRole: r.targetRole } : a.resume;
      })()
    : a.resume;
  return {
    id: a.id,
    resume: resumeField,
    overallScore: a.overallScore,
    scores: a.scores,
    feedback: a.feedback,
    note: a.note,
    createdAt: a.createdAt,
    updatedAt: a.updatedAt,
  };
}

function getAuthUser(req) {
  const header = req.headers.authorization || "";
  const [scheme, token] = header.split(" ");
  if (scheme !== "Bearer" || !token) return null;
  const payload = verifyToken(token);
  if (!payload) return null;
  return db.users.find((u) => u.id === payload.sub) || null;
}

// ---------------------------------------------------------------------------
// Route handlers
// ---------------------------------------------------------------------------
const EMAIL_RE = /^\S+@\S+\.\S+$/;

async function handleSignup(req, res) {
  const body = await readJSON(req);
  const { name, email, password } = body;
  const details = [];
  if (!name || !String(name).trim()) details.push({ field: "name", message: "Name is required" });
  if (!email || !EMAIL_RE.test(email)) details.push({ field: "email", message: "A valid email is required" });
  if (!password || password.length < 8) details.push({ field: "password", message: "Password must be at least 8 characters" });
  if (details.length) return sendError(res, 422, "Validation failed.", details);

  if (db.users.find((u) => u.email === email.toLowerCase())) {
    return sendError(res, 409, "An account with that email already exists.");
  }

  const { salt, hash } = hashPassword(password);
  const user = {
    id: genId("usr"),
    name: name.trim(),
    email: email.toLowerCase(),
    salt,
    passwordHash: hash,
    createdAt: new Date().toISOString(),
  };
  db.users.push(user);

  const token = signToken(user.id);
  send(res, 201, { success: true, data: { user: safeUser(user), token } });
}

async function handleLogin(req, res) {
  const body = await readJSON(req);
  const { email, password } = body;
  const user = db.users.find((u) => u.email === String(email || "").toLowerCase());
  if (!user || !verifyPassword(password || "", user.salt, user.passwordHash)) {
    return sendError(res, 401, "Incorrect email or password.");
  }
  const token = signToken(user.id);
  send(res, 200, { success: true, data: { user: safeUser(user), token } });
}

function handleGetMe(req, res, user) {
  send(res, 200, { success: true, data: { user: safeUser(user) } });
}

async function handleCreateResume(req, res, user, contentType) {
  const boundaryMatch = contentType.match(/boundary=(.+)$/);
  if (!boundaryMatch) return sendError(res, 400, "Expected multipart/form-data upload.");

  const { fields, file } = await readMultipart(req, boundaryMatch[1]);
  if (!file) return sendError(res, 400, "No file uploaded. Attach a PDF or DOCX under the 'resume' field.");

  const allowed = [
    "application/pdf",
    "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
  ];
  if (!allowed.includes(file.mimetype)) {
    return sendError(res, 400, "Unsupported file type. Upload a PDF or DOCX file.");
  }
  if (file.size > 5 * 1024 * 1024) {
    return sendError(res, 413, "File exceeds the 5MB limit.");
  }

  // Demo-only "extraction": real backend uses pdf-parse/mammoth. Here we just
  // decode what text bytes we can find so the mock scorer has something to seed on.
  const extractedText =
    file.buffer.toString("utf8").replace(/[^\x20-\x7E\n]+/g, " ").trim().slice(0, 4000) ||
    `Resume file: ${file.originalname}`;

  const resume = {
    id: genId("res"),
    user: user.id,
    fileName: file.originalname,
    mimeType: file.mimetype,
    sizeBytes: file.size,
    extractedText: extractedText || `Resume file: ${file.originalname}`,
    targetRole: fields.targetRole || null,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  };
  db.resumes.push(resume);
  send(res, 201, { success: true, data: { resume: safeResume(resume) } });
}

function handleListResumes(req, res, user, query) {
  const page = Math.max(1, parseInt(query.get("page"), 10) || 1);
  const limit = Math.min(50, Math.max(1, parseInt(query.get("limit"), 10) || 20));
  const all = db.resumes
    .filter((r) => r.user === user.id)
    .sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
  const start = (page - 1) * limit;
  const pageItems = all.slice(start, start + limit);
  send(res, 200, {
    success: true,
    count: pageItems.length,
    total: all.length,
    page,
    totalPages: Math.max(1, Math.ceil(all.length / limit)),
    data: { resumes: pageItems.map(safeResume) },
  });
}

function findOwnedResume(res, user, id) {
  const resume = db.resumes.find((r) => r.id === id);
  if (!resume) { sendError(res, 404, "Resume not found."); return null; }
  if (resume.user !== user.id) { sendError(res, 403, "You do not have access to this resume."); return null; }
  return resume;
}

function handleGetResume(req, res, user, id) {
  const resume = findOwnedResume(res, user, id);
  if (!resume) return;
  send(res, 200, { success: true, data: { resume: safeResume(resume) } });
}

async function handleUpdateResume(req, res, user, id) {
  const resume = findOwnedResume(res, user, id);
  if (!resume) return;
  const body = await readJSON(req);
  if (body.targetRole !== undefined) resume.targetRole = body.targetRole;
  resume.updatedAt = new Date().toISOString();
  send(res, 200, { success: true, data: { resume: safeResume(resume) } });
}

function handleDeleteResume(req, res, user, id) {
  const resume = findOwnedResume(res, user, id);
  if (!resume) return;
  db.resumes = db.resumes.filter((r) => r.id !== id);
  db.analyses = db.analyses.filter((a) => a.resume !== id); // cascade
  res.writeHead(204);
  res.end();
}

function handleCreateAnalysis(req, res, user, resumeId) {
  const resume = db.resumes.find((r) => r.id === resumeId);
  if (!resume) return sendError(res, 404, "Resume not found.");
  if (resume.user !== user.id) return sendError(res, 403, "You do not have access to this resume.");

  const { scores, feedback, overallScore } = mockScore(resume.extractedText, resume.targetRole);
  const analysis = {
    id: genId("an"),
    user: user.id,
    resume: resume.id,
    overallScore,
    scores,
    feedback,
    note: null,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  };
  db.analyses.push(analysis);
  send(res, 201, { success: true, data: { analysis: safeAnalysis(analysis) } });
}

function handleListAnalyses(req, res, user, query) {
  const page = Math.max(1, parseInt(query.get("page"), 10) || 1);
  const limit = Math.min(50, Math.max(1, parseInt(query.get("limit"), 10) || 20));
  const all = db.analyses
    .filter((a) => a.user === user.id)
    .sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
  const start = (page - 1) * limit;
  const pageItems = all.slice(start, start + limit);
  send(res, 200, {
    success: true,
    count: pageItems.length,
    total: all.length,
    page,
    totalPages: Math.max(1, Math.ceil(all.length / limit)),
    data: { analyses: pageItems.map((a) => safeAnalysis(a, { populateResume: true })) },
  });
}

function findOwnedAnalysis(res, user, id) {
  const analysis = db.analyses.find((a) => a.id === id);
  if (!analysis) { sendError(res, 404, "Analysis not found."); return null; }
  if (analysis.user !== user.id) { sendError(res, 403, "You do not have access to this analysis."); return null; }
  return analysis;
}

function handleGetAnalysis(req, res, user, id) {
  const analysis = findOwnedAnalysis(res, user, id);
  if (!analysis) return;
  send(res, 200, { success: true, data: { analysis: safeAnalysis(analysis, { populateResume: true }) } });
}

async function handlePatchAnalysis(req, res, user, id) {
  const analysis = findOwnedAnalysis(res, user, id);
  if (!analysis) return;
  const body = await readJSON(req);
  if (body.note !== undefined) analysis.note = body.note;
  analysis.updatedAt = new Date().toISOString();
  send(res, 200, { success: true, data: { analysis: safeAnalysis(analysis, { populateResume: true }) } });
}

function handleDeleteAnalysis(req, res, user, id) {
  const analysis = findOwnedAnalysis(res, user, id);
  if (!analysis) return;
  db.analyses = db.analyses.filter((a) => a.id !== id);
  res.writeHead(204);
  res.end();
}

// ---------------------------------------------------------------------------
// Router
// ---------------------------------------------------------------------------
const server = http.createServer(async (req, res) => {
  const origin = req.headers.origin;
  if (CORS_ORIGINS.includes("*") || (origin && CORS_ORIGINS.includes(origin))) {
    res.setHeader("Access-Control-Allow-Origin", origin || "*");
  }
  res.setHeader("Access-Control-Allow-Methods", "GET,POST,PUT,PATCH,DELETE,OPTIONS");
  res.setHeader("Access-Control-Allow-Headers", "Content-Type, Authorization");

  if (req.method === "OPTIONS") {
    res.writeHead(204);
    return res.end();
  }

  const url = new URL(req.url, `http://${req.headers.host}`);
  const path = url.pathname;

  try {
    if (path === "/api/health" && req.method === "GET") {
      return send(res, 200, { success: true, message: "CVastra AI demo API is running." });
    }

    if (path === "/api/auth/signup" && req.method === "POST") return await handleSignup(req, res);
    if (path === "/api/auth/login" && req.method === "POST") return await handleLogin(req, res);

    // Everything below requires auth
    const user = getAuthUser(req);
    const needsAuth = path !== "/api/auth/signup" && path !== "/api/auth/login" && path !== "/api/health";
    if (needsAuth && !user) {
      return sendError(res, 401, "Authentication required. Provide a Bearer token.");
    }

    if (path === "/api/auth/me" && req.method === "GET") return handleGetMe(req, res, user);

    if (path === "/api/resumes" && req.method === "POST") {
      return await handleCreateResume(req, res, user, req.headers["content-type"] || "");
    }
    if (path === "/api/resumes" && req.method === "GET") return handleListResumes(req, res, user, url.searchParams);

    let m;
    if ((m = path.match(/^\/api\/resumes\/([^/]+)$/))) {
      if (req.method === "GET") return handleGetResume(req, res, user, m[1]);
      if (req.method === "PUT") return await handleUpdateResume(req, res, user, m[1]);
      if (req.method === "DELETE") return handleDeleteResume(req, res, user, m[1]);
    }

    if ((m = path.match(/^\/api\/resumes\/([^/]+)\/analyze$/)) && req.method === "POST") {
      return handleCreateAnalysis(req, res, user, m[1]);
    }

    if (path === "/api/analyses" && req.method === "GET") return handleListAnalyses(req, res, user, url.searchParams);

    if ((m = path.match(/^\/api\/analyses\/([^/]+)$/))) {
      if (req.method === "GET") return handleGetAnalysis(req, res, user, m[1]);
      if (req.method === "PATCH") return await handlePatchAnalysis(req, res, user, m[1]);
      if (req.method === "DELETE") return handleDeleteAnalysis(req, res, user, m[1]);
    }

    return sendError(res, 404, `No route found for ${req.method} ${path}`);
  } catch (err) {
    console.error("DEMO SERVER ERROR:", err);
    return sendError(res, 500, "Something went wrong on the demo server.");
  }
});

server.listen(PORT, () => {
  console.log(`CVastra AI DEMO server (zero external dependencies) listening on port ${PORT}`);
  console.log(`This mirrors the real backend's API contract for local integration testing only.`);
});
