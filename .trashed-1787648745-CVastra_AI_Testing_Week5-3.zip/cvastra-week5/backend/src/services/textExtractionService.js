const pdfParse = require("pdf-parse");
const mammoth = require("mammoth");
const AppError = require("../utils/AppError");
const { isSupportedMimeType } = require("../utils/fileRules");

/**
 * Extracts plain text from an uploaded resume buffer based on its mimetype.
 */
async function extractText(buffer, mimeType) {
  if (!isSupportedMimeType(mimeType)) {
    throw new AppError("Unsupported file type. Upload a PDF or DOCX file.", 400);
  }

  if (mimeType === "application/pdf") {
    const result = await pdfParse(buffer);
    return result.text.trim();
  }

  const result = await mammoth.extractRawText({ buffer });
  return result.value.trim();
}

module.exports = { extractText };
