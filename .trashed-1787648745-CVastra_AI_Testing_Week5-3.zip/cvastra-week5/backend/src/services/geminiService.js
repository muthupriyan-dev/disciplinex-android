const { SCORE_DIMENSIONS, mockScore } = require("../utils/scoring");

const GEMINI_URL =
  "https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent";

function buildPrompt(resumeText, targetRole) {
  return `You are an expert resume reviewer. Score the following resume across exactly these
seven dimensions, each from 0-100: formatting, content, keyword, experience, skills, impact, ats.
${targetRole ? `Weight keyword and skills scoring against this target role: "${targetRole}".` : ""}
Also return 3-5 short, actionable feedback bullet points.

Respond with ONLY valid JSON in this exact shape, no markdown fences:
{
  "scores": { "formatting": 0, "content": 0, "keyword": 0, "experience": 0, "skills": 0, "impact": 0, "ats": 0 },
  "feedback": ["...", "..."]
}

Resume text:
"""
${resumeText.slice(0, 12000)}
"""`;
}

/**
 * Scores resume text against the seven CVastra dimensions.
 * Uses the real Gemini API when GEMINI_API_KEY is set; otherwise falls back
 * to a deterministic mock so the API is fully runnable/testable without a key.
 */
async function scoreResume(resumeText, targetRole) {
  const apiKey = process.env.GEMINI_API_KEY;

  if (!apiKey) {
    return mockScore(resumeText, targetRole);
  }

  const response = await fetch(`${GEMINI_URL}?key=${apiKey}`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      contents: [{ parts: [{ text: buildPrompt(resumeText, targetRole) }] }],
    }),
  });

  if (!response.ok) {
    throw new Error(`Gemini API error: ${response.status} ${response.statusText}`);
  }

  const data = await response.json();
  const raw = data.candidates?.[0]?.content?.parts?.[0]?.text || "";
  const cleaned = raw.replace(/```json|```/g, "").trim();

  let parsed;
  try {
    parsed = JSON.parse(cleaned);
  } catch (e) {
    throw new Error("Gemini returned a response that could not be parsed as JSON.");
  }

  SCORE_DIMENSIONS.forEach((dim) => {
    if (typeof parsed.scores?.[dim] !== "number") {
      throw new Error(`Gemini response missing score for dimension: ${dim}`);
    }
  });

  return { scores: parsed.scores, feedback: parsed.feedback || [] };
}

module.exports = { scoreResume, computeOverall: require("../utils/scoring").computeOverall };
