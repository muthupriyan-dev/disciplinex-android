const express = require("express");
const multer = require("multer");
const { body, param } = require("express-validator");
const validate = require("../middleware/validate");
const requireAuth = require("../middleware/auth");
const { ALLOWED_MIME_TYPES, MAX_RESUME_SIZE_BYTES } = require("../utils/fileRules");
const {
  createResume,
  listResumes,
  getResume,
  updateResume,
  deleteResume,
} = require("../controllers/resumeController");

const router = express.Router();

const upload = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: MAX_RESUME_SIZE_BYTES },
  fileFilter: (req, file, cb) => {
    if (!ALLOWED_MIME_TYPES.includes(file.mimetype)) {
      return cb(new Error("Only PDF and DOCX files are allowed."));
    }
    cb(null, true);
  },
});

router.use(requireAuth); // every resume route requires a logged-in user

router.post("/", upload.single("resume"), createResume);
router.get("/", listResumes);

router.get("/:id", [param("id").isMongoId()], validate, getResume);

router.put(
  "/:id",
  [
    param("id").isMongoId(),
    body("targetRole").optional({ nullable: true }).trim().isLength({ max: 150 }),
  ],
  validate,
  updateResume
);

router.delete("/:id", [param("id").isMongoId()], validate, deleteResume);

module.exports = router;
