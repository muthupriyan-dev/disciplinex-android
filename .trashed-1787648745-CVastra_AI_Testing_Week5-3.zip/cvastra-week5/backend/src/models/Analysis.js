const mongoose = require("mongoose");
const { SCORE_DIMENSIONS } = require("../utils/scoring");

const scoreSubschema = {};
SCORE_DIMENSIONS.forEach((key) => {
  scoreSubschema[key] = { type: Number, required: true, min: 0, max: 100 };
});

const analysisSchema = new mongoose.Schema(
  {
    user: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User",
      required: true,
      index: true,
    },
    resume: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "Resume",
      required: true,
      index: true,
    },
    overallScore: {
      type: Number,
      required: true,
      min: 0,
      max: 100,
    },
    scores: {
      type: scoreSubschema,
      required: true,
    },
    feedback: {
      type: [String],
      default: [],
    },
    note: {
      type: String,
      trim: true,
      maxlength: 500,
      default: null,
    },
  },
  { timestamps: true }
);

analysisSchema.methods.toSafeJSON = function () {
  return {
    id: this._id,
    resume: this.resume,
    overallScore: this.overallScore,
    scores: this.scores,
    feedback: this.feedback,
    note: this.note,
    createdAt: this.createdAt,
    updatedAt: this.updatedAt,
  };
};

module.exports = mongoose.model("Analysis", analysisSchema);
module.exports.SCORE_DIMENSIONS = SCORE_DIMENSIONS;
