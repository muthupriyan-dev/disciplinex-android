const Resume = require("../models/Resume");
const Analysis = require("../models/Analysis");
const AppError = require("../utils/AppError");
const asyncHandler = require("../utils/asyncHandler");
const { extractText } = require("../services/textExtractionService");
const { MAX_RESUME_SIZE_BYTES } = require("../utils/fileRules");
const { parsePagination, buildPaginationMeta } = require("../utils/pagination");

// POST /api/resumes  (multipart/form-data, field name "resume")
const createResume = asyncHandler(async (req, res) => {
  if (!req.file) {
    throw new AppError("No file uploaded. Attach a PDF or DOCX under the 'resume' field.", 400);
  }
  if (req.file.size > MAX_RESUME_SIZE_BYTES) {
    throw new AppError("File exceeds the 5MB limit.", 413);
  }

  const extractedText = await extractText(req.file.buffer, req.file.mimetype);
  if (!extractedText || extractedText.length < 20) {
    throw new AppError("Could not extract meaningful text from that file.", 422);
  }

  const resume = await Resume.create({
    user: req.user._id,
    fileName: req.file.originalname,
    mimeType: req.file.mimetype,
    sizeBytes: req.file.size,
    extractedText,
    targetRole: req.body.targetRole || null,
  });

  res.status(201).json({ success: true, data: { resume: resume.toSafeJSON() } });
});

// GET /api/resumes?page=1&limit=20
const listResumes = asyncHandler(async (req, res) => {
  const { page, limit, skip } = parsePagination(req.query);

  const [resumes, total] = await Promise.all([
    Resume.find({ user: req.user._id }).sort({ createdAt: -1 }).skip(skip).limit(limit),
    Resume.countDocuments({ user: req.user._id }),
  ]);

  res.status(200).json({
    success: true,
    count: resumes.length,
    total,
    ...buildPaginationMeta(page, limit, total),
    data: { resumes: resumes.map((r) => r.toSafeJSON()) },
  });
});

// GET /api/resumes/:id
const getResume = asyncHandler(async (req, res) => {
  const resume = await findOwnedResume(req);
  res.status(200).json({ success: true, data: { resume: resume.toSafeJSON() } });
});

// PUT /api/resumes/:id
const updateResume = asyncHandler(async (req, res) => {
  const resume = await findOwnedResume(req);
  if (req.body.targetRole !== undefined) resume.targetRole = req.body.targetRole;
  await resume.save();
  res.status(200).json({ success: true, data: { resume: resume.toSafeJSON() } });
});

// DELETE /api/resumes/:id
const deleteResume = asyncHandler(async (req, res) => {
  const resume = await findOwnedResume(req);
  await Analysis.deleteMany({ resume: resume._id }); // cascade
  await resume.deleteOne();
  res.status(204).send();
});

async function findOwnedResume(req) {
  const resume = await Resume.findById(req.params.id);
  if (!resume) throw new AppError("Resume not found.", 404);
  if (String(resume.user) !== String(req.user._id)) {
    throw new AppError("You do not have access to this resume.", 403);
  }
  return resume;
}

module.exports = { createResume, listResumes, getResume, updateResume, deleteResume };
