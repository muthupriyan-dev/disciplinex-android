/**
 * utils/scoring.js — pure resume-scoring logic, deliberately dependency-free.
 *
 * Found during Week 5 code review: this logic previously lived partly in
 * models/Analysis.js (which requires mongoose) and partly in
 * geminiService.js (which required Analysis.js just to get the dimension
 * list). That meant geminiService.js — whose mock-scoring path has nothing
 * to do with the database — could not be unit tested without mongoose
 * installed. Extracting the pure math here fixes that: this module has zero
 * dependencies and is safe to unit test in complete isolation.
 */

const SCORE_DIMENSIONS = [
  "formatting",
  "content",
  "keyword",
  "experience",
  "skills",
  "impact",
  "ats",
];

/** Simple string hash -> deterministic pseudo-random int in [min, max]. */
function seededScore(seed, min, max) {
  let hash = 0;
  for (let i = 0; i < seed.length; i++) {
    hash = (hash << 5) - hash + seed.charCodeAt(i);
    hash |= 0;
  }
  const normalized = Math.abs(hash % 1000) / 1000;
  return Math.round(min + normalized * (max - min));
}

const MOCK_FEEDBACK_POOL = [
  "Add quantifiable metrics to project bullet points (e.g. \"reduced load time by 40%\").",
  "Include more role-specific keywords for the target position.",
  "Formatting is clean and ATS-friendly — keep the single-column layout.",
  "Trim the summary section to 2-3 lines so recruiters reach experience faster.",
  "List technical skills in a scannable group rather than inline prose.",
  "Use stronger action verbs to open each bullet point.",
  "Experience section reads well but is missing measurable outcomes for the most recent role.",
  "Consider a dedicated projects section to surface relevant work not tied to employment.",
];

/**
 * Deterministic mock scorer: same resume text + target role always produces
 * the same scores (seeded by content, not Math.random()), so results are
 * stable across repeated analysis and reproducible in tests.
 */
function mockScore(resumeText, targetRole) {
  const seed = String(resumeText).slice(0, 500) + (targetRole || "");
  const scores = {};
  SCORE_DIMENSIONS.forEach((dim) => {
    scores[dim] = seededScore(seed + dim, 55, 96);
  });
  const feedback = MOCK_FEEDBACK_POOL.filter(
    (_, i) => seededScore(seed + i, 0, 1) === 1 || i < 3
  ).slice(0, 4);
  return { scores, feedback };
}

/** Validates that a scores object has a valid number (0-100) for every dimension. */
function validateScores(scores) {
  if (!scores || typeof scores !== "object") return false;
  return SCORE_DIMENSIONS.every(
    (dim) => typeof scores[dim] === "number" && scores[dim] >= 0 && scores[dim] <= 100
  );
}

function computeOverall(scores) {
  const values = SCORE_DIMENSIONS.map((dim) => scores[dim]);
  return Math.round(values.reduce((a, b) => a + b, 0) / values.length);
}

module.exports = { SCORE_DIMENSIONS, seededScore, mockScore, validateScores, computeOverall };
