/**
 * utils/pagination.js — pure query-param parsing for list endpoints.
 *
 * Week 5 addition: GET /api/resumes and GET /api/analyses previously
 * returned every record for a user with no limit. Fine for a handful of
 * records, but an unbounded find() is a well-known scalability trap — both
 * in payload size and in DB load as history grows. Centralized here so the
 * parsing/bounds logic (and its test coverage) isn't duplicated between the
 * two controllers, same rationale as fileRules.js and scoring.js.
 */

const DEFAULT_LIMIT = 20;
const MAX_LIMIT = 50;

/** Parses page/limit from a query object (e.g. req.query), clamping to sane bounds. */
function parsePagination(query = {}) {
  const rawPage = parseInt(query.page, 10);
  const rawLimit = parseInt(query.limit, 10);

  const page = Number.isInteger(rawPage) && rawPage > 0 ? rawPage : 1;
  const limit =
    Number.isInteger(rawLimit) && rawLimit > 0 ? Math.min(rawLimit, MAX_LIMIT) : DEFAULT_LIMIT;

  return { page, limit, skip: (page - 1) * limit };
}

function buildPaginationMeta(page, limit, total) {
  return { page, totalPages: Math.max(1, Math.ceil(total / limit)) };
}

module.exports = { DEFAULT_LIMIT, MAX_LIMIT, parsePagination, buildPaginationMeta };
