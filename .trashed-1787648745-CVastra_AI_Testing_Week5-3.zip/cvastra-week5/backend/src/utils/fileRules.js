/**
 * utils/fileRules.js — single source of truth for resume upload constraints.
 *
 * Found during Week 5 code review: the 5MB size limit was duplicated in
 * resumeController.js and resumeRoutes.js, and the allowed MIME type list
 * was duplicated three times (Resume.js model enum, resumeRoutes.js multer
 * filter, textExtractionService.js). A change to one without the others
 * (e.g. adding .doc support) would silently create inconsistent validation
 * between layers. Centralized here instead.
 */

const MAX_RESUME_SIZE_BYTES = 5 * 1024 * 1024; // 5MB

const ALLOWED_MIME_TYPES = [
  "application/pdf",
  "application/vnd.openxmlformats-officedocument.wordprocessingml.document", // .docx
];

function isSupportedMimeType(mimeType) {
  return ALLOWED_MIME_TYPES.includes(mimeType);
}

function isWithinSizeLimit(sizeBytes) {
  return typeof sizeBytes === "number" && sizeBytes > 0 && sizeBytes <= MAX_RESUME_SIZE_BYTES;
}

module.exports = { MAX_RESUME_SIZE_BYTES, ALLOWED_MIME_TYPES, isSupportedMimeType, isWithinSizeLimit };
