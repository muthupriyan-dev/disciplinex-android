# CVastra AI — Testing, Debugging & Optimization (Week 5)

NSDC Junior Full Stack Developer Internship — Week 5 Task.

Every test in this submission was actually written **and executed** — none
of the pass/fail numbers below are estimates. This sandbox has no npm/pip
registry access, so the strategy was to lean on what's runnable without
installing anything: Node 22's built-in test runner (`node:test`) and
built-in `fetch`, plus Playwright (already present) for browser-level e2e
tests. See `debugging-report.md` for the real bugs this process found —
including one genuine 500 error that only showed up under integration
testing, not unit testing or syntax checks.

## Folder structure

```
cvastra-week5/
  frontend/                 Front-end (refactored this week — see below)
  backend/                  Express + MongoDB backend (refactored this week)
  demo-server/               Zero-dependency server mirroring the backend contract
  tests/
    backend-unit/            37 tests — pure logic, no DB, no network
    backend-integration/     26 tests — real HTTP against a live server
    frontend-unit/           11 tests — pure JS, no browser
    frontend-e2e/            8 tests — real Chromium via Playwright
  performance/                Benchmarks — see "Optimization summary" below
  test-logs/                  Captured stdout from actual test runs
  debugging-report.md         Real bugs found this week, root cause + fix
  README.md                   this file
```

## Running the tests

### Backend unit tests (37 tests, no server needed)
```bash
node --test tests/backend-unit/*.test.js
```
Tests `utils/scoring.js`, `utils/fileRules.js`, `utils/pagination.js`,
`AppError`, and `asyncHandler` — all pure logic, dependency-free, so they run
with zero setup.

### Backend integration tests (26 tests, needs a running server)
```bash
node demo-server/server.js &
node --test tests/backend-integration/api.test.js
```
Real HTTP requests via Node's built-in `fetch` against a real running
server — auth, resume CRUD, analysis CRUD, ownership checks, cascade
deletes, and pagination. Can also point at the real backend:
```bash
cd backend && npm install && npm run dev &
TEST_API_BASE=http://localhost:5000/api node --test ../tests/backend-integration/api.test.js
```

### Frontend unit tests (11 tests, no browser needed)
```bash
node --test tests/frontend-unit/*.test.js
```
Tests `frontend/js/utils.js` (`escapeHTML`, `scoreClass`, `formatDate`)
directly under Node — this module is deliberately DOM-free (see its header
comment) specifically so it can be tested without a browser.

### Frontend end-to-end tests (8 tests, needs both servers running)
```bash
node demo-server/server.js &
python3 -m http.server 8791 --directory frontend &
python3 tests/frontend-e2e/app_spec.py
```
Drives real Chromium via Playwright through signup, upload, analyze,
dashboard, delete, and logout — plus error states (invalid file type,
nonexistent analysis ID, blocked short-password submission) and a
zero-unexpected-console-errors check.

### Backend's own Jest suite (from Week 3 — needs `npm install`)
`backend/tests/` still has the original Jest + Supertest + mongodb-memory-server
suite from Week 3 (auth/resume/analysis lifecycle against a real, if
in-memory, MongoDB). It needs `npm install`, which isn't possible in this
sandbox — see `backend/README.md`'s note on that. The `node:test`-based
suites above are what's actually been run for this submission.

## Testing strategy

**Unit tests** target pure functions with no I/O — the fastest, most
reliable layer, and the only one that runs with zero setup. This week's
refactor (extracting `utils/scoring.js`, `utils/fileRules.js`,
`utils/pagination.js`, and `frontend/js/utils.js`) was done specifically to
make more of the codebase reachable by this layer — see
`debugging-report.md` #5 for why `geminiService.js` couldn't be unit tested
*before* that refactor.

**Integration tests** hit a real running server over real HTTP, checking
that routing, middleware, validation, and ownership checks compose
correctly — not just that each piece works alone. This is the layer that
caught the one real production-affecting bug this week (a route wired to
the wrong handler signature after a refactor — see debugging-report.md #4).
Unit tests for the pagination logic passed the whole time; only an actual
request to the actual route exposed that the router never passed the query
string through.

**End-to-end tests** drive a real browser against the real static files and
a real server, covering what a user actually does: sign up, upload, watch
the score render, navigate, delete, log out — plus the failure paths (wrong
file type, broken links, short passwords). This is also the layer that
caught a **test-suite bug** (flaky waits — debugging-report.md #2), which is
its own useful outcome: an e2e suite that "passes" nondeterministically is
worse than no suite, because it teaches you to ignore red runs.

**What's covered vs. what isn't:** all four CRUD resources (auth, resumes,
analyses) have integration coverage for the happy path, validation
failures, and cross-user ownership checks (403s). Not covered: load beyond
what's in `performance/` (no sustained concurrency test), and the real
backend's Jest suite couldn't be executed in this environment (documented
above, not hidden).

## Optimization summary

Two benchmarks **did not** find a bottleneck — that's reported honestly
below rather than replaced with a fabricated fix. One benchmark **did**
find a real, measurable win, which was implemented. One feature
(pagination) was added proactively for a known scaling risk that doesn't
show up yet at this data volume but will as usage grows.

### 1. `escapeHTML`: DOM allocation → pure string replace — **1.57x faster, implemented**

Before this week, `escapeHTML` existed as three separate copies
(`auth.js`, `dashboard.js`, `detail.js`), each creating and discarding a
real `document.createElement('div')` per call just to use its
`textContent`/`innerHTML` round-trip. Consolidated into one pure,
regex-based implementation in `utils.js` with no DOM access at all.

Measured in a real browser via Playwright (`performance/benchmark_escape_html.py`),
50,000 calls per run, 5 runs each, median reported:

| Version | Median (50k calls) | Per-call |
|---|---|---|
| OLD (DOM `createElement`) | 49.40 ms | 0.988 µs |
| NEW (pure regex replace) | 31.40 ms | 0.628 µs |

**1.57x faster**, and it also fixed the triplication itself (one
implementation instead of three to keep in sync) and made the function
unit-testable without a browser (see `tests/frontend-unit/utils.test.js`).

### 2. Hypothesis: linear-scan user lookup slows down as users grow — **tested, not confirmed at this scale**

`demo-server`'s `getAuthUser()` does `db.users.find(u => u.id === payload.sub)`
on every authenticated request — an O(n) scan. The hypothesis: this should
measurably slow down as the user table grows, and the record placed last
should be slower to find than the one placed first.

Seeded 2,000 users, then compared `GET /api/auth/me` latency for the
first-created vs. last-created user (200 samples each,
`performance/benchmark.js`):

| | avg | p50 | p95 |
|---|---|---|---|
| Last-created user (worst case) | 0.85 ms | 0.69 ms | 2.21 ms |
| First-created user (best case) | 0.81 ms | 0.59 ms | 1.52 ms |

Ratio: **1.06x** — essentially noise. V8's array scan over ~2,000 simple
objects is fast enough (sub-millisecond either way) that the O(n) vs O(1)
distinction doesn't show up at a realistic scale for this app. **No change
made** — optimizing this now would be complexity added for a benefit that
doesn't exist yet. Full output in `performance/BEFORE-benchmark-output.txt`.

### 3. Hypothesis: the hand-rolled multipart parser scales badly for large files — **tested, not confirmed**

`demo-server`'s multipart parser uses `buffer.indexOf()` to find part
boundaries. Hypothesis: this could scale worse than linearly for large
files. Measured upload latency across file sizes
(`performance/benchmark-upload.js`):

| File size | Median latency | ms/KB |
|---|---|---|
| 10 KB | 6.45 ms | 0.645 |
| 100 KB | 6.00 ms | 0.060 |
| 1 MB | 12.72 ms | 0.012 |
| 4 MB | 24.61 ms | 0.006 |

ms/KB *decreases* as file size grows (fixed per-request overhead gets
amortized) — the parser scales linearly-or-better, no quadratic blowup.
**No change made.** Full output in `performance/BEFORE-upload-benchmark-output.txt`.

### 4. Pagination on `GET /api/resumes` and `GET /api/analyses` — **implemented proactively**

Unlike #2 and #3, this wasn't triggered by a measured bottleneck — at
current data volumes, returning an unbounded list is not yet slow. It's a
well-known scaling trap regardless: response payload size and DB read cost
both grow unboundedly with a user's history, with no way to opt out. Added
`?page=&limit=` support (default 20, max 50 per page) to both the real
backend (`Model.find().skip().limit()` + `countDocuments()`, using the
indexes already on `user` in both schemas) and the demo server
(`Array.slice`), with shared parsing logic in `backend/src/utils/pagination.js`
so the bounds-checking has one implementation and one set of tests
(`tests/backend-unit/pagination.test.js`) instead of being duplicated
per-controller. Integration-tested end-to-end (`tests/backend-integration/api.test.js`),
including the exact bug this introduced and then fixed — see
`debugging-report.md` #4.

## Known limitations

- The real backend's original Jest suite (Week 3) needs `npm install`,
  unavailable in this sandbox — not re-verified this week, only the
  `node:test` suites above were actually executed.
- Performance benchmarks run against `demo-server` (in-memory, single
  process), not the real MongoDB-backed backend — relative comparisons
  (DOM vs. no-DOM, file-size scaling) are architecture-independent, but
  absolute latency numbers would differ against a real database with
  network round-trips.
- No sustained-concurrency / stress test (e.g. 100 simultaneous uploads) —
  the benchmarks here measure sequential latency at increasing data
  volume, not throughput under concurrent load.
