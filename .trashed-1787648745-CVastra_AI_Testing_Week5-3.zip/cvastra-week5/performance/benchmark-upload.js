/**
 * performance/benchmark-upload.js
 * ---------------------------------------------------------------------------
 * The first hypothesis (O(n) array scan on GET /api/auth/me) turned out not
 * to matter at realistic scale — see BEFORE-benchmark-output.txt and
 * README.md's "What we hypothesized vs what we found" section.
 *
 * Second hypothesis: demo-server's hand-rolled multipart parser
 * (readMultipart in server.js) finds the boundary with repeated
 * `buf.indexOf(boundaryBuf, start)` calls. For a single-file upload with
 * few fields this is only 2-3 indexOf calls, so it should be cheap — but
 * indexOf on a large buffer is itself O(buffer length), so a large resume
 * file could still be slow if something re-scans the whole buffer
 * unnecessarily. This benchmark checks whether upload latency scales
 * linearly (expected — you can't parse a file without reading its bytes)
 * or worse than linearly (would indicate a real bug, e.g. an accidental
 * quadratic scan).
 * ---------------------------------------------------------------------------
 */
const BASE = process.env.BENCH_API_BASE || "http://localhost:5000/api";

async function signup() {
  const res = await fetch(`${BASE}/auth/signup`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      name: "Upload Bench",
      email: `uploadbench${Date.now()}${Math.random()}@example.com`,
      password: "correcthorse123",
    }),
  });
  const json = await res.json();
  return json.data.token;
}

function buildMultipartBody(fileSizeBytes) {
  const boundary = "----benchBoundary" + Date.now();
  // Fill with printable ASCII so it exercises the same code path as a real
  // PDF's text-extraction fallback in the demo server.
  const filler = Buffer.alloc(fileSizeBytes, "A".charCodeAt(0));
  const head = Buffer.from(
    `--${boundary}\r\nContent-Disposition: form-data; name="resume"; filename="bench.pdf"\r\nContent-Type: application/pdf\r\n\r\n`
  );
  const tail = Buffer.from(`\r\n--${boundary}--\r\n`);
  return { body: Buffer.concat([head, filler, tail]), contentType: `multipart/form-data; boundary=${boundary}` };
}

async function timeUpload(token, sizeBytes) {
  const { body, contentType } = buildMultipartBody(sizeBytes);
  const t0 = performance.now();
  const res = await fetch(`${BASE}/resumes`, {
    method: "POST",
    headers: { Authorization: `Bearer ${token}`, "Content-Type": contentType },
    body,
  });
  await res.json();
  const elapsed = performance.now() - t0;
  return { elapsed, status: res.status };
}

async function main() {
  const token = await signup();
  const sizes = [
    { label: "10 KB", bytes: 10 * 1024 },
    { label: "100 KB", bytes: 100 * 1024 },
    { label: "1 MB", bytes: 1 * 1024 * 1024 },
    { label: "4 MB (near the 5MB limit)", bytes: 4 * 1024 * 1024 },
  ];

  console.log("Upload latency vs file size (5 uploads per size, median reported):\n");
  const results = [];
  for (const { label, bytes } of sizes) {
    const timings = [];
    for (let i = 0; i < 5; i++) {
      const { elapsed, status } = await timeUpload(token, bytes);
      if (status !== 201) {
        console.log(`  ${label}: unexpected status ${status}`);
        continue;
      }
      timings.push(elapsed);
    }
    timings.sort((a, b) => a - b);
    const median = timings[Math.floor(timings.length / 2)];
    console.log(`  ${label.padEnd(28)} median: ${median.toFixed(2)} ms   (all: ${timings.map((t) => t.toFixed(1)).join(", ")})`);
    results.push({ label, bytes, medianMs: median });
  }

  console.log("\nScaling check (ms per KB, should be roughly constant if parsing is linear):");
  results.forEach((r) => {
    console.log(`  ${r.label.padEnd(28)} ${(r.medianMs / (r.bytes / 1024)).toFixed(4)} ms/KB`);
  });
}

main().catch((err) => {
  console.error("Benchmark failed:", err);
  process.exit(1);
});
