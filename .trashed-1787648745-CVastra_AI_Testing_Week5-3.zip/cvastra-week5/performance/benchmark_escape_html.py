"""
performance/benchmark_escape_html.py
-------------------------------------------------------------------------
Benchmarks the Week 5 escapeHTML refactor (see frontend/js/utils.js header
comment) directly in a real browser via Playwright: the OLD implementation
(three separate copies existed in auth.js/dashboard.js/detail.js, each
creating a real DOM element per call) vs the NEW implementation (a single
pure regex-based replace in utils.js, no DOM access).

Run with: python3 performance/benchmark_escape_html.py
(No server needed — this only needs a browser page to run JS in.)
-------------------------------------------------------------------------
"""
from playwright.sync_api import sync_playwright

N_CALLS = 50000
SAMPLE_STRING = "Senior Frontend Developer & <Team Lead> \"React/TypeScript\" 'expert'"

OLD_DOM_BASED_JS = """
() => {
  function escapeHTMLOld(str) {
    const div = document.createElement('div');
    div.textContent = str;
    return div.innerHTML;
  }
  const s = %r;
  const t0 = performance.now();
  for (let i = 0; i < %d; i++) {
    escapeHTMLOld(s);
  }
  return performance.now() - t0;
}
""" % (SAMPLE_STRING, N_CALLS)

NEW_PURE_JS = """
() => {
  const ESCAPE_MAP = { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' };
  function escapeHTMLNew(str) {
    return String(str).replace(/[&<>"']/g, (ch) => ESCAPE_MAP[ch]);
  }
  const s = %r;
  const t0 = performance.now();
  for (let i = 0; i < %d; i++) {
    escapeHTMLNew(s);
  }
  return performance.now() - t0;
}
""" % (SAMPLE_STRING, N_CALLS)


def main():
    with sync_playwright() as p:
        browser = p.chromium.launch()
        page = browser.new_page()
        page.goto("about:blank")

        # Run each version 5 times and take the median, alternating order to
        # cancel out any warm-up/JIT bias.
        old_times = []
        new_times = []
        for i in range(5):
            if i % 2 == 0:
                old_times.append(page.evaluate(OLD_DOM_BASED_JS))
                new_times.append(page.evaluate(NEW_PURE_JS))
            else:
                new_times.append(page.evaluate(NEW_PURE_JS))
                old_times.append(page.evaluate(OLD_DOM_BASED_JS))

        browser.close()

    old_times.sort()
    new_times.sort()
    old_median = old_times[len(old_times) // 2]
    new_median = new_times[len(new_times) // 2]

    print(f"escapeHTML benchmark — {N_CALLS:,} calls per run, 5 runs each, median reported\n")
    print(f"  OLD (DOM createElement per call): {old_median:.2f} ms   (all runs: {[round(t,1) for t in old_times]})")
    print(f"  NEW (pure regex replace):         {new_median:.2f} ms   (all runs: {[round(t,1) for t in new_times]})")
    print(f"\n  Speedup: {old_median / new_median:.2f}x faster")
    print(f"  Per-call: OLD {old_median / N_CALLS * 1000:.3f} µs vs NEW {new_median / N_CALLS * 1000:.3f} µs")


if __name__ == "__main__":
    main()
