/**
 * performance/benchmark.js
 * ---------------------------------------------------------------------------
 * Measures real request latency against a running demo-server instance.
 * No dependencies (no autocannon/k6 — not installable here), just Node's
 * built-in fetch and a manual timing loop.
 *
 * What it measures: the cost of GET /api/auth/me as the user table grows.
 * demo-server's getAuthUser() does `db.users.find(u => u.id === payload.sub)`
 * — a linear scan — on EVERY authenticated request (which is all of them
 * except signup/login/health). That means the single most-called function
 * in the whole server gets slower as more people sign up, independent of
 * which endpoint they're hitting.
 *
 * Usage:
 *   node server.js &                          # start the server under test
 *   node performance/benchmark.js              # seeds users, measures, prints results
 * ---------------------------------------------------------------------------
 */

const BASE = process.env.BENCH_API_BASE || "http://localhost:5000/api";
const SEED_USERS = Number(process.env.BENCH_SEED_USERS || 2000);
const SAMPLE_REQUESTS = Number(process.env.BENCH_SAMPLES || 300);

function uniqueEmail(i) {
  return `bench${Date.now()}_${i}@example.com`;
}

async function signup(i) {
  const res = await fetch(`${BASE}/auth/signup`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ name: `Bench User ${i}`, email: uniqueEmail(i), password: "correcthorse123" }),
  });
  const json = await res.json();
  return json.data.token;
}

function percentile(sortedArr, p) {
  const idx = Math.floor((p / 100) * (sortedArr.length - 1));
  return sortedArr[idx];
}

function summarize(label, timingsMs) {
  const sorted = [...timingsMs].sort((a, b) => a - b);
  const avg = timingsMs.reduce((a, b) => a + b, 0) / timingsMs.length;
  console.log(`\n${label}`);
  console.log(`  requests: ${timingsMs.length}`);
  console.log(`  avg:      ${avg.toFixed(2)} ms`);
  console.log(`  p50:      ${percentile(sorted, 50).toFixed(2)} ms`);
  console.log(`  p95:      ${percentile(sorted, 95).toFixed(2)} ms`);
  console.log(`  p99:      ${percentile(sorted, 99).toFixed(2)} ms`);
  console.log(`  max:      ${sorted[sorted.length - 1].toFixed(2)} ms`);
  return { avg, p50: percentile(sorted, 50), p95: percentile(sorted, 95), p99: percentile(sorted, 99) };
}

async function main() {
  console.log(`Target: ${BASE}`);
  console.log(`Seeding ${SEED_USERS} users (this establishes the linear-scan table size)...`);

  const seedStart = Date.now();
  // Seed sequentially in small concurrent batches to avoid overwhelming the
  // single-threaded demo server's event loop with connection storms.
  const BATCH = 25;
  let firstUserToken = null;
  let lastUserToken = null;
  for (let i = 0; i < SEED_USERS; i += BATCH) {
    const batchSize = Math.min(BATCH, SEED_USERS - i);
    const tokens = await Promise.all(
      Array.from({ length: batchSize }, (_, j) => signup(i + j))
    );
    if (i === 0) firstUserToken = tokens[0];
    lastUserToken = tokens[tokens.length - 1];
  }
  console.log(`Seeded ${SEED_USERS} users in ${Date.now() - seedStart}ms`);

  // Worst case for a linear scan: the user whose record was inserted LAST
  // has to be scanned past every other record first.
  console.log(`\nMeasuring GET /api/auth/me for the LAST-created user (worst case for a linear scan)...`);
  const lastUserTimings = [];
  for (let i = 0; i < SAMPLE_REQUESTS; i++) {
    const t0 = performance.now();
    const res = await fetch(`${BASE}/auth/me`, { headers: { Authorization: `Bearer ${lastUserToken}` } });
    await res.json();
    lastUserTimings.push(performance.now() - t0);
  }
  const lastStats = summarize(`GET /api/auth/me — last-created user (n=${SEED_USERS} users in table)`, lastUserTimings);

  console.log(`\nMeasuring GET /api/auth/me for the FIRST-created user (best case — found at index 0)...`);
  const firstUserTimings = [];
  for (let i = 0; i < SAMPLE_REQUESTS; i++) {
    const t0 = performance.now();
    const res = await fetch(`${BASE}/auth/me`, { headers: { Authorization: `Bearer ${firstUserToken}` } });
    await res.json();
    firstUserTimings.push(performance.now() - t0);
  }
  const firstStats = summarize(`GET /api/auth/me — first-created user`, firstUserTimings);

  console.log(`\n--- Summary ---`);
  console.log(`Last-user avg / First-user avg ratio: ${(lastStats.avg / firstStats.avg).toFixed(2)}x`);
  console.log(
    lastStats.avg > firstStats.avg * 1.3
      ? "=> Confirms position-dependent latency: consistent with an O(n) linear scan, not O(1)."
      : "=> No meaningful position-dependent latency detected — lookup appears O(1)."
  );

  console.log(`\nRESULT_JSON=${JSON.stringify({ seedUsers: SEED_USERS, sampleRequests: SAMPLE_REQUESTS, lastUser: lastStats, firstUser: firstStats })}`);
}

main().catch((err) => {
  console.error("Benchmark failed:", err);
  process.exit(1);
});
