/**
 * dashboard.js — behavior for dashboard.html (view 2 of 3).
 * Data now comes from GET /api/analyses, where each record's `resume` field
 * is populated with { fileName, targetRole } by the backend.
 */
(function () {
  if (!CVastraAuth.requireAuthOrRedirect()) return;

  const statsEl = document.getElementById("stats");
  const regionEl = document.getElementById("history-region");

  function renderStats(history) {
    if (history.length === 0) {
      statsEl.innerHTML = "";
      return;
    }
    const avg = Math.round(history.reduce((sum, r) => sum + r.overallScore, 0) / history.length);
    const best = Math.max(...history.map((r) => r.overallScore));
    statsEl.innerHTML = `
      <div class="stat-block">
        <span class="stat-num">${history.length}</span>
        <span class="stat-label">Total fittings</span>
      </div>
      <div class="stat-block">
        <span class="stat-num">${avg}</span>
        <span class="stat-label">Average score</span>
      </div>
      <div class="stat-block">
        <span class="stat-num">${best}</span>
        <span class="stat-label">Best score</span>
      </div>
    `;
  }

  function cardHTML(record) {
    const cls = scoreClass(record.overallScore);
    const resume = record.resume || {};
    const fileName = resume.fileName || "Resume";
    const role = resume.targetRole ? `Target: ${escapeHTML(resume.targetRole)}` : "No target role specified";
    return `
      <a class="swatch-card" href="detail.html?id=${encodeURIComponent(record.id)}">
        <div class="fname">${escapeHTML(fileName)}</div>
        <div class="role-tag">${role}</div>
        <div class="score-row">
          <span class="score-num ${cls}">${record.overallScore}</span>
          <span class="score-label">/ 100 overall</span>
        </div>
        <div class="date">${formatDate(record.createdAt)}</div>
      </a>
    `;
  }

  function renderHistory(history) {
    if (history.length === 0) {
      regionEl.innerHTML = `
        <div class="empty-state">
          <h3>No fittings yet</h3>
          <p>Upload a resume to see it measured here.</p>
          <a href="index.html" class="btn">Start your first analysis</a>
        </div>
      `;
      return;
    }
    const grid = document.createElement("div");
    grid.className = "swatch-grid";
    grid.innerHTML = history.map(cardHTML).join("");
    regionEl.innerHTML = "";
    regionEl.appendChild(grid);
  }

  function renderError(err) {
    const message =
      err.status === 0
        ? "Could not reach the CVastra API. Make sure the backend is running (see README)."
        : err.message || "Something went wrong loading your history.";
    regionEl.innerHTML = `<div class="error-banner"><strong>Couldn't load your dashboard</strong>${escapeHTML(message)}</div>`;
    statsEl.innerHTML = "";
  }

  async function init() {
    try {
      const history = await CVastraAPI.getHistory();
      renderStats(history);
      renderHistory(history);
    } catch (err) {
      console.error(err);
      if (err.status === 401) {
        CVastraAuth.logout();
        return;
      }
      renderError(err);
    }
  }

  init();
})();
