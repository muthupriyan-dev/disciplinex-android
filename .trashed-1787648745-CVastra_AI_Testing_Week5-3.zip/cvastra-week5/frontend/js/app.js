/**
 * app.js — shared across all pages.
 * Handles the mobile nav toggle. Pure helpers (scoreClass, formatDate,
 * escapeHTML) now live in utils.js — see that file's header comment for why.
 */

document.addEventListener("DOMContentLoaded", () => {
  const toggle = document.querySelector(".nav-toggle");
  const nav = document.querySelector(".main-nav");
  if (toggle && nav) {
    toggle.addEventListener("click", () => {
      const isOpen = nav.classList.toggle("open");
      toggle.setAttribute("aria-expanded", String(isOpen));
    });
  }
});
