/**
 * utils.js — pure, DOM-free helper functions shared across pages.
 *
 * Week 5 refactor: escapeHTML() previously existed as three separate copies
 * (auth.js, dashboard.js, detail.js), each creating and discarding a real
 * DOM element (`document.createElement('div')`) per call just to use its
 * `.textContent`/`.innerHTML` round-trip for escaping. That's three sources
 * of truth to keep in sync, and a DOM allocation on every render of every
 * card/row — measurable overhead on the dashboard when history grows long
 * (see performance/README.md for a before/after benchmark). Replaced with a
 * single, pure, table-based string replace: no DOM access at all, so it's
 * also usable server-side and directly unit-testable with node:test.
 *
 * Loaded as a plain <script> before app.js/dashboard.js/etc, so it also
 * exports itself to `module.exports` when running under Node (for tests)
 * without affecting browser behavior.
 */

const ESCAPE_MAP = {
  "&": "&amp;",
  "<": "&lt;",
  ">": "&gt;",
  '"': "&quot;",
  "'": "&#39;",
};

function escapeHTML(str) {
  return String(str).replace(/[&<>"']/g, (ch) => ESCAPE_MAP[ch]);
}

function scoreClass(value) {
  if (value >= 80) return "score-good";
  if (value >= 65) return "score-mid";
  return "score-low";
}

function formatDate(iso) {
  if (iso === null || iso === undefined || iso === "") return "";
  const d = new Date(iso);
  if (Number.isNaN(d.getTime())) return "";
  return d.toLocaleDateString(undefined, { year: "numeric", month: "short", day: "numeric" });
}

if (typeof module !== "undefined" && module.exports) {
  module.exports = { escapeHTML, scoreClass, formatDate };
}
