const test = require("node:test");
const assert = require("node:assert/strict");
const AppError = require("../../backend/src/utils/AppError");
const asyncHandler = require("../../backend/src/utils/asyncHandler");

test("AppError sets message, statusCode, and isOperational", () => {
  const err = new AppError("Not found.", 404);
  assert.equal(err.message, "Not found.");
  assert.equal(err.statusCode, 404);
  assert.equal(err.isOperational, true);
  assert.ok(err instanceof Error);
});

test("AppError carries optional details payload", () => {
  const details = [{ field: "email", message: "required" }];
  const err = new AppError("Validation failed.", 422, details);
  assert.deepEqual(err.details, details);
});

test("AppError.details defaults to null when omitted", () => {
  const err = new AppError("Server error.", 500);
  assert.equal(err.details, null);
});

test("AppError has a proper stack trace (not swallowed)", () => {
  const err = new AppError("Oops.", 500);
  assert.ok(typeof err.stack === "string" && err.stack.length > 0);
});

test("asyncHandler forwards a resolved value's side effects normally", async () => {
  let called = false;
  const handler = asyncHandler(async (req, res) => {
    called = true;
    res.send("ok");
  });
  const res = { send: () => {} };
  const next = () => { throw new Error("next() should not be called on success"); };
  await handler({}, res, next);
  assert.equal(called, true);
});

test("asyncHandler forwards a rejected promise to next() instead of throwing", async () => {
  const boom = new AppError("Boom.", 400);
  const handler = asyncHandler(async () => {
    throw boom;
  });

  let caught = null;
  const next = (err) => { caught = err; };

  await handler({}, {}, next);
  assert.equal(caught, boom);
});

test("asyncHandler does not call next() when the handler succeeds", async () => {
  const handler = asyncHandler(async () => {});
  let nextCalled = false;
  await handler({}, {}, () => { nextCalled = true; });
  assert.equal(nextCalled, false);
});
