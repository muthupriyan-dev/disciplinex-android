const test = require("node:test");
const assert = require("node:assert/strict");
const {
  MAX_RESUME_SIZE_BYTES,
  ALLOWED_MIME_TYPES,
  isSupportedMimeType,
  isWithinSizeLimit,
} = require("../../backend/src/utils/fileRules");

test("MAX_RESUME_SIZE_BYTES is exactly 5MB", () => {
  assert.equal(MAX_RESUME_SIZE_BYTES, 5 * 1024 * 1024);
});

test("isSupportedMimeType accepts PDF", () => {
  assert.equal(isSupportedMimeType("application/pdf"), true);
});

test("isSupportedMimeType accepts DOCX", () => {
  assert.equal(
    isSupportedMimeType("application/vnd.openxmlformats-officedocument.wordprocessingml.document"),
    true
  );
});

test("isSupportedMimeType rejects unsupported types", () => {
  assert.equal(isSupportedMimeType("image/png"), false);
  assert.equal(isSupportedMimeType("application/msword"), false); // old .doc — deliberately unsupported
  assert.equal(isSupportedMimeType(""), false);
  assert.equal(isSupportedMimeType(undefined), false);
});

test("ALLOWED_MIME_TYPES has exactly 2 entries (PDF, DOCX)", () => {
  assert.equal(ALLOWED_MIME_TYPES.length, 2);
});

test("isWithinSizeLimit accepts sizes at and under the limit", () => {
  assert.equal(isWithinSizeLimit(1), true);
  assert.equal(isWithinSizeLimit(MAX_RESUME_SIZE_BYTES), true);
  assert.equal(isWithinSizeLimit(MAX_RESUME_SIZE_BYTES - 1), true);
});

test("isWithinSizeLimit rejects sizes over the limit", () => {
  assert.equal(isWithinSizeLimit(MAX_RESUME_SIZE_BYTES + 1), false);
});

test("isWithinSizeLimit rejects zero, negative, and non-numeric sizes", () => {
  assert.equal(isWithinSizeLimit(0), false);
  assert.equal(isWithinSizeLimit(-5), false);
  assert.equal(isWithinSizeLimit("5000"), false);
  assert.equal(isWithinSizeLimit(null), false);
});
