/**
 * unit/scoring.test.js
 * Tests backend/src/utils/scoring.js in complete isolation — no mongoose,
 * no Express, no network. Run with: node --test tests/backend-unit/
 */
const test = require("node:test");
const assert = require("node:assert/strict");
const {
  SCORE_DIMENSIONS,
  seededScore,
  mockScore,
  validateScores,
  computeOverall,
} = require("../../backend/src/utils/scoring");

test("SCORE_DIMENSIONS has exactly the 7 documented dimensions", () => {
  assert.equal(SCORE_DIMENSIONS.length, 7);
  assert.deepEqual(SCORE_DIMENSIONS, [
    "formatting", "content", "keyword", "experience", "skills", "impact", "ats",
  ]);
});

test("seededScore is deterministic — same seed always gives the same result", () => {
  const a = seededScore("hello-formatting", 55, 96);
  const b = seededScore("hello-formatting", 55, 96);
  assert.equal(a, b);
});

test("seededScore respects min/max bounds across many seeds", () => {
  for (let i = 0; i < 200; i++) {
    const v = seededScore(`seed-${i}`, 55, 96);
    assert.ok(v >= 55 && v <= 96, `expected ${v} to be within [55,96]`);
  }
});

test("seededScore produces different values for different seeds (not a constant)", () => {
  const values = new Set();
  for (let i = 0; i < 30; i++) {
    values.add(seededScore(`distinct-${i}`, 0, 100));
  }
  assert.ok(values.size > 5, "expected meaningful spread across seeds");
});

test("mockScore returns a score for every dimension, each within 55-96", () => {
  const { scores } = mockScore("Experienced frontend developer with React.", "Frontend Developer");
  SCORE_DIMENSIONS.forEach((dim) => {
    assert.equal(typeof scores[dim], "number");
    assert.ok(scores[dim] >= 55 && scores[dim] <= 96);
  });
});

test("mockScore is deterministic per (text, role) pair", () => {
  const first = mockScore("Some resume text here", "Backend Developer");
  const second = mockScore("Some resume text here", "Backend Developer");
  assert.deepEqual(first.scores, second.scores);
});

test("mockScore differs for different resume text (not a global constant)", () => {
  const a = mockScore("Frontend developer with React and CSS expertise.", null);
  const b = mockScore("Backend developer with Python and PostgreSQL expertise.", null);
  assert.notDeepEqual(a.scores, b.scores);
});

test("mockScore returns between 1 and 4 feedback items", () => {
  const { feedback } = mockScore("Any resume text", null);
  assert.ok(feedback.length >= 1 && feedback.length <= 4);
  feedback.forEach((f) => assert.equal(typeof f, "string"));
});

test("mockScore handles an empty string without throwing", () => {
  assert.doesNotThrow(() => mockScore("", null));
});

test("computeOverall averages all 7 dimensions correctly", () => {
  const scores = { formatting: 80, content: 80, keyword: 80, experience: 80, skills: 80, impact: 80, ats: 80 };
  assert.equal(computeOverall(scores), 80);
});

test("computeOverall rounds to the nearest integer", () => {
  const scores = { formatting: 100, content: 100, keyword: 100, experience: 0, skills: 0, impact: 0, ats: 0 };
  // sum=300, /7 = 42.857... -> rounds to 43
  assert.equal(computeOverall(scores), 43);
});

test("validateScores accepts a complete, in-range scores object", () => {
  const scores = { formatting: 1, content: 1, keyword: 1, experience: 1, skills: 1, impact: 1, ats: 1 };
  assert.equal(validateScores(scores), true);
});

test("validateScores rejects a scores object missing a dimension", () => {
  const scores = { formatting: 1, content: 1, keyword: 1, experience: 1, skills: 1, impact: 1 }; // missing "ats"
  assert.equal(validateScores(scores), false);
});

test("validateScores rejects an out-of-range score", () => {
  const scores = { formatting: 150, content: 1, keyword: 1, experience: 1, skills: 1, impact: 1, ats: 1 };
  assert.equal(validateScores(scores), false);
});

test("validateScores rejects null/undefined", () => {
  assert.equal(validateScores(null), false);
  assert.equal(validateScores(undefined), false);
});
