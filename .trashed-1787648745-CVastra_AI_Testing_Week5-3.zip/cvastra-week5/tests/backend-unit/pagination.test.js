const test = require("node:test");
const assert = require("node:assert/strict");
const { DEFAULT_LIMIT, MAX_LIMIT, parsePagination, buildPaginationMeta } = require("../../backend/src/utils/pagination");

test("parsePagination defaults to page 1, limit 20 with no query", () => {
  const { page, limit, skip } = parsePagination({});
  assert.equal(page, 1);
  assert.equal(limit, DEFAULT_LIMIT);
  assert.equal(skip, 0);
});

test("parsePagination computes skip correctly for page > 1", () => {
  const { skip } = parsePagination({ page: "3", limit: "10" });
  assert.equal(skip, 20); // (3-1)*10
});

test("parsePagination clamps limit to MAX_LIMIT", () => {
  const { limit } = parsePagination({ limit: "9999" });
  assert.equal(limit, MAX_LIMIT);
});

test("parsePagination ignores invalid page/limit and falls back to defaults", () => {
  const { page, limit } = parsePagination({ page: "not-a-number", limit: "-5" });
  assert.equal(page, 1);
  assert.equal(limit, DEFAULT_LIMIT);
});

test("parsePagination rejects page 0 or negative, falls back to 1", () => {
  assert.equal(parsePagination({ page: "0" }).page, 1);
  assert.equal(parsePagination({ page: "-3" }).page, 1);
});

test("parsePagination accepts a valid custom page and limit", () => {
  const { page, limit, skip } = parsePagination({ page: "2", limit: "5" });
  assert.equal(page, 2);
  assert.equal(limit, 5);
  assert.equal(skip, 5);
});

test("buildPaginationMeta computes totalPages correctly", () => {
  assert.deepEqual(buildPaginationMeta(1, 20, 45), { page: 1, totalPages: 3 });
  assert.deepEqual(buildPaginationMeta(1, 20, 20), { page: 1, totalPages: 1 });
  assert.deepEqual(buildPaginationMeta(1, 20, 0), { page: 1, totalPages: 1 }); // never below 1
});
