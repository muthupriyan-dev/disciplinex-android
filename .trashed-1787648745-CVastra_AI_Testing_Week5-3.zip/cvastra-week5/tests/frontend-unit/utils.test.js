/**
 * unit/utils.test.js
 * Tests frontend/js/utils.js directly under Node — no browser, no DOM,
 * because utils.js is deliberately DOM-free (see its header comment).
 * Run with: node --test tests/frontend-unit/
 */
const test = require("node:test");
const assert = require("node:assert/strict");
const { escapeHTML, scoreClass, formatDate } = require("../../frontend/js/utils.js");

test("escapeHTML escapes all five HTML-significant characters", () => {
  assert.equal(escapeHTML(`<script>&"'</script>`), "&lt;script&gt;&amp;&quot;&#39;&lt;/script&gt;");
});

test("escapeHTML leaves plain text unchanged", () => {
  assert.equal(escapeHTML("Frontend Developer"), "Frontend Developer");
});

test("escapeHTML neutralizes a script-injection attempt (XSS regression check)", () => {
  const malicious = `<img src=x onerror="alert('xss')">`;
  const escaped = escapeHTML(malicious);
  assert.ok(!escaped.includes("<img"), "raw <img tag must not survive escaping");
  assert.ok(escaped.includes("&lt;img"));
});

test("escapeHTML coerces non-string input instead of throwing", () => {
  assert.equal(escapeHTML(42), "42");
  assert.equal(escapeHTML(null), "null");
  assert.equal(escapeHTML(undefined), "undefined");
});

test("escapeHTML handles an empty string", () => {
  assert.equal(escapeHTML(""), "");
});

test("scoreClass returns score-good for 80 and above", () => {
  assert.equal(scoreClass(80), "score-good");
  assert.equal(scoreClass(100), "score-good");
});

test("scoreClass returns score-mid for 65-79", () => {
  assert.equal(scoreClass(65), "score-mid");
  assert.equal(scoreClass(79), "score-mid");
});

test("scoreClass returns score-low below 65", () => {
  assert.equal(scoreClass(64), "score-low");
  assert.equal(scoreClass(0), "score-low");
});

test("scoreClass boundary values are inclusive on the correct side", () => {
  // regression check for an off-by-one at the two thresholds
  assert.equal(scoreClass(79.9), "score-mid");
  assert.equal(scoreClass(64.9), "score-low");
});

test("formatDate renders a valid ISO string as a readable date", () => {
  const out = formatDate("2026-03-15T10:00:00.000Z");
  assert.match(out, /2026/);
  assert.match(out, /Mar/);
});

test("formatDate returns an empty string for an invalid date instead of \"Invalid Date\"", () => {
  // Regression: Date.prototype.toLocaleDateString on an invalid Date returns
  // the literal string "Invalid Date" in most engines, which would have
  // rendered directly into the swatch card / detail page. Found while
  // writing this test — see debugging-report.md.
  assert.equal(formatDate("not-a-real-date"), "");
  assert.equal(formatDate(undefined), "");
  assert.equal(formatDate(null), "");
});
