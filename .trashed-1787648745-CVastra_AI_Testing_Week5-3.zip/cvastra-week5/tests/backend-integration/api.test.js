/**
 * integration/api.test.js
 *
 * Real integration tests: makes actual HTTP requests (via Node's built-in
 * fetch) against a running server implementing the CVastra AI API contract.
 * Not mocked, not stubbed — this is testing wire behavior end to end:
 * routing, auth, validation, ownership checks, and cascade deletes.
 *
 * Run against the dependency-free demo server (see demo-server/README.md
 * for why it exists) since the real Express/Mongoose backend needs
 * `npm install` + MongoDB, unavailable in this build environment:
 *
 *   1. node demo-server/server.js &
 *   2. node --test tests/backend-integration/api.test.js
 *
 * Because both servers implement the identical contract documented in
 * backend/API_DOCUMENTATION.md, this suite exercises the same request/
 * response shapes the real backend commits to — see README.md "Why
 * integration tests run against the demo server" for the full rationale.
 */
const test = require("node:test");
const assert = require("node:assert/strict");
const fs = require("node:fs");
const path = require("node:path");

const BASE = process.env.TEST_API_BASE || "http://localhost:5000/api";

function uniqueEmail() {
  return `test${Date.now()}${Math.random().toString(36).slice(2)}@example.com`;
}

async function signup(overrides = {}) {
  const body = {
    name: "Test User",
    email: uniqueEmail(),
    password: "correcthorse123",
    ...overrides,
  };
  const res = await fetch(`${BASE}/auth/signup`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(body),
  });
  const json = await res.json();
  return { res, json, credentials: body };
}

function samplePdfBuffer() {
  const text =
    "Experienced Frontend Developer with five years of React and TypeScript. " +
    "Led migration of a large dashboard, mentored two junior engineers.";
  return Buffer.from(`%PDF-1.4\nBT /F1 18 Tf 50 700 Td (${text}) Tj ET\n%%EOF`);
}

function buildMultipartBody(fields, file) {
  const boundary = "----cvastraTestBoundary" + Date.now();
  const parts = [];
  for (const [key, value] of Object.entries(fields)) {
    parts.push(
      `--${boundary}\r\nContent-Disposition: form-data; name="${key}"\r\n\r\n${value}\r\n`
    );
  }
  if (file) {
    parts.push(
      `--${boundary}\r\nContent-Disposition: form-data; name="resume"; filename="${file.name}"\r\nContent-Type: ${file.type}\r\n\r\n`
    );
  }
  const head = Buffer.from(parts.join(""));
  const tail = Buffer.from(`\r\n--${boundary}--\r\n`);
  const body = file ? Buffer.concat([head, file.buffer, tail]) : Buffer.concat([head]);
  return { body, contentType: `multipart/form-data; boundary=${boundary}` };
}

async function uploadResume(token, targetRole) {
  const { body, contentType } = buildMultipartBody(
    { targetRole: targetRole || "" },
    { name: "resume.pdf", type: "application/pdf", buffer: samplePdfBuffer() }
  );
  const res = await fetch(`${BASE}/resumes`, {
    method: "POST",
    headers: { Authorization: `Bearer ${token}`, "Content-Type": contentType },
    body,
  });
  const json = await res.json();
  return { res, json };
}

// ---------------------------------------------------------------------------
// Health
// ---------------------------------------------------------------------------
test("GET /api/health returns 200 without auth", async () => {
  const res = await fetch(`${BASE}/health`);
  assert.equal(res.status, 200);
  const json = await res.json();
  assert.equal(json.success, true);
});

// ---------------------------------------------------------------------------
// Auth
// ---------------------------------------------------------------------------
test("POST /api/auth/signup creates an account and returns a usable token", async () => {
  const { res, json } = await signup();
  assert.equal(res.status, 201);
  assert.equal(json.success, true);
  assert.equal(typeof json.data.token, "string");
  assert.equal(json.data.user.passwordHash, undefined);
});

test("POST /api/auth/signup rejects a password under 8 characters", async () => {
  const { res, json } = await signup({ password: "short" });
  assert.equal(res.status, 422);
  assert.equal(json.success, false);
});

test("POST /api/auth/signup rejects a duplicate email", async () => {
  const email = uniqueEmail();
  await signup({ email });
  const { res, json } = await signup({ email });
  assert.equal(res.status, 409);
  assert.equal(json.success, false);
});

test("POST /api/auth/login rejects a wrong password", async () => {
  const { credentials } = await signup();
  const res = await fetch(`${BASE}/auth/login`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ email: credentials.email, password: "wrongpassword" }),
  });
  assert.equal(res.status, 401);
});

test("GET /api/auth/me requires a Bearer token (401 without one)", async () => {
  const res = await fetch(`${BASE}/auth/me`);
  assert.equal(res.status, 401);
});

test("GET /api/auth/me returns the correct user for a valid token", async () => {
  const { json: signupJson, credentials } = await signup();
  const res = await fetch(`${BASE}/auth/me`, {
    headers: { Authorization: `Bearer ${signupJson.data.token}` },
  });
  const json = await res.json();
  assert.equal(res.status, 200);
  assert.equal(json.data.user.email, credentials.email);
});

test("A malformed/garbage token is rejected, not silently accepted", async () => {
  const res = await fetch(`${BASE}/auth/me`, {
    headers: { Authorization: "Bearer not-a-real-token" },
  });
  assert.equal(res.status, 401);
});

// ---------------------------------------------------------------------------
// Resumes
// ---------------------------------------------------------------------------
test("POST /api/resumes requires auth", async () => {
  const res = await fetch(`${BASE}/resumes`, { method: "POST" });
  assert.equal(res.status, 401);
});

test("POST /api/resumes rejects a request with no file", async () => {
  const { json: signupJson } = await signup();
  const res = await fetch(`${BASE}/resumes`, {
    method: "POST",
    headers: { Authorization: `Bearer ${signupJson.data.token}` },
  });
  assert.equal(res.status, 400);
});

test("POST /api/resumes uploads successfully and returns resume metadata", async () => {
  const { json: signupJson } = await signup();
  const { res, json } = await uploadResume(signupJson.data.token, "Frontend Developer");
  assert.equal(res.status, 201);
  assert.equal(json.data.resume.targetRole, "Frontend Developer");
  assert.equal(json.data.resume.fileName, "resume.pdf");
});

test("GET /api/resumes lists only the current user's resumes", async () => {
  const { json: userA } = await signup();
  const { json: userB } = await signup();
  await uploadResume(userA.data.token);
  await uploadResume(userB.data.token);
  await uploadResume(userB.data.token);

  const resA = await fetch(`${BASE}/resumes`, {
    headers: { Authorization: `Bearer ${userA.data.token}` },
  });
  const jsonA = await resA.json();
  assert.equal(jsonA.count, 1);

  const resB = await fetch(`${BASE}/resumes`, {
    headers: { Authorization: `Bearer ${userB.data.token}` },
  });
  const jsonB = await resB.json();
  assert.equal(jsonB.count, 2);
});

test("A user cannot GET another user's resume by ID (403)", async () => {
  const { json: userA } = await signup();
  const { json: userB } = await signup();
  const { json: uploadJson } = await uploadResume(userA.data.token);

  const res = await fetch(`${BASE}/resumes/${uploadJson.data.resume.id}`, {
    headers: { Authorization: `Bearer ${userB.data.token}` },
  });
  assert.equal(res.status, 403);
});

test("GET /api/resumes/:id with a bogus ID returns 404, not a 500", async () => {
  const { json: signupJson } = await signup();
  const res = await fetch(`${BASE}/resumes/does-not-exist`, {
    headers: { Authorization: `Bearer ${signupJson.data.token}` },
  });
  assert.ok(res.status === 404, `expected 404, got ${res.status}`);
});

test("PUT /api/resumes/:id updates targetRole", async () => {
  const { json: signupJson } = await signup();
  const { json: uploadJson } = await uploadResume(signupJson.data.token, "Backend Developer");

  const res = await fetch(`${BASE}/resumes/${uploadJson.data.resume.id}`, {
    method: "PUT",
    headers: { Authorization: `Bearer ${signupJson.data.token}`, "Content-Type": "application/json" },
    body: JSON.stringify({ targetRole: "Senior Backend Developer" }),
  });
  const json = await res.json();
  assert.equal(res.status, 200);
  assert.equal(json.data.resume.targetRole, "Senior Backend Developer");
});

// ---------------------------------------------------------------------------
// Analyses
// ---------------------------------------------------------------------------
test("POST /api/resumes/:id/analyze scores all 7 dimensions in range", async () => {
  const { json: signupJson } = await signup();
  const { json: uploadJson } = await uploadResume(signupJson.data.token, "Frontend Developer");

  const res = await fetch(`${BASE}/resumes/${uploadJson.data.resume.id}/analyze`, {
    method: "POST",
    headers: { Authorization: `Bearer ${signupJson.data.token}` },
  });
  const json = await res.json();
  assert.equal(res.status, 201);

  const { scores, overallScore } = json.data.analysis;
  ["formatting", "content", "keyword", "experience", "skills", "impact", "ats"].forEach((dim) => {
    assert.ok(scores[dim] >= 0 && scores[dim] <= 100, `${dim} out of range: ${scores[dim]}`);
  });
  assert.ok(overallScore >= 0 && overallScore <= 100);
});

test("Analyzing the same resume twice gives identical scores (deterministic mock)", async () => {
  const { json: signupJson } = await signup();
  const { json: uploadJson } = await uploadResume(signupJson.data.token, "Frontend Developer");

  const first = await (await fetch(`${BASE}/resumes/${uploadJson.data.resume.id}/analyze`, {
    method: "POST",
    headers: { Authorization: `Bearer ${signupJson.data.token}` },
  })).json();
  const second = await (await fetch(`${BASE}/resumes/${uploadJson.data.resume.id}/analyze`, {
    method: "POST",
    headers: { Authorization: `Bearer ${signupJson.data.token}` },
  })).json();

  assert.deepEqual(first.data.analysis.scores, second.data.analysis.scores);
});

test("GET /api/analyses populates resume.fileName (Week 4 integration fix regression check)", async () => {
  const { json: signupJson } = await signup();
  const { json: uploadJson } = await uploadResume(signupJson.data.token, "Frontend Developer");
  const analyzeRes = await fetch(`${BASE}/resumes/${uploadJson.data.resume.id}/analyze`, {
    method: "POST",
    headers: { Authorization: `Bearer ${signupJson.data.token}` },
  });
  await analyzeRes.json(); // must consume the body or the connection isn't released (see debugging-report.md)

  const res = await fetch(`${BASE}/analyses`, {
    headers: { Authorization: `Bearer ${signupJson.data.token}` },
  });
  const json = await res.json();
  assert.equal(json.data.analyses[0].resume.fileName, "resume.pdf");
});

test("GET /api/analyses/:id (single) also populates resume.fileName", async () => {
  // This is exactly the bug fixed during Week 4 integration — asserting it
  // here so a future change can't silently reintroduce it.
  const { json: signupJson } = await signup();
  const { json: uploadJson } = await uploadResume(signupJson.data.token, "Frontend Developer");

  const analyzeRes = await fetch(`${BASE}/resumes/${uploadJson.data.resume.id}/analyze`, {
    method: "POST",
    headers: { Authorization: `Bearer ${signupJson.data.token}` },
  });
  const analyzeBody = await analyzeRes.json();

  const res = await fetch(`${BASE}/analyses/${analyzeBody.data.analysis.id}`, {
    headers: { Authorization: `Bearer ${signupJson.data.token}` },
  });
  const json = await res.json();
  assert.equal(json.data.analysis.resume.fileName, "resume.pdf");
});

test("PATCH /api/analyses/:id updates note without changing scores", async () => {
  const { json: signupJson } = await signup();
  const { json: uploadJson } = await uploadResume(signupJson.data.token);
  const analyzeRes = await fetch(`${BASE}/resumes/${uploadJson.data.resume.id}/analyze`, {
    method: "POST",
    headers: { Authorization: `Bearer ${signupJson.data.token}` },
  });
  const analyzeBody = await analyzeRes.json();
  const originalScore = analyzeBody.data.analysis.overallScore;

  const patchRes = await fetch(`${BASE}/analyses/${analyzeBody.data.analysis.id}`, {
    method: "PATCH",
    headers: { Authorization: `Bearer ${signupJson.data.token}`, "Content-Type": "application/json" },
    body: JSON.stringify({ note: "Applied to two roles." }),
  });
  const patchJson = await patchRes.json();
  assert.equal(patchJson.data.analysis.note, "Applied to two roles.");
  assert.equal(patchJson.data.analysis.overallScore, originalScore);
});

test("Deleting a resume cascades to delete its analyses", async () => {
  const { json: signupJson } = await signup();
  const { json: uploadJson } = await uploadResume(signupJson.data.token);
  const analyzeRes = await fetch(`${BASE}/resumes/${uploadJson.data.resume.id}/analyze`, {
    method: "POST",
    headers: { Authorization: `Bearer ${signupJson.data.token}` },
  });
  const analyzeBody = await analyzeRes.json();

  const deleteRes = await fetch(`${BASE}/resumes/${uploadJson.data.resume.id}`, {
    method: "DELETE",
    headers: { Authorization: `Bearer ${signupJson.data.token}` },
  });
  assert.equal(deleteRes.status, 204);

  const getRes = await fetch(`${BASE}/analyses/${analyzeBody.data.analysis.id}`, {
    headers: { Authorization: `Bearer ${signupJson.data.token}` },
  });
  assert.equal(getRes.status, 404);
});

test("A user cannot analyze another user's resume (403)", async () => {
  const { json: userA } = await signup();
  const { json: userB } = await signup();
  const { json: uploadJson } = await uploadResume(userA.data.token);

  const res = await fetch(`${BASE}/resumes/${uploadJson.data.resume.id}/analyze`, {
    method: "POST",
    headers: { Authorization: `Bearer ${userB.data.token}` },
  });
  assert.equal(res.status, 403);
});

async function uploadAndAnalyze(token, targetRole) {
  const { json: uploadJson } = await uploadResume(token, targetRole);
  const analyzeRes = await fetch(`${BASE}/resumes/${uploadJson.data.resume.id}/analyze`, {
    method: "POST",
    headers: { Authorization: `Bearer ${token}` },
  });
  await analyzeRes.json(); // consume the body — see debugging-report.md for why this matters in a loop
  return uploadJson;
}

// ---------------------------------------------------------------------------
// Pagination (Week 5 addition)
// ---------------------------------------------------------------------------
test("GET /api/analyses defaults to a max of 20 results per page", async () => {
  const { json: signupJson } = await signup();
  for (let i = 0; i < 25; i++) {
    await uploadAndAnalyze(signupJson.data.token);
  }

  const res = await fetch(`${BASE}/analyses`, {
    headers: { Authorization: `Bearer ${signupJson.data.token}` },
  });
  const json = await res.json();
  assert.equal(json.count, 20, "page size should default to 20");
  assert.equal(json.total, 25, "total should reflect the full count, not just this page");
  assert.equal(json.page, 1);
  assert.equal(json.totalPages, 2);
});

test("GET /api/analyses?page=2 returns the remainder", async () => {
  const { json: signupJson } = await signup();
  for (let i = 0; i < 25; i++) {
    await uploadAndAnalyze(signupJson.data.token);
  }

  const res = await fetch(`${BASE}/analyses?page=2`, {
    headers: { Authorization: `Bearer ${signupJson.data.token}` },
  });
  const json = await res.json();
  assert.equal(json.count, 5, "second page should have the remaining 5 records");
  assert.equal(json.page, 2);
});

test("GET /api/analyses?limit=5 respects a custom page size", async () => {
  const { json: signupJson } = await signup();
  for (let i = 0; i < 8; i++) {
    await uploadAndAnalyze(signupJson.data.token);
  }

  const res = await fetch(`${BASE}/analyses?limit=5`, {
    headers: { Authorization: `Bearer ${signupJson.data.token}` },
  });
  const json = await res.json();
  assert.equal(json.count, 5);
  assert.equal(json.totalPages, 2); // ceil(8/5)
});

test("GET /api/resumes pagination does not leak another user's records into the count", async () => {
  const { json: userA } = await signup();
  const { json: userB } = await signup();
  await uploadResume(userA.data.token);
  await uploadResume(userA.data.token);
  await uploadResume(userB.data.token);

  const res = await fetch(`${BASE}/resumes`, {
    headers: { Authorization: `Bearer ${userA.data.token}` },
  });
  const json = await res.json();
  assert.equal(json.total, 2, "should only count userA's own resumes");
});
