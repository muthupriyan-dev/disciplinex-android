"""
frontend-e2e/app_spec.py
-------------------------------------------------------------------------
End-to-end tests driving a real Chromium browser against the real static
front-end and a real running server (the demo server — see
demo-server/README.md). Uses Playwright's sync API directly rather than
pytest/playwright-test, since neither is installable here (no pip/npm
registry access) — Playwright itself is already available in this
environment. This is a small hand-rolled runner: each @test-decorated
function is registered, then run in order against a fresh browser context,
with pass/fail collected and reported in a TAP-like summary.

Run with:
  1. node demo-server/server.js &
  2. python3 -m http.server 8791 --directory frontend &
  3. python3 tests/frontend-e2e/app_spec.py
-------------------------------------------------------------------------
"""
import re
import sys
import time
import traceback
from playwright.sync_api import sync_playwright

FRONTEND = "http://localhost:8791"

TEST_FUNCTIONS = []
results = []


def test(name):
    """Registers fn to run later against a fresh page, catching failures."""
    def decorator(fn):
        def run(page):
            try:
                fn(page)
                results.append((name, True, None))
                print(f"ok - {name}")
            except Exception as e:
                results.append((name, False, f"{type(e).__name__}: {e}"))
                print(f"not ok - {name}")
                print("   " + traceback.format_exc().replace("\n", "\n   "))
        TEST_FUNCTIONS.append(run)
        return run
    return decorator


def fresh_email():
    return f"e2e{int(time.time() * 1000)}{id(object())}@example.com"


@test("Visiting a protected page while logged out redirects to login.html")
def _(page):
    page.goto(f"{FRONTEND}/index.html")
    page.wait_for_timeout(400)
    assert "login.html" in page.url, f"expected redirect to login.html, got {page.url}"


@test("Signup blocks submission client-side for a password under the 8-char minlength")
def _(page):
    page.goto(f"{FRONTEND}/login.html")
    page.click("#tab-signup")
    page.fill("#signup-name", "Test User")
    page.fill("#signup-email", fresh_email())
    page.fill("#signup-password", "short")
    page.click("#signup-submit")
    page.wait_for_timeout(300)
    assert "login.html" in page.url, "short password should not have submitted"


@test("Full happy path: signup -> upload -> analyze -> detail -> dashboard -> logout")
def _(page):
    page.goto(f"{FRONTEND}/index.html")
    page.wait_for_load_state("load")
    page.click("#tab-signup")
    page.fill("#signup-name", "Muthu")
    page.fill("#signup-email", fresh_email())
    page.fill("#signup-password", "correcthorse123")
    page.click("#signup-submit")
    page.wait_for_url(re.compile(r"index\.html"), timeout=6000)
    page.wait_for_selector("#logout-btn", timeout=5000)  # nav auth-slot has rendered

    page.set_input_files("#file-input", "/tmp/sample-resume.pdf")
    page.wait_for_selector("#file-name-tag:not([hidden])", timeout=3000)
    page.fill("#target-role", "Frontend Developer")
    page.click("#analyze-btn")
    page.wait_for_url(re.compile(r"detail\.html\?id="), timeout=8000)
    page.wait_for_selector(".dial-value", timeout=5000)

    rows = page.locator(".measure-row").count()
    assert rows == 7, f"expected 7 measurement rows, got {rows}"

    score_text = page.locator(".dial-value").inner_text()
    assert score_text.strip().rstrip("%").isdigit(), f"unexpected score text: {score_text}"

    page.goto(f"{FRONTEND}/dashboard.html")
    page.wait_for_selector(".swatch-card", timeout=5000)
    cards = page.locator(".swatch-card").count()
    assert cards == 1, f"expected 1 swatch card, got {cards}"

    page.click("#logout-btn")
    page.wait_for_url(re.compile(r"login\.html"), timeout=5000)


@test("Dashboard shows an empty state for a brand-new account with no analyses")
def _(page):
    page.goto(f"{FRONTEND}/index.html")
    page.wait_for_load_state("load")
    page.click("#tab-signup")
    page.fill("#signup-name", "New User")
    page.fill("#signup-email", fresh_email())
    page.fill("#signup-password", "correcthorse123")
    page.click("#signup-submit")
    page.wait_for_url(re.compile(r"index\.html"), timeout=6000)
    page.wait_for_selector("#logout-btn", timeout=5000)

    page.goto(f"{FRONTEND}/dashboard.html")
    page.wait_for_selector(".empty-state", timeout=8000)


@test("Upload page rejects a non-PDF/DOCX file client-side before any request is sent")
def _(page):
    page.goto(f"{FRONTEND}/index.html")
    page.wait_for_load_state("load")
    page.click("#tab-signup")
    page.fill("#signup-name", "File Test User")
    page.fill("#signup-email", fresh_email())
    page.fill("#signup-password", "correcthorse123")
    page.click("#signup-submit")
    page.wait_for_url(re.compile(r"index\.html"), timeout=6000)
    page.wait_for_selector("#logout-btn", timeout=5000)

    with open("/tmp/not-a-resume.txt", "w") as f:
        f.write("this is not a resume")
    page.set_input_files("#file-input", "/tmp/not-a-resume.txt")
    page.wait_for_function(
        "document.getElementById('status-line').textContent.length > 0", timeout=3000
    )
    status_text = page.locator("#status-line").inner_text()
    assert "PDF or DOCX" in status_text, f"expected a file-type warning, got: {status_text!r}"
    assert page.locator("#analyze-btn").is_disabled(), "analyze button should stay disabled"


@test("detail.html with a nonexistent analysis id shows a not-found state, not a crash")
def _(page):
    page.goto(f"{FRONTEND}/index.html")
    page.wait_for_load_state("load")
    page.click("#tab-signup")
    page.fill("#signup-name", "NotFound User")
    page.fill("#signup-email", fresh_email())
    page.fill("#signup-password", "correcthorse123")
    page.click("#signup-submit")
    page.wait_for_url(re.compile(r"index\.html"), timeout=6000)
    page.wait_for_selector("#logout-btn", timeout=5000)

    page.goto(f"{FRONTEND}/detail.html?id=nonexistent-id-12345")
    page.wait_for_selector(".empty-state", timeout=8000)


@test("Deleting an analysis from the detail view removes it from the dashboard")
def _(page):
    page.goto(f"{FRONTEND}/index.html")
    page.wait_for_load_state("load")
    page.click("#tab-signup")
    page.fill("#signup-name", "Delete Test User")
    page.fill("#signup-email", fresh_email())
    page.fill("#signup-password", "correcthorse123")
    page.click("#signup-submit")
    page.wait_for_url(re.compile(r"index\.html"), timeout=6000)
    page.wait_for_selector("#logout-btn", timeout=5000)

    page.set_input_files("#file-input", "/tmp/sample-resume.pdf")
    page.wait_for_selector("#file-name-tag:not([hidden])", timeout=3000)
    page.click("#analyze-btn")
    page.wait_for_url(re.compile(r"detail\.html\?id="), timeout=8000)
    page.wait_for_selector("#delete-btn", timeout=5000)

    page.on("dialog", lambda dialog: dialog.accept())
    page.click("#delete-btn")
    page.wait_for_url(re.compile(r"dashboard\.html"), timeout=5000)
    page.wait_for_selector(".empty-state", timeout=8000)


@test("No unexpected console errors during signup->upload->detail (Google Fonts 403 excluded — sandbox has no network)")
def _(page):
    errors = []
    page.on("console", lambda msg: errors.append(msg.text) if msg.type == "error" else None)
    page.on("pageerror", lambda exc: errors.append(str(exc)))

    page.goto(f"{FRONTEND}/index.html")
    page.wait_for_load_state("load")
    page.click("#tab-signup")
    page.fill("#signup-name", "Console Check")
    page.fill("#signup-email", fresh_email())
    page.fill("#signup-password", "correcthorse123")
    page.click("#signup-submit")
    page.wait_for_url(re.compile(r"index\.html"), timeout=6000)
    page.wait_for_selector("#logout-btn", timeout=5000)

    real_errors = [e for e in errors if "fonts.googleapis" not in e and "403" not in e]
    assert not real_errors, f"unexpected console errors: {real_errors}"


def main():
    with sync_playwright() as p:
        browser = p.chromium.launch()
        for test_fn in TEST_FUNCTIONS:
            context = browser.new_context(viewport={"width": 1280, "height": 800})
            page = context.new_page()
            test_fn(page)
            context.close()
        browser.close()

    total = len(results)
    passed = sum(1 for _, ok, _ in results if ok)
    failed = total - passed
    print(f"\n# tests {total}")
    print(f"# pass {passed}")
    print(f"# fail {failed}")
    if failed:
        sys.exit(1)


if __name__ == "__main__":
    main()
