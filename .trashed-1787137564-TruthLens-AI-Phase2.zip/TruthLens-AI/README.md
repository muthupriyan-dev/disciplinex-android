# TruthLens AI

**Verify Before You Believe.**

AI-powered fake news detection web app. Paste any news text and get an instant
REAL/FAKE prediction with a confidence score and a plain-language explanation.

> 🚧 **Status: Phase 2 of 4 complete.** Core prediction, URL analysis, OCR image
> detection, and PDF analysis are all functional. Voice input, dashboard,
> history, export, and multi-language are being added next. This README will
> be replaced with the full professional version at the end of Phase 4.

## What works right now

- Paste news text → TF-IDF + Passive Aggressive Classifier predicts REAL or FAKE
- Animated confidence gauge (0–100%)
- Plain-language AI explanation of the verdict
- Suspicious/clickbait phrase highlighting
- **Paste a news article URL** → auto-fetches title, author, and body text, then analyzes it, plus a source credibility score (HTTPS, domain reputation, author byline, URL structure)
- **Upload an image** (screenshot/photo of news text) → OCR extracts the text (editable before analysis) → analyzed
- **Upload a PDF** → full document text extracted and analyzed
- Dark/light theme toggle (persisted)
- Fully responsive glassmorphism UI (Bootstrap 5)
- Auto-trains the model on first run if `model.pkl` is missing

## ⚠️ OCR system dependency (Render deploy note)

Image OCR uses `pytesseract`, which needs the **Tesseract OCR binary** installed
on the server (not just the Python package). Render's native Python
environment builds in a full Ubuntu container, so add this to your Render
**Build Command**:

```
apt-get update && apt-get install -y tesseract-ocr && pip install -r requirements.txt
```

If Tesseract isn't available, the OCR endpoint returns a clear JSON error
instead of crashing — text, URL, and PDF analysis are unaffected.
- Includes a synthetic dataset generator (`dataset/generate_dataset.py`) so the
  app works out of the box even without a real Fake.csv/True.csv — swap in a
  real dataset any time by replacing those two files and deleting `model.pkl`

## Run locally

```bash
pip install -r requirements.txt
python app.py
```

Visit `http://localhost:5000`

## Deploy on Render

1. Push this repo to GitHub.
2. Create a new **Web Service** on Render, connect the repo.
3. Build command: `pip install -r requirements.txt`
4. Start command: `gunicorn app:app`
5. Render will auto-detect `runtime.txt` for the Python version.

## Project structure (Phase 1)

```
TruthLens-AI/
├── app.py                 # Flask app + prediction API
├── train_model.py         # Trains TF-IDF + PassiveAggressiveClassifier
├── utils.py                # Text cleaning, explanation, credibility scoring
├── requirements.txt
├── runtime.txt
├── Procfile
├── model.pkl               # Trained model (auto-generated)
├── vectorizer.pkl          # Trained vectorizer (auto-generated)
├── dataset/
│   ├── generate_dataset.py # Synthetic dataset generator
│   ├── Fake.csv
│   └── True.csv
├── templates/
│   └── index.html
└── static/
    ├── css/ (style.css, dark.css)
    ├── js/ (main.js)
    ├── uploads/            # reserved for Phase 2 (OCR/PDF uploads)
    └── reports/            # reserved for Phase 3 (export reports)
```

## Using a real dataset

Replace `dataset/Fake.csv` and `dataset/True.csv` with real data (must include
a `text` column, `title` optional), delete `model.pkl` and `vectorizer.pkl`,
then restart the app — it will retrain automatically.

## License

MIT — see `LICENSE`.

## Author

Muthu
