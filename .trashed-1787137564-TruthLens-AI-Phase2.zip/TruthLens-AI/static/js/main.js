/* ==========================================================
   TruthLens AI — main.js
   Handles: tab switching, theme toggle (persisted), text
   analysis API call, gauge animation, result rendering,
   local history storage (used by dashboard/history pages
   added in later phases).
   ========================================================== */

document.addEventListener('DOMContentLoaded', () => {

  /* ---------- Theme toggle ---------- */
  const themeToggle = document.getElementById('themeToggle');
  const body = document.body;
  const savedTheme = localStorage.getItem('tl-theme') || 'dark';
  if (savedTheme === 'light') {
    body.classList.add('theme-light');
    themeToggle.innerHTML = '<i class="fa-solid fa-sun"></i>';
  }
  themeToggle.addEventListener('click', () => {
    body.classList.toggle('theme-light');
    const isLight = body.classList.contains('theme-light');
    localStorage.setItem('tl-theme', isLight ? 'light' : 'dark');
    themeToggle.innerHTML = isLight
      ? '<i class="fa-solid fa-sun"></i>'
      : '<i class="fa-solid fa-moon"></i>';
  });

  /* ---------- Tabs ---------- */
  const tabButtons = document.querySelectorAll('.tl-tab-btn');
  const panels = { text: '#panel-text', url: '#panel-url', image: '#panel-image', pdf: '#panel-pdf', voice: '#panel-voice' };
  tabButtons.forEach(btn => {
    btn.addEventListener('click', () => {
      tabButtons.forEach(b => { b.classList.remove('active'); b.setAttribute('aria-selected', 'false'); });
      btn.classList.add('active');
      btn.setAttribute('aria-selected', 'true');
      Object.values(panels).forEach(sel => document.querySelector(sel).classList.add('d-none'));
      document.querySelector(panels[btn.dataset.tab]).classList.remove('d-none');
      document.getElementById('resultPanel').classList.remove('show');
    });
  });

  /* ---------- Character counter ---------- */
  const newsText = document.getElementById('newsText');
  const charCount = document.getElementById('charCount');
  newsText.addEventListener('input', () => {
    charCount.textContent = `${newsText.value.length} characters`;
  });

  /* ---------- Clear ---------- */
  document.getElementById('clearBtn').addEventListener('click', () => {
    newsText.value = '';
    charCount.textContent = '0 characters';
    document.getElementById('resultPanel').classList.remove('show');
    hideError();
  });

  document.getElementById('analyzeAnotherBtn').addEventListener('click', () => {
    document.getElementById('resultPanel').classList.remove('show');
    newsText.focus();
    window.scrollTo({ top: document.getElementById('panel-text').offsetTop - 100, behavior: 'smooth' });
  });

  /* ---------- Error handling ---------- */
  function showError(msg) {
    const box = document.getElementById('errorBox');
    box.textContent = msg;
    box.classList.remove('d-none');
  }
  function hideError() {
    document.getElementById('errorBox').classList.add('d-none');
  }

  /* ---------- Analyze ---------- */
  const analyzeBtn = document.getElementById('analyzeBtn');
  const loader = document.getElementById('loader');

  analyzeBtn.addEventListener('click', async () => {
    hideError();
    const text = newsText.value.trim();

    if (text.length < 10) {
      showError('Please enter at least 10 characters of news text to analyze.');
      return;
    }

    analyzeBtn.disabled = true;
    loader.classList.add('show');
    document.getElementById('resultPanel').classList.remove('show');

    try {
      const res = await fetch('/api/predict', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ text })
      });

      const data = await res.json();

      if (!res.ok) {
        showError(data.error || 'Something went wrong while analyzing this text.');
        return;
      }

      renderResult(data);
      saveToHistory(data, text);

    } catch (err) {
      showError('Network error — please check your connection and try again.');
    } finally {
      analyzeBtn.disabled = false;
      loader.classList.remove('show');
    }
  });

  function renderResult(data) {
    const isFake = data.label === 'FAKE';

    // Badge
    const badge = document.getElementById('labelBadge');
    badge.innerHTML = `
      <span class="tl-badge ${isFake ? 'fake' : 'real'}">
        <span class="tl-badge-dot"></span>
        ${isFake ? 'Likely Fake News' : 'Likely Real News'}
      </span>`;

    // Gauge
    const arc = document.getElementById('gaugeArc');
    const circumference = 283; // matches path length approx for this arc
    const pct = Math.max(0, Math.min(100, data.confidence));
    const offset = circumference - (circumference * pct / 100);
    requestAnimationFrame(() => { arc.style.strokeDashoffset = offset; });
    document.getElementById('confidenceValue').textContent = `${pct}%`;

    // Explanation
    document.getElementById('explanationBox').textContent = data.explanation;

    // Highlighted text
    const highlightBox = document.getElementById('highlightedBox');
    if (data.suspicious_phrases && data.suspicious_phrases.length > 0) {
      highlightBox.innerHTML = data.highlighted_text;
    } else {
      highlightBox.innerHTML = '<span class="text-lo">No suspicious phrases were flagged in this text.</span>';
    }

    // Credibility score (URL analysis only)
    const credSection = document.getElementById('credibilitySection');
    if (typeof data.credibility_score !== 'undefined') {
      document.getElementById('credibilityScoreText').textContent = `${data.credibility_score} / 100`;
      const list = document.getElementById('credibilityReasonsList');
      list.innerHTML = (data.credibility_reasons || []).map(r => `<li>${r}</li>`).join('');
      credSection.classList.remove('d-none');
    } else {
      credSection.classList.add('d-none');
    }

    // Extracted text (URL / PDF analysis)
    const extractedSection = document.getElementById('extractedTextSection');
    if (data.extracted_text) {
      document.getElementById('extractedTextBox').textContent = data.extracted_text;
      extractedSection.classList.remove('d-none');
    } else {
      extractedSection.classList.add('d-none');
    }

    document.getElementById('resultPanel').classList.add('show');
    document.getElementById('resultPanel').scrollIntoView({ behavior: 'smooth', block: 'start' });
  }

  /* ---------- URL analysis ---------- */
  const urlErrorBox = document.getElementById('errorBoxUrl');
  function showUrlError(msg) { urlErrorBox.textContent = msg; urlErrorBox.classList.remove('d-none'); }
  function hideUrlError() { urlErrorBox.classList.add('d-none'); }

  document.getElementById('clearUrlBtn').addEventListener('click', () => {
    document.getElementById('newsUrl').value = '';
    hideUrlError();
    document.getElementById('resultPanel').classList.remove('show');
  });

  document.getElementById('analyzeUrlBtn').addEventListener('click', async () => {
    hideUrlError();
    const url = document.getElementById('newsUrl').value.trim();
    if (!url) { showUrlError('Please paste a news article URL.'); return; }

    const btn = document.getElementById('analyzeUrlBtn');
    const loader = document.getElementById('loaderUrl');
    btn.disabled = true; loader.classList.add('show');
    document.getElementById('resultPanel').classList.remove('show');

    try {
      const res = await fetch('/api/analyze-url', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ url })
      });
      const data = await res.json();
      if (!res.ok) { showUrlError(data.error || 'Could not analyze this URL.'); return; }
      renderResult(data);
      saveToHistory(data, data.article_title || url);
    } catch (err) {
      showUrlError('Network error — please check your connection and try again.');
    } finally {
      btn.disabled = false; loader.classList.remove('show');
    }
  });

  /* ---------- Image (OCR) analysis ---------- */
  const imageErrorBox = document.getElementById('errorBoxImage');
  function showImageError(msg) { imageErrorBox.textContent = msg; imageErrorBox.classList.remove('d-none'); }
  function hideImageError() { imageErrorBox.classList.add('d-none'); }

  document.getElementById('clearImageBtn').addEventListener('click', () => {
    document.getElementById('newsImage').value = '';
    document.getElementById('ocrPreviewWrap').classList.add('d-none');
    hideImageError();
    document.getElementById('resultPanel').classList.remove('show');
  });

  document.getElementById('analyzeImageBtn').addEventListener('click', async () => {
    hideImageError();
    const fileInput = document.getElementById('newsImage');
    if (!fileInput.files || fileInput.files.length === 0) {
      showImageError('Please choose an image to upload.');
      return;
    }

    const btn = document.getElementById('analyzeImageBtn');
    const loader = document.getElementById('loaderImage');
    btn.disabled = true; loader.classList.add('show');

    try {
      const formData = new FormData();
      formData.append('image', fileInput.files[0]);
      const res = await fetch('/api/analyze-image', { method: 'POST', body: formData });
      const data = await res.json();
      if (!res.ok) { showImageError(data.error || 'Could not extract text from this image.'); return; }

      document.getElementById('ocrPreviewText').value = data.extracted_text;
      document.getElementById('ocrPreviewWrap').classList.remove('d-none');
    } catch (err) {
      showImageError('Network error — please check your connection and try again.');
    } finally {
      btn.disabled = false; loader.classList.remove('show');
    }
  });

  document.getElementById('analyzeOcrTextBtn').addEventListener('click', async () => {
    hideImageError();
    const text = document.getElementById('ocrPreviewText').value.trim();
    if (text.length < 10) { showImageError('Extracted text is too short to analyze.'); return; }

    const loader = document.getElementById('loaderImage');
    loader.classList.add('show');
    document.getElementById('resultPanel').classList.remove('show');

    try {
      const res = await fetch('/api/predict', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ text })
      });
      const data = await res.json();
      if (!res.ok) { showImageError(data.error || 'Something went wrong while analyzing this text.'); return; }
      renderResult(data);
      saveToHistory(data, text);
    } catch (err) {
      showImageError('Network error — please check your connection and try again.');
    } finally {
      loader.classList.remove('show');
    }
  });

  /* ---------- PDF analysis ---------- */
  const pdfErrorBox = document.getElementById('errorBoxPdf');
  function showPdfError(msg) { pdfErrorBox.textContent = msg; pdfErrorBox.classList.remove('d-none'); }
  function hidePdfError() { pdfErrorBox.classList.add('d-none'); }

  document.getElementById('clearPdfBtn').addEventListener('click', () => {
    document.getElementById('newsPdf').value = '';
    hidePdfError();
    document.getElementById('resultPanel').classList.remove('show');
  });

  document.getElementById('analyzePdfBtn').addEventListener('click', async () => {
    hidePdfError();
    const fileInput = document.getElementById('newsPdf');
    if (!fileInput.files || fileInput.files.length === 0) {
      showPdfError('Please choose a PDF to upload.');
      return;
    }

    const btn = document.getElementById('analyzePdfBtn');
    const loader = document.getElementById('loaderPdf');
    btn.disabled = true; loader.classList.add('show');
    document.getElementById('resultPanel').classList.remove('show');

    try {
      const formData = new FormData();
      formData.append('pdf', fileInput.files[0]);
      const res = await fetch('/api/analyze-pdf', { method: 'POST', body: formData });
      const data = await res.json();
      if (!res.ok) { showPdfError(data.error || 'Could not analyze this PDF.'); return; }
      renderResult(data);
      saveToHistory(data, fileInput.files[0].name);
    } catch (err) {
      showPdfError('Network error — please check your connection and try again.');
    } finally {
      btn.disabled = false; loader.classList.remove('show');
    }
  });

  /* ---------- Local history storage (consumed by dashboard/history — later phase) ---------- */
  function saveToHistory(data, inputText) {
    try {
      const history = JSON.parse(localStorage.getItem('tl-history') || '[]');
      history.unshift({
        text: inputText.slice(0, 300),
        label: data.label,
        confidence: data.confidence,
        explanation: data.explanation,
        timestamp: data.timestamp
      });
      localStorage.setItem('tl-history', JSON.stringify(history.slice(0, 200)));
    } catch (e) {
      console.warn('Could not save history:', e);
    }
  }

});
