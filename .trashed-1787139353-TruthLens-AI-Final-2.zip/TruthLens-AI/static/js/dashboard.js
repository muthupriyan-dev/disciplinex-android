/* ==========================================================
   dashboard.js
   Reads 'tl-history' from localStorage (written by main.js /
   voice.js on every analysis) and renders stat cards, a
   Real-vs-Fake pie chart, a recent-confidence bar chart, and
   a recent activity list.
   ========================================================== */

document.addEventListener('DOMContentLoaded', () => {
  const history = JSON.parse(localStorage.getItem('tl-history') || '[]');

  if (history.length === 0) {
    document.getElementById('emptyState').classList.remove('d-none');
    document.getElementById('dashboardContent').classList.add('d-none');
    return;
  }

  const total = history.length;
  const fakeCount = history.filter(h => h.label === 'FAKE').length;
  const realCount = history.filter(h => h.label === 'REAL').length;
  const avgConfidence = (history.reduce((sum, h) => sum + (h.confidence || 0), 0) / total).toFixed(1);

  document.getElementById('statTotal').textContent = total;
  document.getElementById('statFake').textContent = fakeCount;
  document.getElementById('statReal').textContent = realCount;
  document.getElementById('statAvgConfidence').textContent = `${avgConfidence}%`;

  // Pie chart: Real vs Fake
  new Chart(document.getElementById('pieChart'), {
    type: 'doughnut',
    data: {
      labels: ['Real', 'Fake'],
      datasets: [{
        data: [realCount, fakeCount],
        backgroundColor: ['#34d399', '#f87171'],
        borderWidth: 0
      }]
    },
    options: {
      plugins: { legend: { labels: { color: '#e6e9ff' } } }
    }
  });

  // Bar chart: confidence of last 10 analyses (most recent first -> reverse for chronological display)
  const recent = history.slice(0, 10).reverse();
  new Chart(document.getElementById('barChart'), {
    type: 'bar',
    data: {
      labels: recent.map((h, i) => `#${i + 1}`),
      datasets: [{
        label: 'Confidence %',
        data: recent.map(h => h.confidence),
        backgroundColor: recent.map(h => h.label === 'FAKE' ? '#f87171' : '#34d399'),
        borderRadius: 6
      }]
    },
    options: {
      scales: {
        x: { ticks: { color: '#8b90b8' }, grid: { color: 'rgba(255,255,255,0.06)' } },
        y: { ticks: { color: '#8b90b8' }, grid: { color: 'rgba(255,255,255,0.06)' }, min: 0, max: 100 }
      },
      plugins: { legend: { display: false } }
    }
  });

  // Recent activity list
  const listEl = document.getElementById('recentActivityList');
  listEl.innerHTML = history.slice(0, 8).map(h => {
    const date = new Date(h.timestamp).toLocaleString();
    const badgeClass = h.label === 'FAKE' ? 'fake' : 'real';
    const snippet = (h.text || '').slice(0, 90);
    return `
      <div class="d-flex justify-content-between align-items-center py-2 border-bottom" style="border-color: var(--glass-border) !important;">
        <div class="me-3">
          <div class="small text-lo">${date}</div>
          <div>${snippet}${h.text && h.text.length > 90 ? '…' : ''}</div>
        </div>
        <span class="tl-badge ${badgeClass}" style="white-space:nowrap;">
          <span class="tl-badge-dot"></span>${h.label} · ${h.confidence}%
        </span>
      </div>`;
  }).join('');
});
