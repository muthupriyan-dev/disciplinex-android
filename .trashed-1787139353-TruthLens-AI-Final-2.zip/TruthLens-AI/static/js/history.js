/* ==========================================================
   history.js
   Renders the full 'tl-history' localStorage list with
   per-item delete, clear-all, and CSV/PDF export.
   ========================================================== */

function tlLoadHistory() {
  return JSON.parse(localStorage.getItem('tl-history') || '[]');
}

function tlSaveHistory(history) {
  localStorage.setItem('tl-history', JSON.stringify(history));
}

function tlRenderHistory() {
  const history = tlLoadHistory();
  const listEl = document.getElementById('historyList');
  const emptyState = document.getElementById('emptyState');

  if (history.length === 0) {
    emptyState.classList.remove('d-none');
    listEl.innerHTML = '';
    return;
  }
  emptyState.classList.add('d-none');

  listEl.innerHTML = history.map((h, index) => {
    const date = new Date(h.timestamp).toLocaleString();
    const badgeClass = h.label === 'FAKE' ? 'fake' : 'real';
    return `
      <div class="glass p-3 d-flex justify-content-between align-items-start gap-3">
        <div class="flex-grow-1">
          <div class="small text-lo mb-1">${date}</div>
          <div class="mb-2">${(h.text || '').slice(0, 220)}${h.text && h.text.length > 220 ? '…' : ''}</div>
          <span class="tl-badge ${badgeClass}"><span class="tl-badge-dot"></span>${h.label} · ${h.confidence}%</span>
        </div>
        <button class="btn btn-tl-ghost btn-sm text-danger flex-shrink-0" data-delete-index="${index}" aria-label="Delete this entry">
          <i class="fa-solid fa-trash"></i>
        </button>
      </div>`;
  }).join('');

  listEl.querySelectorAll('[data-delete-index]').forEach(btn => {
    btn.addEventListener('click', () => {
      const idx = parseInt(btn.getAttribute('data-delete-index'), 10);
      const history = tlLoadHistory();
      history.splice(idx, 1);
      tlSaveHistory(history);
      tlRenderHistory();
    });
  });
}

document.addEventListener('DOMContentLoaded', () => {
  tlRenderHistory();

  document.getElementById('clearAllBtn').addEventListener('click', () => {
    if (confirm('Clear all analysis history? This cannot be undone.')) {
      tlSaveHistory([]);
      tlRenderHistory();
    }
  });

  document.getElementById('exportCsvBtn').addEventListener('click', () => {
    const history = tlLoadHistory();
    if (history.length === 0) return;

    const rows = [['Date', 'Prediction', 'Confidence %', 'Explanation', 'Text']];
    history.forEach(h => {
      rows.push([
        new Date(h.timestamp).toLocaleString(),
        h.label,
        h.confidence,
        (h.explanation || '').replace(/"/g, '""'),
        (h.text || '').replace(/"/g, '""')
      ]);
    });
    const csvContent = rows.map(r => r.map(cell => `"${cell}"`).join(',')).join('\n');
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    link.href = URL.createObjectURL(blob);
    link.download = 'truthlens-history.csv';
    link.click();
  });

  document.getElementById('exportPdfBtn').addEventListener('click', () => {
    const history = tlLoadHistory();
    if (history.length === 0) return;

    const { jsPDF } = window.jspdf;
    const doc = new jsPDF();
    let y = 15;

    doc.setFontSize(16);
    doc.text('TruthLens AI — Analysis Report', 14, y);
    y += 10;
    doc.setFontSize(10);
    doc.text(`Generated: ${new Date().toLocaleString()} · ${history.length} entries`, 14, y);
    y += 10;

    history.forEach((h, i) => {
      if (y > 270) { doc.addPage(); y = 15; }
      doc.setFontSize(11);
      doc.setFont(undefined, 'bold');
      doc.text(`${i + 1}. ${h.label} — ${h.confidence}% (${new Date(h.timestamp).toLocaleString()})`, 14, y);
      y += 6;
      doc.setFont(undefined, 'normal');
      doc.setFontSize(9);
      const textLines = doc.splitTextToSize((h.text || '').slice(0, 300), 180);
      doc.text(textLines, 14, y);
      y += textLines.length * 4.5 + 4;
    });

    doc.save('truthlens-history.pdf');
  });
});
