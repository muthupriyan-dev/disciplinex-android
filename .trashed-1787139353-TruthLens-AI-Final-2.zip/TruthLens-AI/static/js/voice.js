/* ==========================================================
   TruthLens AI — voice.js
   Browser-native speech-to-text using the Web Speech API
   (SpeechRecognition / webkitSpeechRecognition). No server
   round-trip needed for transcription — only the final text
   is sent to /api/predict for analysis.
   ========================================================== */

document.addEventListener('DOMContentLoaded', () => {
  const micBtn = document.getElementById('micBtn');
  const micStatus = document.getElementById('micStatus');
  const voiceText = document.getElementById('voiceText');
  const unsupportedBox = document.getElementById('voiceUnsupportedBox');

  if (!micBtn) return; // voice panel not on this page

  const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;

  if (!SpeechRecognition) {
    unsupportedBox.classList.remove('d-none');
    micBtn.disabled = true;
    return;
  }

  const recognition = new SpeechRecognition();
  recognition.continuous = true;
  recognition.interimResults = true;
  recognition.lang = 'en-US';

  let isListening = false;

  recognition.onstart = () => {
    isListening = true;
    micStatus.textContent = 'Listening… tap again to stop';
    micBtn.classList.add('btn-tl-primary');
    micBtn.querySelector('i').className = 'fa-solid fa-microphone-lines fa-lg';
  };

  recognition.onresult = (event) => {
    let finalTranscript = '';
    for (let i = event.resultIndex; i < event.results.length; i++) {
      if (event.results[i].isFinal) {
        finalTranscript += event.results[i][0].transcript + ' ';
      }
    }
    if (finalTranscript) {
      voiceText.value = (voiceText.value + ' ' + finalTranscript).trim();
    }
  };

  recognition.onerror = (event) => {
    micStatus.textContent = `Voice recognition error: ${event.error}. Tap the mic to try again.`;
    isListening = false;
  };

  recognition.onend = () => {
    isListening = false;
    micStatus.textContent = 'Tap the mic to start speaking';
    micBtn.querySelector('i').className = 'fa-solid fa-microphone fa-lg';
  };

  micBtn.addEventListener('click', () => {
    if (isListening) {
      recognition.stop();
    } else {
      try {
        recognition.start();
      } catch (e) {
        // recognition may already be running; ignore
      }
    }
  });

  document.getElementById('clearVoiceBtn')?.addEventListener('click', () => {
    voiceText.value = '';
  });

  document.getElementById('analyzeVoiceBtn')?.addEventListener('click', async () => {
    const errorBox = document.getElementById('errorBoxVoice');
    errorBox.classList.add('d-none');
    const text = voiceText.value.trim();

    if (text.length < 10) {
      errorBox.textContent = 'Please speak or type at least 10 characters before analyzing.';
      errorBox.classList.remove('d-none');
      return;
    }

    if (isListening) recognition.stop();

    const btn = document.getElementById('analyzeVoiceBtn');
    const loader = document.getElementById('loaderVoice');
    btn.disabled = true;
    loader.classList.add('show');
    document.getElementById('resultPanel').classList.remove('show');

    try {
      const res = await fetch('/api/predict', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ text })
      });
      const data = await res.json();
      if (!res.ok) {
        errorBox.textContent = data.error || 'Something went wrong while analyzing this text.';
        errorBox.classList.remove('d-none');
        return;
      }
      // renderResult and saveToHistory are defined in main.js and available globally
      if (typeof renderResult === 'function') {
        renderResult(data);
      }
      if (typeof saveToHistory === 'function') {
        saveToHistory(data, text);
      }
    } catch (err) {
      errorBox.textContent = 'Network error — please check your connection and try again.';
      errorBox.classList.remove('d-none');
    } finally {
      btn.disabled = false;
      loader.classList.remove('show');
    }
  });
});
