/* ==========================================================
   TruthLens AI — i18n.js
   Simple client-side English/Tamil interface translation.
   Applies to any element with a data-i18n="key" attribute.
   Persists choice in localStorage as 'tl-lang'.
   ========================================================== */

const TL_TRANSLATIONS = {
  en: {
    nav_dashboard: "Dashboard",
    nav_history: "History",
    tagline: "Verify Before You Believe.",
    hero_detect: "Detect",
    hero_fake: "Fake News",
    hero_instant: "Instantly with AI",
    hero_lead: "Paste any news article, headline, or claim below. TruthLens AI analyzes language patterns and gives you a real-time credibility verdict with a plain-language explanation.",
    tab_text: "Text",
    tab_url: "URL",
    tab_image: "Image (OCR)",
    tab_pdf: "PDF",
    tab_voice: "Voice",
    text_label: "Paste news text, headline, or claim",
    min_chars: "Minimum 10 characters",
    btn_analyze: "Analyze News",
    btn_clear: "Clear",
    footer_text: "Built with Flask & scikit-learn · TruthLens AI is a portfolio project — always verify important news through multiple trusted sources.",
  },
  ta: {
    nav_dashboard: "டாஷ்போர்டு",
    nav_history: "வரலாறு",
    tagline: "நம்புவதற்கு முன் சரிபார்க்கவும்.",
    hero_detect: "போலிச் செய்திகளை",
    hero_fake: "AI மூலம்",
    hero_instant: "உடனடியாகக் கண்டறியுங்கள்",
    hero_lead: "எந்தவொரு செய்தி, தலைப்பு அல்லது கூற்றையும் கீழே ஒட்டவும். TruthLens AI மொழி பாணிகளை பகுப்பாய்வு செய்து, எளிய விளக்கத்துடன் உடனடி நம்பகத்தன்மை முடிவை தரும்.",
    tab_text: "உரை",
    tab_url: "URL",
    tab_image: "படம் (OCR)",
    tab_pdf: "PDF",
    tab_voice: "குரல்",
    text_label: "செய்தி உரை, தலைப்பு அல்லது கூற்றை ஒட்டவும்",
    min_chars: "குறைந்தபட்சம் 10 எழுத்துகள்",
    btn_analyze: "செய்தியை பகுப்பாய்வு செய்",
    btn_clear: "அழி",
    footer_text: "Flask & scikit-learn மூலம் உருவாக்கப்பட்டது · TruthLens AI ஒரு போர்ட்ஃபோலியோ திட்டம் — முக்கியமான செய்திகளை எப்போதும் பல நம்பகமான ஆதாரங்கள் மூலம் சரிபார்க்கவும்.",
  }
};

function tlApplyLanguage(lang) {
  const dict = TL_TRANSLATIONS[lang] || TL_TRANSLATIONS.en;
  document.querySelectorAll('[data-i18n]').forEach(el => {
    const key = el.getAttribute('data-i18n');
    if (dict[key]) el.textContent = dict[key];
  });
  document.documentElement.setAttribute('lang', lang === 'ta' ? 'ta' : 'en');
  const langBtn = document.getElementById('langToggle');
  if (langBtn) langBtn.textContent = lang === 'ta' ? 'TA' : 'EN';
}

document.addEventListener('DOMContentLoaded', () => {
  const savedLang = localStorage.getItem('tl-lang') || 'en';
  tlApplyLanguage(savedLang);

  const langToggle = document.getElementById('langToggle');
  if (langToggle) {
    langToggle.addEventListener('click', () => {
      const current = localStorage.getItem('tl-lang') || 'en';
      const next = current === 'en' ? 'ta' : 'en';
      localStorage.setItem('tl-lang', next);
      tlApplyLanguage(next);
    });
  }
});
