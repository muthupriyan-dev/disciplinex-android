"""
train_model.py
---------------
Loads dataset/Fake.csv and dataset/True.csv, trains a TF-IDF + Passive
Aggressive Classifier fake-news detection model, and saves:
  - model.pkl
  - vectorizer.pkl

This is run automatically by app.py on first startup if model.pkl is
missing, or can be run manually:  python train_model.py
"""

import os
import pickle
import pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import PassiveAggressiveClassifier
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score, classification_report

from utils import clean_text

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DATASET_DIR = os.path.join(BASE_DIR, "dataset")
MODEL_PATH = os.path.join(BASE_DIR, "model.pkl")
VECTORIZER_PATH = os.path.join(BASE_DIR, "vectorizer.pkl")


def load_dataset():
    fake_path = os.path.join(DATASET_DIR, "Fake.csv")
    true_path = os.path.join(DATASET_DIR, "True.csv")

    if not (os.path.exists(fake_path) and os.path.exists(true_path)):
        # Auto-generate a synthetic dataset if the user hasn't supplied one
        print("Fake.csv / True.csv not found — generating synthetic dataset...")
        import subprocess
        subprocess.run(["python3", os.path.join(DATASET_DIR, "generate_dataset.py")],
                        cwd=DATASET_DIR, check=True)

    fake_df = pd.read_csv(fake_path)
    true_df = pd.read_csv(true_path)

    # Normalize expected columns: title, text, label
    fake_df["label"] = "FAKE"
    true_df["label"] = "REAL"

    df = pd.concat([fake_df, true_df], ignore_index=True)
    if "text" not in df.columns:
        raise ValueError("Dataset must contain a 'text' column")

    df["text"] = df["text"].fillna("")
    if "title" in df.columns:
        df["content"] = df["title"].fillna("") + " " + df["text"]
    else:
        df["content"] = df["text"]

    df["content_clean"] = df["content"].apply(clean_text)
    df = df.sample(frac=1, random_state=42).reset_index(drop=True)
    return df


def train():
    df = load_dataset()
    X = df["content_clean"]
    y = df["label"]

    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, random_state=42, stratify=y
    )

    vectorizer = TfidfVectorizer(stop_words="english", max_df=0.7, min_df=2)
    X_train_vec = vectorizer.fit_transform(X_train)
    X_test_vec = vectorizer.transform(X_test)

    model = PassiveAggressiveClassifier(max_iter=100, random_state=42)
    model.fit(X_train_vec, y_train)

    preds = model.predict(X_test_vec)
    acc = accuracy_score(y_test, preds)
    print(f"Validation Accuracy: {acc * 100:.2f}%")
    print(classification_report(y_test, preds))

    with open(MODEL_PATH, "wb") as f:
        pickle.dump(model, f)
    with open(VECTORIZER_PATH, "wb") as f:
        pickle.dump(vectorizer, f)

    print(f"Saved model to {MODEL_PATH}")
    print(f"Saved vectorizer to {VECTORIZER_PATH}")
    return acc


if __name__ == "__main__":
    train()
