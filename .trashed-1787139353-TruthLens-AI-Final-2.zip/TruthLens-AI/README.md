# TruthLens AI

**Verify Before You Believe.**

TruthLens AI is a full-stack, AI-powered fake news detection platform. Paste
news text, a URL, an image, a PDF, or your voice — get an instant REAL/FAKE
verdict with a confidence score, a plain-language explanation, and a source
credibility score. No login required.

---

## ✨ Features

| Category | What it does |
|---|---|
| **Text Analysis** | TF-IDF + Passive Aggressive Classifier predicts REAL/FAKE with a confidence score |
| **AI Explanation** | Plain-language reasoning + suspicious/clickbait phrase highlighting |
| **Confidence Meter** | Animated gauge, color-coded green → yellow → red |
| **URL Analysis** | Auto-fetches article title/author/body, analyzes it, scores source credibility (HTTPS, domain reputation, byline, URL structure) |
| **OCR Image Detection** | Upload a screenshot/photo → Tesseract OCR extracts text → editable before analysis |
| **PDF Analysis** | Full-document text extraction and analysis |
| **Voice Input** | Browser-native speech-to-text (Web Speech API) |
| **Dashboard** | Total/Fake/Real counts, average confidence, pie chart, confidence trend bar chart, recent activity |
| **History** | Full local history, per-entry delete, clear all, **CSV & PDF export** |
| **Multi-language** | English / Tamil interface toggle |
| **Dark Mode** | Toggle, persisted across visits |
| **Responsive UI** | Glassmorphism, blue-purple gradient, works on desktop/tablet/mobile |

## 🖼️ Screenshots

_Add screenshots here after deploying — e.g. `docs/screenshot-home.png`, `docs/screenshot-dashboard.png`_

## 🛠️ Tech Stack

- **Frontend:** HTML5, CSS3, JavaScript, Bootstrap 5, Chart.js, jsPDF
- **Backend:** Python, Flask
- **Machine Learning:** scikit-learn (TF-IDF Vectorizer + Passive Aggressive Classifier), pandas, NumPy
- **OCR:** pytesseract (Tesseract OCR)
- **PDF:** pdfplumber
- **Web scraping:** requests + BeautifulSoup4
- **Deployment:** Render, Gunicorn

## 🚀 Installation & Run Locally

```bash
git clone https://github.com/<your-username>/TruthLens-AI.git
cd TruthLens-AI
pip install -r requirements.txt
python app.py
```

Visit `http://localhost:5000`. The model trains automatically on first run
using the included synthetic dataset (or your own, see below).

## ☁️ Deployment on Render

1. Push this repo to GitHub.
2. Create a new **Web Service** on [Render](https://render.com), connect the repo.
3. **Build Command** (Tesseract is required for OCR):
   ```
   apt-get update && apt-get install -y tesseract-ocr && pip install -r requirements.txt
   ```
4. **Start Command:**
   ```
   gunicorn app:app
   ```
5. Render auto-detects the Python version from `runtime.txt`.

## 📁 Folder Structure

```
TruthLens-AI/
├── app.py                    # Flask app + all API routes
├── train_model.py            # Trains TF-IDF + Passive Aggressive Classifier
├── utils.py                  # Text cleaning, URL/OCR/PDF extraction, explanations, credibility scoring
├── requirements.txt
├── runtime.txt
├── Procfile
├── model.pkl / vectorizer.pkl  # Auto-generated on first run
├── dataset/
│   ├── generate_dataset.py   # Synthetic dataset generator (used if no real dataset supplied)
│   ├── Fake.csv
│   └── True.csv
├── templates/
│   ├── index.html            # Main analysis UI
│   ├── dashboard.html        # Analytics dashboard
│   └── history.html          # History + export
├── static/
│   ├── css/ (style.css, dark.css)
│   ├── js/  (main.js, dashboard.js, history.js, voice.js, i18n.js, theme.js)
│   ├── uploads/               # Reserved for temp uploads
│   └── reports/               # Reserved for generated reports
├── .github/
│   ├── workflows/python-app.yml
│   ├── ISSUE_TEMPLATE/
│   └── PULL_REQUEST_TEMPLATE.md
├── CONTRIBUTING.md
├── LICENSE
└── README.md
```

## 📊 Using Your Own Dataset

Replace `dataset/Fake.csv` and `dataset/True.csv` with real data (a `text`
column is required, `title` is optional), delete `model.pkl` and
`vectorizer.pkl`, then restart the app — it retrains automatically.

## ⚠️ Notes & Limitations

- **History/Dashboard data is stored in browser localStorage** (no server
  database, matching the no-login design) — it stays on the user's device only.
- **Voice input** requires a browser with Web Speech API support (Chrome/Edge).
  Unsupported browsers show a graceful fallback message.
- The bundled dataset is **synthetically generated** for demo purposes — swap
  in a real labeled dataset for production-grade accuracy.
- This tool is a portfolio/educational project, not a substitute for
  professional fact-checking. Always verify important news through multiple
  trusted sources.

## 🔮 Future Scope

- Full explanation translation (not just UI chrome) via a translation API
- Server-side account-based history (optional, keeping the current no-login mode as default)
- Ensemble model (TF-IDF + transformer embeddings) for higher accuracy
- Browser extension for one-click analysis while reading

## 📄 License

MIT — see [LICENSE](LICENSE).

## 👤 Author

**Muthu** — [GitHub](https://github.com/muthupriyan-dev)
