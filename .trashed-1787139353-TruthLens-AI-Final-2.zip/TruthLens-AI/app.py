"""
app.py
------
TruthLens AI — Flask backend.
Phase 1: core prediction engine (text-based fake news detection) + UI.
Later phases will add URL analysis, OCR, PDF, voice, dashboard, history export.
"""

import os
import pickle
from datetime import datetime, timezone

from flask import Flask, render_template, request, jsonify

from utils import (
    clean_text, find_suspicious_phrases, highlight_text, generate_explanation,
    extract_article_from_url, extract_text_from_image, extract_text_from_pdf,
)

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
MODEL_PATH = os.path.join(BASE_DIR, "model.pkl")
VECTORIZER_PATH = os.path.join(BASE_DIR, "vectorizer.pkl")

app = Flask(__name__)
app.config["MAX_CONTENT_LENGTH"] = 10 * 1024 * 1024  # 10 MB upload cap

model = None
vectorizer = None


def ensure_model_loaded():
    """Load model/vectorizer into memory, training automatically if missing."""
    global model, vectorizer
    if model is not None and vectorizer is not None:
        return

    if not (os.path.exists(MODEL_PATH) and os.path.exists(VECTORIZER_PATH)):
        print("Model files not found — training a new model...")
        from train_model import train
        train()

    with open(MODEL_PATH, "rb") as f:
        model = pickle.load(f)
    with open(VECTORIZER_PATH, "rb") as f:
        vectorizer = pickle.load(f)


def predict_text(raw_text: str):
    """Run the full prediction pipeline on a piece of text."""
    ensure_model_loaded()

    if not raw_text or not raw_text.strip():
        return {"error": "Empty input. Please provide some text to analyze."}, 400

    cleaned = clean_text(raw_text)
    vec = vectorizer.transform([cleaned])

    label = model.predict(vec)[0]

    # PassiveAggressiveClassifier has no predict_proba; use decision_function
    # distance from the hyperplane as a confidence proxy, squashed to 0-100%.
    decision = model.decision_function(vec)[0]
    confidence = min(99.9, 50 + abs(decision) * 12)  # heuristic scaling
    confidence = max(50.0, confidence)

    phrases = find_suspicious_phrases(raw_text)
    highlighted = highlight_text(raw_text, phrases)
    explanation = generate_explanation(label, confidence, phrases)

    return {
        "label": label,
        "confidence": round(confidence, 1),
        "explanation": explanation,
        "highlighted_text": highlighted,
        "suspicious_phrases": phrases,
        "timestamp": datetime.now(timezone.utc).isoformat(),
    }, 200


@app.route("/")
def index():
    return render_template("index.html")


@app.route("/dashboard")
def dashboard():
    return render_template("dashboard.html")


@app.route("/history")
def history():
    return render_template("history.html")


@app.route("/api/predict", methods=["POST"])
def api_predict():
    try:
        data = request.get_json(silent=True) or {}
        text = data.get("text", "")
        result, status = predict_text(text)
        return jsonify(result), status
    except Exception as e:
        return jsonify({"error": f"Prediction failed: {str(e)}"}), 500


@app.route("/api/analyze-url", methods=["POST"])
def api_analyze_url():
    try:
        data = request.get_json(silent=True) or {}
        url = data.get("url", "")

        article = extract_article_from_url(url)
        if article.get("error"):
            return jsonify({"error": article["error"]}), 400

        combined_text = f"{article['title']} {article['text']}"
        result, status = predict_text(combined_text)
        if status != 200:
            return jsonify(result), status

        result["article_title"] = article["title"]
        result["article_author"] = article["author"]
        result["article_url"] = article["url"]
        result["credibility_score"] = article["credibility_score"]
        result["credibility_reasons"] = article["credibility_reasons"]
        result["extracted_text"] = article["text"][:2000]
        return jsonify(result), 200
    except Exception as e:
        return jsonify({"error": f"URL analysis failed: {str(e)}"}), 500


@app.route("/api/analyze-image", methods=["POST"])
def api_analyze_image():
    try:
        if "image" not in request.files:
            return jsonify({"error": "No image file uploaded."}), 400
        file = request.files["image"]
        if file.filename == "":
            return jsonify({"error": "No image file selected."}), 400

        allowed = {"png", "jpg", "jpeg", "webp", "bmp"}
        ext = file.filename.rsplit(".", 1)[-1].lower() if "." in file.filename else ""
        if ext not in allowed:
            return jsonify({"error": "Unsupported image format. Use PNG, JPG, JPEG, WEBP, or BMP."}), 400

        ocr_result = extract_text_from_image(file.stream)
        if ocr_result.get("error"):
            return jsonify({"error": ocr_result["error"]}), 400

        return jsonify({"extracted_text": ocr_result["text"]}), 200
    except Exception as e:
        return jsonify({"error": f"Image analysis failed: {str(e)}"}), 500


@app.route("/api/analyze-pdf", methods=["POST"])
def api_analyze_pdf():
    try:
        if "pdf" not in request.files:
            return jsonify({"error": "No PDF file uploaded."}), 400
        file = request.files["pdf"]
        if file.filename == "":
            return jsonify({"error": "No PDF file selected."}), 400
        if not file.filename.lower().endswith(".pdf"):
            return jsonify({"error": "Please upload a valid .pdf file."}), 400

        pdf_result = extract_text_from_pdf(file.stream)
        if pdf_result.get("error"):
            return jsonify({"error": pdf_result["error"]}), 400

        result, status = predict_text(pdf_result["text"])
        if status != 200:
            return jsonify(result), status

        result["extracted_text"] = pdf_result["text"][:3000]
        return jsonify(result), 200
    except Exception as e:
        return jsonify({"error": f"PDF analysis failed: {str(e)}"}), 500


@app.route("/health")
def health():
    return jsonify({"status": "ok"})


if __name__ == "__main__":
    ensure_model_loaded()
    port = int(os.environ.get("PORT", 5000))
    app.run(host="0.0.0.0", port=port, debug=True)
