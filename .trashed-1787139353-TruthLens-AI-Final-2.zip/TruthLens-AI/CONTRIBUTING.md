# Contributing to TruthLens AI

Thanks for your interest in improving TruthLens AI! This is a portfolio/open
learning project, and contributions are welcome.

## Getting started

1. Fork the repository and clone your fork.
2. Install dependencies: `pip install -r requirements.txt`
3. Run locally: `python app.py`
4. Create a feature branch: `git checkout -b feature/your-feature-name`

## Guidelines

- Keep functions small and commented — this codebase favors readability.
- Run the app locally and manually verify your change before opening a PR.
- If you change the ML pipeline (`train_model.py`, `utils.py`), re-run
  `python train_model.py` and confirm validation accuracy is still reported.
- If you add a new API route, add matching error handling (invalid input,
  empty input, upstream failures) consistent with the existing routes in `app.py`.
- Keep the glassmorphism / blue-purple gradient visual language consistent
  with `static/css/style.css` design tokens.

## Reporting bugs

Please use the Bug Report issue template and include:
- Steps to reproduce
- Expected vs actual behavior
- Browser/OS if it's a frontend issue

## Pull requests

- Reference the issue number if applicable.
- Describe what changed and why.
- Keep PRs focused on a single feature or fix where possible.
