"""
generate_dataset.py
--------------------
Generates a synthetic but linguistically realistic Fake.csv / True.csv
dataset for TruthLens AI when no real dataset is supplied by the user.

Real news templates mimic formal journalistic structure (attribution,
neutral tone, named sources, dates, official statements).

Fake news templates mimic clickbait / sensational patterns (ALL CAPS
emphasis, emotional trigger words, unverified claims, conspiracy framing,
"share before it's deleted" style calls to action).

Run: python generate_dataset.py
Produces: Fake.csv, True.csv in the same folder (columns: title,text,label)
"""

import csv
import random

random.seed(42)

topics = [
    "the economy", "a new vaccine", "the general election", "a celebrity marriage",
    "climate policy", "a tech company merger", "a local hospital", "the stock market",
    "a government scheme", "a school reopening", "a cricket tournament", "a new law",
    "an airport expansion", "a water shortage", "a corporate scandal", "a space mission",
    "a bank policy", "a university ranking", "a road accident", "a festival celebration",
]

real_sources = [
    "Reuters", "Press Trust of India", "the Ministry of Health", "the state government",
    "a spokesperson for the company", "the university administration", "local police",
    "the Election Commission", "the World Health Organization", "the finance ministry",
]

real_templates = [
    "Officials confirmed on {day} that {topic} developments will proceed as scheduled, according to {source}.",
    "{source} released a statement on {topic}, clarifying earlier reports and providing updated figures.",
    "In a press briefing, {source} outlined the next steps regarding {topic}, citing data collected over the past quarter.",
    "The report, verified by {source}, indicates a measured and steady change relating to {topic} this year.",
    "Authorities announced updated guidelines concerning {topic} after consultation with {source} and independent experts.",
    "According to documents reviewed by journalists, {topic} will see incremental changes approved by {source}.",
    "{source} confirmed the figures related to {topic} are consistent with previous quarterly assessments.",
    "A joint statement from {source} addressed public concerns about {topic}, promising further updates next month.",
]

fake_templates = [
    "SHOCKING: You won't BELIEVE what they're hiding about {topic}!!! Share before this gets DELETED!",
    "BREAKING: Secret documents PROVE {topic} is a total scam — doctors HATE this one trick!",
    "They don't want you to know the TRUTH about {topic}. Wake up before it's too late!",
    "Insiders REVEAL shocking conspiracy behind {topic} that mainstream media refuses to report!",
    "URGENT: {topic} will DESTROY everything you know — forward this to everyone NOW!",
    "Unbelievable! Anonymous source claims {topic} is a cover-up bigger than anyone imagined.",
    "This ONE secret about {topic} will change your life forever, click to find out instantly!",
    "Experts are TERRIFIED to talk about {topic} — here's what REALLY happened behind closed doors.",
]

days = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"]


def make_rows(templates, label, n):
    rows = []
    for _ in range(n):
        topic = random.choice(topics)
        source = random.choice(real_sources)
        day = random.choice(days)
        template = random.choice(templates)
        text = template.format(topic=topic, source=source, day=day)
        title = text.split(".")[0].split("!")[0][:90]
        rows.append([title, text, label])
    return rows


true_rows = make_rows(real_templates, "REAL", 400)
fake_rows = make_rows(fake_templates, "FAKE", 400)

with open("True.csv", "w", newline="", encoding="utf-8") as f:
    w = csv.writer(f)
    w.writerow(["title", "text", "label"])
    w.writerows(true_rows)

with open("Fake.csv", "w", newline="", encoding="utf-8") as f:
    w = csv.writer(f)
    w.writerow(["title", "text", "label"])
    w.writerows(fake_rows)

print("Generated True.csv (400 rows) and Fake.csv (400 rows)")
