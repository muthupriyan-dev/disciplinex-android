"""
utils.py
--------
Shared helper functions for TruthLens AI:
- text cleaning
- suspicious/clickbait word detection & highlighting
- human-readable explanation generation
- simple URL credibility scoring (no external paid APIs required)
"""

import re
import string
import io
from urllib.parse import urlparse

import requests
from bs4 import BeautifulSoup
from PIL import Image
import pytesseract
import pdfplumber

# Words/phrases statistically associated with sensational / fake news style.
SUSPICIOUS_WORDS = [
    "shocking", "you won't believe", "secret", "they don't want you to know",
    "wake up", "conspiracy", "breaking", "urgent", "share before", "deleted",
    "insiders reveal", "mainstream media", "cover-up", "click", "forward this",
    "terrified", "destroy", "won't believe", "hate this one trick", "anonymous source",
    "unbelievable", "truth about", "one trick", "instantly", "everyone now",
]

REPUTABLE_DOMAINS = [
    "bbc.com", "bbc.co.uk", "reuters.com", "apnews.com", "cnn.com", "thehindu.com",
    "timesofindia.indiatimes.com", "ndtv.com", "indianexpress.com", "npr.org",
    "theguardian.com", "aljazeera.com", "news18.com", "hindustantimes.com",
]


def clean_text(text: str) -> str:
    """Lowercase, strip punctuation/extra whitespace for model input."""
    text = text.lower()
    text = re.sub(r"http\S+|www\S+", " ", text)
    text = re.sub(r"[^a-z\s]", " ", text)
    text = re.sub(r"\s+", " ", text).strip()
    return text


def find_suspicious_phrases(original_text: str):
    """Return list of suspicious phrases found (case-insensitive) in the original text."""
    found = []
    lower = original_text.lower()
    for phrase in SUSPICIOUS_WORDS:
        if phrase in lower:
            found.append(phrase)
    # Also flag ALL-CAPS shouting words (3+ letters, all caps) and excess exclamation marks
    caps_words = re.findall(r"\b[A-Z]{4,}\b", original_text)
    for w in caps_words:
        if w.lower() not in found:
            found.append(w)
    return found


def highlight_text(original_text: str, phrases):
    """Wrap suspicious phrases in <mark> tags for frontend display."""
    highlighted = original_text
    seen = set()
    for phrase in sorted(phrases, key=len, reverse=True):
        if phrase.lower() in seen:
            continue
        seen.add(phrase.lower())
        pattern = re.compile(re.escape(phrase), re.IGNORECASE)
        highlighted = pattern.sub(lambda m: f"<mark>{m.group(0)}</mark>", highlighted)
    return highlighted


def generate_explanation(label: str, confidence: float, phrases):
    """Produce a simple, human-readable explanation of the prediction."""
    if label == "FAKE":
        base = (
            f"This content was classified as FAKE with {confidence:.1f}% confidence. "
        )
        if phrases:
            base += (
                "The model flagged sensational or manipulative language commonly found "
                f"in misleading articles, including: {', '.join(phrases[:6])}. "
            )
        base += (
            "Fake news often uses urgent, emotional, or exaggerated wording to provoke "
            "quick sharing instead of careful reading. Verify claims with multiple "
            "reputable sources before trusting or sharing this content."
        )
    else:
        base = (
            f"This content was classified as REAL with {confidence:.1f}% confidence. "
            "The language pattern is consistent with formal, neutral reporting "
            "style typically seen in verified journalism (attribution to sources, "
            "measured tone, absence of clickbait phrasing). "
        )
        if phrases:
            base += (
                f"Note: a few flagged words were still detected ({', '.join(phrases[:4])}); "
                "consider cross-checking with an official source regardless."
            )
        else:
            base += "No major red-flag phrases were detected."
    return base


def score_url_credibility(url: str):
    """
    Lightweight heuristic credibility scoring (0-100) based on:
    - HTTPS usage
    - Known reputable domain match
    - Domain structure (subdomain spam, excessive hyphens/digits = lower trust)
    - Presence of a clean path (article-like) vs root/query-spam
    """
    score = 50
    reasons = []
    try:
        parsed = urlparse(url if "://" in url else f"https://{url}")
        domain = parsed.netloc.lower().replace("www.", "")

        if parsed.scheme == "https":
            score += 15
            reasons.append("Uses secure HTTPS connection (+15)")
        else:
            reasons.append("Does not use HTTPS (0)")

        if any(domain.endswith(d) for d in REPUTABLE_DOMAINS):
            score += 30
            reasons.append("Domain matches a known reputable news outlet (+30)")
        else:
            reasons.append("Domain not found in known reputable outlet list (0)")

        hyphens = domain.count("-")
        digits = sum(c.isdigit() for c in domain)
        if hyphens >= 2 or digits >= 3:
            score -= 15
            reasons.append("Domain contains suspicious hyphen/digit pattern (-15)")

        if len(parsed.path) > 10:
            score += 5
            reasons.append("URL contains a specific article path, not just homepage (+5)")
        else:
            reasons.append("URL points to homepage/root, less likely a specific article (0)")

        score = max(0, min(100, score))
    except Exception:
        score = 30
        reasons.append("Could not fully parse URL; defaulting to a cautious score")

    return score, reasons


# ==========================================================
# Phase 2 — URL article extraction
# ==========================================================

HEADERS = {
    "User-Agent": "Mozilla/5.0 (compatible; TruthLensBot/1.0; +https://truthlens.ai/bot)"
}


def extract_article_from_url(url: str, timeout: int = 10):
    """
    Fetch a news article URL and extract title + body text + author +
    metadata signals used for credibility scoring.
    Returns a dict with keys: title, text, author, has_https, error
    """
    if not url or not url.strip():
        return {"error": "Please provide a URL."}

    normalized = url if "://" in url else f"https://{url}"

    try:
        resp = requests.get(normalized, headers=HEADERS, timeout=timeout)
        resp.raise_for_status()
    except requests.exceptions.RequestException as e:
        return {"error": f"Could not fetch this URL: {e}"}

    soup = BeautifulSoup(resp.text, "html.parser")

    # Title: prefer og:title, fall back to <title>
    title = None
    og_title = soup.find("meta", property="og:title")
    if og_title and og_title.get("content"):
        title = og_title["content"].strip()
    elif soup.title:
        title = soup.title.get_text(strip=True)

    # Author: common meta patterns
    author = None
    for sel in [
        ("meta", {"name": "author"}),
        ("meta", {"property": "article:author"}),
    ]:
        tag = soup.find(*sel)
        if tag and tag.get("content"):
            author = tag["content"].strip()
            break

    # Body text: gather <p> tags inside <article> if present, else all <p>
    article_tag = soup.find("article")
    paragraphs = article_tag.find_all("p") if article_tag else soup.find_all("p")
    body_text = " ".join(p.get_text(" ", strip=True) for p in paragraphs)
    body_text = re.sub(r"\s+", " ", body_text).strip()

    if len(body_text) < 80:
        return {"error": "Could not extract enough readable article text from this URL. "
                          "The site may block automated access or use heavy JavaScript rendering."}

    credibility_score, credibility_reasons = score_url_credibility(normalized)
    if author:
        credibility_score = min(100, credibility_score + 5)
        credibility_reasons.append("Author byline found on page (+5)")
    else:
        credibility_reasons.append("No author byline detected (0)")

    return {
        "title": title or "(no title found)",
        "text": body_text[:6000],  # cap extremely long articles
        "author": author or "Not disclosed",
        "url": normalized,
        "credibility_score": credibility_score,
        "credibility_reasons": credibility_reasons,
        "error": None,
    }


# ==========================================================
# Phase 2 — OCR image text extraction
# ==========================================================

def extract_text_from_image(file_stream) -> dict:
    """
    Run OCR on an uploaded image file stream and return extracted text.
    """
    try:
        image = Image.open(file_stream)
        if image.mode != "RGB":
            image = image.convert("RGB")
        text = pytesseract.image_to_string(image)
        text = text.strip()
        if not text:
            return {"error": "No readable text was found in this image. "
                              "Try a clearer, higher-resolution photo."}
        return {"text": text, "error": None}
    except Exception as e:
        return {"error": f"OCR failed: {e}"}


# ==========================================================
# Phase 2 — PDF text extraction
# ==========================================================

def extract_text_from_pdf(file_stream) -> dict:
    """
    Extract all text from an uploaded PDF file stream.
    """
    try:
        text_parts = []
        with pdfplumber.open(file_stream) as pdf:
            for page in pdf.pages:
                page_text = page.extract_text() or ""
                text_parts.append(page_text)
        full_text = "\n".join(text_parts).strip()
        if not full_text:
            return {"error": "No extractable text was found in this PDF. "
                              "It may be a scanned image-only PDF without a text layer."}
        return {"text": full_text[:8000], "error": None}
    except Exception as e:
        return {"error": f"PDF extraction failed: {e}"}
