import cv2

def draw_toolbar(img, draw_color):

    # Toolbar Background
    cv2.rectangle(img, (0, 0), (640, 70), (230, 230, 230), -1)

    # Blue
    cv2.rectangle(img, (20, 15), (70, 55), (255, 0, 0), -1)

    # Green
    cv2.rectangle(img, (100, 15), (150, 55), (0, 255, 0), -1)

    # Red
    cv2.rectangle(img, (180, 15), (230, 55), (0, 0, 255), -1)

    # Yellow
    cv2.rectangle(img, (260, 15), (310, 55), (0, 255, 255), -1)

    # Eraser
    cv2.rectangle(img, (340, 15), (390, 55), (255, 255, 255), -1)
    cv2.putText(
        img,
        "E",
        (357, 43),
        cv2.FONT_HERSHEY_SIMPLEX,
        0.8,
        (0, 0, 0),
        2,
    )

    # Clear
    cv2.rectangle(img, (430, 15), (560, 55), (180, 180, 180), -1)
    cv2.putText(
        img,
        "CLEAR",
        (440, 43),
        cv2.FONT_HERSHEY_SIMPLEX,
        0.7,
        (0, 0, 0),
        2,
    )

    # Current Color Indicator
    cv2.rectangle(img, (580, 15), (630, 55), draw_color, -1)
    cv2.putText(
        img,
        "NOW",
        (575, 68),
        cv2.FONT_HERSHEY_SIMPLEX,
        0.5,
        (255, 255, 255),
        1,
    )