import cv2
import mediapipe as mp
import numpy as np
import os
from datetime import datetime
from toolbar import draw_toolbar
from hand_tracker import HandTracker
# Initialize MediaPipe Hands
tracker = HandTracker()

# Open webcam
cap = cv2.VideoCapture(0)

prev_x, prev_y = 0, 0
canvas = None
save_folder = "saved_drawings"

if not os.path.exists(save_folder):
    os.makedirs(save_folder)
draw_color = (255,0,0)
show_saved_message = False
saved_message_time = 0
brush_size = 10
eraser_size = 30
while True:
    success, img = cap.read()

    if not success:
        break

    # Mirror image
    img = cv2.flip(img, 1)
    
    cv2.rectangle(img, (180, 15), (230, 55), (0, 0, 255), -1)
    draw_toolbar(img, draw_color)

    # Create canvas once
    if canvas is None:
        canvas = np.zeros_like(img) * 255

    # Convert to RGB
    img_rgb = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)

    # Detect hands
    results = tracker.find_hands(img)

    h, w, c = img.shape

    if results.multi_hand_landmarks:
        for hand_landmarks in results.multi_hand_landmarks:
            landmarks = hand_landmarks.landmark

            index_up = landmarks[8].y < landmarks[6].y
            middle_up = landmarks[12].y < landmarks[10].y
            if index_up and not middle_up:
                print("Draw Mode")

            elif index_up and middle_up:
                print("Selection Mode")
            # Draw hand landmarks
            tracker.draw_hands(img, hand_landmarks)

            # Loop through landmarks
            for id, lm in enumerate(hand_landmarks.landmark):

                cx = int(lm.x * w)
                cy = int(lm.y * h)
                # Selection Mode
                if index_up and middle_up:

                    if cy < 70:

        # Blue
                        if 20 < cx < 70:
                            draw_color = (255, 0, 0)

        # Green
                        elif 100 < cx < 150:
                            draw_color = (0, 255, 0)

        # Red
                        elif 180 < cx < 230:
                            draw_color = (0, 0, 255)

        # Yellow
                        elif 260 < cx < 310:
                            draw_color = (0, 255, 255)

        # Eraser
                        elif 340 < cx < 390:
                            draw_color = (0,0,0)

        # Clear
                        elif 430 < cx < 560:
                            canvas[:] = 0
                # Index Finger Tip
                if id == 8:

                    cv2.circle(img, (cx, cy), 10, (0, 0, 255), cv2.FILLED)

                # ☝️ Draw Mode
                    if index_up and not middle_up:

                        if prev_x == 0 and prev_y == 0:
                            prev_x, prev_y = cx, cy

                        if draw_color == (0,0,0):
                            thickness = eraser_size    # Eraser size
                        else:
                            thickness = brush_size # Brush size

                        cv2.line(
                            canvas,
                            (prev_x, prev_y),
                            (cx, cy),
                            draw_color,
                            thickness
                        )

                       

                        prev_x, prev_y = cx, cy

    else:
        prev_x, prev_y = 0, 0

    # Merge drawing with camera
    output = cv2.addWeighted(img, 0.8, canvas, 0.8, 0)
    if show_saved_message:

        elapsed = (cv2.getTickCount() - saved_message_time) / cv2.getTickFrequency()

        if elapsed < 2:
            cv2.putText(
                output,
                "Image Saved!",
                (180, 120),
                cv2.FONT_HERSHEY_SIMPLEX,
                1,
                (0, 255, 0),
                3
            )
        else:
            show_saved_message = False

    cv2.imshow("Air Drawing", output)
    key = cv2.waitKey(1) & 0xFF

    if key == ord("s"):
        filename = datetime.now().strftime("%Y%m%d_%H%M%S") + ".png"
        filepath = os.path.join(save_folder, filename)

        cv2.imwrite(filepath, canvas)

        print(f"Saved: {filepath}")
        show_saved_message = True
        saved_message_time = cv2.getTickCount()

    if key == ord("q"):
        break


cap.release()
cv2.destroyAllWindows()