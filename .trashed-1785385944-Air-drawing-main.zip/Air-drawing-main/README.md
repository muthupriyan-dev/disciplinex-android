# 🖌️ AI Virtual Air Drawing using OpenCV & MediaPipe

A real-time computer vision project that allows users to draw in the air using hand gestures captured through a webcam. No touch or mouse required — just your fingers!

---

## 🚀 Features

- ✋ Real-time hand tracking using MediaPipe
- 🖍️ Air drawing using index finger
- 🎨 Color palette selection (Blue, Green, Red, Yellow)
- 🧽 Eraser tool
- 🧹 Clear canvas option
- 💾 Save drawings as PNG images
- 📺 On-screen toolbar UI

---

## 🛠️ Tech Stack

- Python
- OpenCV
- MediaPipe
- NumPy

---

## ▶️ How to Run

```bash
pip install opencv-python mediapipe numpy
python main.py

🎮 Controls
☝️ Index Finger → Draw
☝️✌️ Index + Middle Finger → Select toolbar
💾 Press S → Save drawing
❌ Press Q → Quit


👨‍💻 Author
Rohitha Radhakrishnan