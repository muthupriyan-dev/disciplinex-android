# DisciplineX — Phase 1 Scaffold

Fitness accountability app. This is the **foundation build**: auth (email/Google/guest),
navigation, theming, and data-layer scaffolding. No sensors, pose detection, or
lock-mode yet — those come in later phases once this builds and runs cleanly.

## Phone-only workflow (no laptop needed)

### 1. Push to GitHub
Upload this whole folder to a new GitHub repo via the browser uploader
(same way you did for your other projects).

### 2. Firebase setup (from browser, no CLI)
1. Go to [Firebase Console](https://console.firebase.google.com) → Create Project.
2. Add an Android app → package name: `com.disciplinex.app`
3. Firebase gives you: `apiKey`, `appId`, `messagingSenderId`, `projectId`.
   Copy each into `lib/firebase_options.dart` (replace the `REPLACE_WITH_...` placeholders).
4. Enable **Authentication** → Email/Password + Google sign-in methods.
5. Enable **Cloud Firestore** → start in test mode for now.
6. Download `google-services.json` from Project Settings and upload it to
   `android/app/google-services.json` in your GitHub repo (this file will exist
   after Codemagic's first build step generates the `android/` folder — see below,
   or you can pre-create the folder yourself and upload it directly).

### 3. Build the APK via Codemagic (this replaces Android Studio)
1. Sign up at [codemagic.io](https://codemagic.io) with your GitHub account — free tier available.
2. Add this repo as an app in Codemagic.
3. Codemagic auto-detects `codemagic.yaml` in this repo — it will:
   - Auto-generate the missing `android/` native folder if not present
   - Run `flutter pub get`
   - Build a debug APK
4. Once the build finishes, download the `.apk` directly from Codemagic's
   artifact list on your phone, and install it (enable "install unknown apps"
   for your browser in Android settings).

### 4. Iterate
Every time I (Claude) give you updated/new files, upload them to the same GitHub
repo (overwrite via browser editor or re-upload), then trigger a new Codemagic build.
No local compilation needed at any point.

## What's included in this scaffold
- Email/password + Google Sign-In + Guest mode auth (Firebase Auth)
- User profile model + Firestore read/write
- Workout model (ready for Phase 2 scheduling logic)
- Splash → Login/Signup → Dashboard navigation flow
- Light/dark theme toggle (persisted)
- Clean folder structure matching the original spec (`models/services/screens/widgets/providers/utils/repositories/constants`)

## Known placeholders (intentional, fill in before real use)
- `lib/firebase_options.dart` — needs your real Firebase config values
- `android/app/google-services.json` — needs to be added after Firebase Android app setup
- Codemagic email recipient in `codemagic.yaml` — update to your email for build notifications

## Next phases (once this builds clean)
1. Workout scheduling UI + local notifications (WorkManager/AlarmManager)
2. Sensor tracking (pedometer for walking/running)
3. Camera pose detection (push-ups/squats/sit-ups/plank/yoga) — this is the most
   complex phase and will need its own dependency + native permission setup
4. Recovery mode + lock mode (Android UsageStatsManager / AccessibilityService
   for app-blocking — this requires special permissions and careful Play Store
   policy handling)
5. Streaks, achievements, leaderboard, challenges
6. AI Coach (Gemini API — you already have integration experience from CVastra AI)
