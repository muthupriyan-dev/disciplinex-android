import 'package:cloud_firestore/cloud_firestore.dart';
import '../constants/app_constants.dart';
import '../models/user_model.dart';
import '../models/workout_model.dart';

class FirestoreService {
  final FirebaseFirestore _db = FirebaseFirestore.instance;

  // ---------- Users ----------
  Future<void> createUserProfile(UserModel user) async {
    await _db.collection(AppConstants.usersCollection).doc(user.uid).set(user.toMap());
  }

  Future<UserModel?> getUserProfile(String uid) async {
    final doc = await _db.collection(AppConstants.usersCollection).doc(uid).get();
    if (!doc.exists) return null;
    return UserModel.fromMap(doc.data()!);
  }

  Future<void> updateUserProfile(UserModel user) async {
    await _db
        .collection(AppConstants.usersCollection)
        .doc(user.uid)
        .update(user.toMap());
  }

  Future<void> deleteUserProfile(String uid) async {
    await _db.collection(AppConstants.usersCollection).doc(uid).delete();
  }

  // ---------- Workouts ----------
  Future<void> saveWorkout(String uid, WorkoutModel workout) async {
    await _db
        .collection(AppConstants.usersCollection)
        .doc(uid)
        .collection(AppConstants.workoutsCollection)
        .doc(workout.id)
        .set(workout.toMap());
  }

  Stream<List<WorkoutModel>> streamWorkouts(String uid) {
    return _db
        .collection(AppConstants.usersCollection)
        .doc(uid)
        .collection(AppConstants.workoutsCollection)
        .orderBy('startTime', descending: true)
        .snapshots()
        .map((snap) => snap.docs.map((d) => WorkoutModel.fromMap(d.data())).toList());
  }

  Future<void> updateWorkoutStatus(String uid, String workoutId, String status) async {
    await _db
        .collection(AppConstants.usersCollection)
        .doc(uid)
        .collection(AppConstants.workoutsCollection)
        .doc(workoutId)
        .update({'status': status});
  }

  // ---------- Streak ----------
  Future<void> updateStreak(String uid, int currentStreak, DateTime lastCompleted) async {
    await _db.collection(AppConstants.streaksCollection).doc(uid).set({
      'currentStreak': currentStreak,
      'lastCompleted': lastCompleted.toIso8601String(),
    }, SetOptions(merge: true));
  }
}
