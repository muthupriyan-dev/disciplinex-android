import 'package:flutter/material.dart';

class AppColors {
  AppColors._();

  static const Color primary = Color(0xFF2E7D32); // Discipline green
  static const Color primaryDark = Color(0xFF1B5E20);
  static const Color accent = Color(0xFFFF6D00); // Motivation orange
  static const Color background = Color(0xFFF7F9F7);
  static const Color backgroundDark = Color(0xFF121212);
  static const Color surface = Colors.white;
  static const Color surfaceDark = Color(0xFF1E1E1E);
  static const Color error = Color(0xFFD32F2F);
  static const Color success = Color(0xFF43A047);
  static const Color warning = Color(0xFFF9A825);
  static const Color textPrimary = Color(0xFF1A1A1A);
  static const Color textSecondary = Color(0xFF6B6B6B);
  static const Color lockRed = Color(0xFFC62828);
}
