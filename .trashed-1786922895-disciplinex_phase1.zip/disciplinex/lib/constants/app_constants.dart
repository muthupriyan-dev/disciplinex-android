class AppConstants {
  AppConstants._();

  static const String appName = 'DisciplineX';

  // Hive box names
  static const String userBox = 'userBox';
  static const String workoutBox = 'workoutBox';
  static const String settingsBox = 'settingsBox';

  // Firestore collection names
  static const String usersCollection = 'users';
  static const String workoutsCollection = 'workouts';
  static const String streaksCollection = 'streaks';
  static const String challengesCollection = 'challenges';

  // Recovery grace period (minutes)
  static const int recoveryGraceMinutes = 30;

  // Exercise types
  static const List<String> exerciseTypes = [
    'Walking',
    'Running',
    'Push-ups',
    'Squats',
    'Jumping Jacks',
    'Sit-ups',
    'Plank',
    'Yoga',
    'Stretching',
  ];

  // Default always-allowed apps (package names filled in during lock-mode setup)
  static const List<String> defaultAllowedApps = [
    'Phone',
    'Camera',
    'Messages',
    'Photos',
    'Calculator',
    'Emergency Contacts',
    'Maps',
  ];
}
