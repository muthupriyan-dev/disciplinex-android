class UserModel {
  final String uid;
  final String name;
  final String email;
  final int? age;
  final double? heightCm;
  final double? weightKg;
  final String? gender;
  final String fitnessGoal; // Weight Loss, Weight Gain, Muscle Building, General Fitness
  final int dailyExerciseTargetMinutes;
  final bool isGuest;
  final DateTime createdAt;

  UserModel({
    required this.uid,
    required this.name,
    required this.email,
    this.age,
    this.heightCm,
    this.weightKg,
    this.gender,
    this.fitnessGoal = 'General Fitness',
    this.dailyExerciseTargetMinutes = 30,
    this.isGuest = false,
    DateTime? createdAt,
  }) : createdAt = createdAt ?? DateTime.now();

  Map<String, dynamic> toMap() {
    return {
      'uid': uid,
      'name': name,
      'email': email,
      'age': age,
      'heightCm': heightCm,
      'weightKg': weightKg,
      'gender': gender,
      'fitnessGoal': fitnessGoal,
      'dailyExerciseTargetMinutes': dailyExerciseTargetMinutes,
      'isGuest': isGuest,
      'createdAt': createdAt.toIso8601String(),
    };
  }

  factory UserModel.fromMap(Map<String, dynamic> map) {
    return UserModel(
      uid: map['uid'] as String,
      name: map['name'] as String? ?? '',
      email: map['email'] as String? ?? '',
      age: map['age'] as int?,
      heightCm: (map['heightCm'] as num?)?.toDouble(),
      weightKg: (map['weightKg'] as num?)?.toDouble(),
      gender: map['gender'] as String?,
      fitnessGoal: map['fitnessGoal'] as String? ?? 'General Fitness',
      dailyExerciseTargetMinutes: map['dailyExerciseTargetMinutes'] as int? ?? 30,
      isGuest: map['isGuest'] as bool? ?? false,
      createdAt: map['createdAt'] != null
          ? DateTime.parse(map['createdAt'] as String)
          : DateTime.now(),
    );
  }

  UserModel copyWith({
    String? name,
    int? age,
    double? heightCm,
    double? weightKg,
    String? gender,
    String? fitnessGoal,
    int? dailyExerciseTargetMinutes,
  }) {
    return UserModel(
      uid: uid,
      name: name ?? this.name,
      email: email,
      age: age ?? this.age,
      heightCm: heightCm ?? this.heightCm,
      weightKg: weightKg ?? this.weightKg,
      gender: gender ?? this.gender,
      fitnessGoal: fitnessGoal ?? this.fitnessGoal,
      dailyExerciseTargetMinutes:
          dailyExerciseTargetMinutes ?? this.dailyExerciseTargetMinutes,
      isGuest: isGuest,
      createdAt: createdAt,
    );
  }
}
