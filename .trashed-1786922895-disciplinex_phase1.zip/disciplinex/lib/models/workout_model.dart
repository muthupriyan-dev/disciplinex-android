enum WorkoutStatus { scheduled, inProgress, paused, completed, missed, locked }

enum RepeatSchedule { everyDay, weekdays, custom }

class WorkoutModel {
  final String id;
  final String exerciseType;
  final DateTime startTime;
  final int durationMinutes;
  final RepeatSchedule repeat;
  final List<int>? customDays; // 1 = Monday ... 7 = Sunday
  final List<String> lockedApps;
  WorkoutStatus status;
  DateTime? pausedAt;
  DateTime? completedAt;
  int caloriesBurned;

  WorkoutModel({
    required this.id,
    required this.exerciseType,
    required this.startTime,
    required this.durationMinutes,
    this.repeat = RepeatSchedule.everyDay,
    this.customDays,
    this.lockedApps = const [],
    this.status = WorkoutStatus.scheduled,
    this.pausedAt,
    this.completedAt,
    this.caloriesBurned = 0,
  });

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'exerciseType': exerciseType,
      'startTime': startTime.toIso8601String(),
      'durationMinutes': durationMinutes,
      'repeat': repeat.name,
      'customDays': customDays,
      'lockedApps': lockedApps,
      'status': status.name,
      'pausedAt': pausedAt?.toIso8601String(),
      'completedAt': completedAt?.toIso8601String(),
      'caloriesBurned': caloriesBurned,
    };
  }

  factory WorkoutModel.fromMap(Map<String, dynamic> map) {
    return WorkoutModel(
      id: map['id'] as String,
      exerciseType: map['exerciseType'] as String,
      startTime: DateTime.parse(map['startTime'] as String),
      durationMinutes: map['durationMinutes'] as int,
      repeat: RepeatSchedule.values.firstWhere(
        (e) => e.name == map['repeat'],
        orElse: () => RepeatSchedule.everyDay,
      ),
      customDays: (map['customDays'] as List?)?.cast<int>(),
      lockedApps: (map['lockedApps'] as List?)?.cast<String>() ?? [],
      status: WorkoutStatus.values.firstWhere(
        (e) => e.name == map['status'],
        orElse: () => WorkoutStatus.scheduled,
      ),
      pausedAt: map['pausedAt'] != null ? DateTime.parse(map['pausedAt'] as String) : null,
      completedAt:
          map['completedAt'] != null ? DateTime.parse(map['completedAt'] as String) : null,
      caloriesBurned: map['caloriesBurned'] as int? ?? 0,
    );
  }
}
