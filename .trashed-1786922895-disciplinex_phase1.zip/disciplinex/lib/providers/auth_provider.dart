import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/foundation.dart';
import '../models/user_model.dart';
import '../services/auth_service.dart';
import '../services/firestore_service.dart';

enum AuthStatus { unknown, authenticated, unauthenticated }

class AuthProvider extends ChangeNotifier {
  final AuthService _authService = AuthService();
  final FirestoreService _firestoreService = FirestoreService();

  AuthStatus status = AuthStatus.unknown;
  UserModel? userProfile;
  String? errorMessage;
  bool isLoading = false;

  AuthProvider() {
    _authService.authStateChanges.listen(_onAuthStateChanged);
  }

  Future<void> _onAuthStateChanged(User? firebaseUser) async {
    if (firebaseUser == null) {
      status = AuthStatus.unauthenticated;
      userProfile = null;
    } else {
      status = AuthStatus.authenticated;
      userProfile = await _firestoreService.getUserProfile(firebaseUser.uid);
    }
    notifyListeners();
  }

  Future<bool> signUp(String name, String email, String password) async {
    return _runAuthAction(() async {
      final cred = await _authService.signUpWithEmail(email, password);
      final newUser = UserModel(uid: cred.user!.uid, name: name, email: email);
      await _firestoreService.createUserProfile(newUser);
      userProfile = newUser;
    });
  }

  Future<bool> signIn(String email, String password) async {
    return _runAuthAction(() async {
      await _authService.signInWithEmail(email, password);
    });
  }

  Future<bool> signInWithGoogle() async {
    return _runAuthAction(() async {
      final cred = await _authService.signInWithGoogle();
      if (cred == null) throw Exception('Sign-in cancelled');
      final existing = await _firestoreService.getUserProfile(cred.user!.uid);
      if (existing == null) {
        final newUser = UserModel(
          uid: cred.user!.uid,
          name: cred.user!.displayName ?? 'DisciplineX User',
          email: cred.user!.email ?? '',
        );
        await _firestoreService.createUserProfile(newUser);
        userProfile = newUser;
      }
    });
  }

  Future<bool> continueAsGuest() async {
    return _runAuthAction(() async {
      final cred = await _authService.signInAsGuest();
      final guestUser = UserModel(
        uid: cred.user!.uid,
        name: 'Guest',
        email: '',
        isGuest: true,
      );
      userProfile = guestUser;
    });
  }

  Future<void> signOut() async {
    await _authService.signOut();
  }

  Future<bool> _runAuthAction(Future<void> Function() action) async {
    isLoading = true;
    errorMessage = null;
    notifyListeners();
    try {
      await action();
      isLoading = false;
      notifyListeners();
      return true;
    } catch (e) {
      isLoading = false;
      errorMessage = e is FirebaseAuthException ? (e.message ?? e.code) : e.toString();
      notifyListeners();
      return false;
    }
  }
}
